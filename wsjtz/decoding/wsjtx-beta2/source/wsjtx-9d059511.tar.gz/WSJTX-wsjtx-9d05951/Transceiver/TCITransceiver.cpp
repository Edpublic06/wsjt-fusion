#include "Transceiver/TCITransceiver.hpp"
#include "Transceiver/TCIProtocol.hpp"

#include <QRegularExpression>
#include <QThread>
#include <qmath.h>

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstring>
#include <limits>

#if QT_VERSION >= QT_VERSION_CHECK(5, 15, 0)
#include <QRandomGenerator>
#endif

#include <QString>
#include "widgets/itoneAndicw.h"
#include "Network/NetworkServerLookup.hpp"
#include "moc_TCITransceiver.cpp"

#include <QStandardPaths>
#include <QDir>
#include <QDebug>
#include <QDateTime>
#include <QMutexLocker>
#include <QTimer>
#include <QVector>

#include "DecDataMutex.hpp"

namespace
{
  char const * const TCI_transceiver_1_name {"TCI Client RX1"};
  char const * const TCI_transceiver_2_name {"TCI Client RX2"};
  // Exactly 1 MHz remains within the current band.
  quint64 constexpr band_change_threshold_hz {1000000u};

  bool has_required_args (QStringList const& args, int required)
  {
    return args.size () >= required;
  }

  bool decimal_tenths (QString const& value, int * result)
  {
    auto const parts = value.split ('.');
    bool whole_ok {false};
    bool fractional_ok {false};
    int const whole = parts.value (0).toInt (&whole_ok);
    int const fractional = parts.value (1).toInt (&fractional_ok);
    if (!result || parts.size () < 2 || !whole_ok || !fractional_ok)
      {
        return false;
      }

    *result = 10 * whole + fractional;
    return true;
  }

  QString map_mode (Transceiver::MODE mode)
  {
    switch (mode)
      {
      case Transceiver::AM: return "am";
      case Transceiver::CW: return "cw";
      case Transceiver::USB: return "usb";
      case Transceiver::LSB: return "lsb";
      case Transceiver::DIG_L: return "digl";
      case Transceiver::DIG_U: return "digu";
      case Transceiver::FM: return "wfm";
      case Transceiver::DIG_FM:
        return "nfm";
      default: break;
      }
    return "";
  }
  static const QString SmTZ(";");
  static const QString SmDP(":");
  static const QString SmCM(",");
  static const QString SmTrue("true");
  static const QString SmFalse("false");

  // TCI command names
  static const QString CmdDevice("device");
  static const QString CmdReceiveOnly("receive_only");
  static const QString CmdTrxCount("trx_count");
  static const QString CmdChannelCount("channels_count");
  static const QString CmdVfoLimits("vfo_limits");
  static const QString CmdIfLimits("if_limits");
  static const QString CmdModeList("modulations_list");
  static const QString CmdMode("modulation");
  static const QString CmdReady("ready");
  static const QString CmdStop("stop");
  static const QString CmdStart("start");
  static const QString CmdPreamp("preamp");
  static const QString CmdDds("dds");
  static const QString CmdIf("if");
  static const QString CmdTrx("trx");
  static const QString CmdRxEnable("rx_enable");
  static const QString CmdTxEnable("tx_enable");
  static const QString CmdRxChannelEnable("rx_channel_enable");
  static const QString CmdRitEnable("rit_enable");
  static const QString CmdRitOffset("rit_offset");
  static const QString CmdXitEnable("xit_enable");
  static const QString CmdXitOffset("xit_offset");
  static const QString CmdSplitEnable("split_enable");
  static const QString CmdIqSR("iq_samplerate");
  static const QString CmdIqStart("iq_start");
  static const QString CmdIqStop("iq_stop");
  static const QString CmdCWSpeed("cw_macros_speed");
  static const QString CmdCWDelay("cw_macros_delay");
  static const QString CmdSpot("spot");
  static const QString CmdSpotDelete("spot_delete");
  static const QString CmdFilterBand("rx_filter_band");
  static const QString CmdVFO("vfo");
  static const QString CmdVersion("protocol"); //protocol:esdr,1.2;
  static const QString CmdTune("tune");
  static const QString CmdRxMute("rx_mute");
  static const QString CmdSmeter("rx_smeter");
  static const QString CmdPower("tx_power");
  static const QString CmdSWR("tx_swr");
  static const QString CmdECoderRX("ecoder_switch_rx");
  static const QString CmdECoderVFO("ecoder_switch_channel");
  static const QString CmdAudioSR("audio_samplerate");
  static const QString CmdAudioStart("audio_start");
  static const QString CmdAudioStop("audio_stop");
  static const QString CmdAppFocus("app_focus");
  static const QString CmdVolume("volume");
  static const QString CmdSqlEnable("sql_enable");
  static const QString CmdSqlLevel("sql_level");
  static const QString CmdDrive("drive");
  static const QString CmdTuneDrive("tune_drive");
  static const QString CmdMute("mute");
  static const QString CmdRxSensorsEnable("rx_sensors_enable");
  static const QString CmdTxSensorsEnable("tx_sensors_enable");
  static const QString CmdRxSensors("rx_sensors");
  static const QString CmdTxSensors("tx_sensors");
  static const QString CmdAgcMode("agc_mode");
  static const QString CmdAgcGain("agc_gain");
  static const QString CmdLock("lock");
}

extern "C" {
  void   fil4_state_(qint16*, qint32*, qint16*, qint32*, float*);
}
#include "ReceiveAudio.hpp"

extern float gran();		// Noise generator (for tests only)

#define RAMP_INCREMENT 64  // MUST be an integral factor of 2^16

#if defined (WSJT_SOFT_KEYING)
# define SOFT_KEYING WSJT_SOFT_KEYING
#else
# define SOFT_KEYING 1
#endif

double constexpr TCITransceiver::m_twoPi;

void TCITransceiver::register_transceivers (logger_type *, TransceiverFactory::Transceivers * registry, unsigned id1, unsigned id2)
{
  (*registry)[TCI_transceiver_1_name] = TransceiverFactory::Capabilities {id1, TransceiverFactory::Capabilities::tci, true};
  (*registry)[TCI_transceiver_2_name] = TransceiverFactory::Capabilities {id2, TransceiverFactory::Capabilities::tci, true};
}

TCITransceiver::TCITransceiver (logger_type * logger, std::unique_ptr<TransceiverBase> wrapped,QString const& rignr,
                               QString const& address, bool use_for_ptt,
                               int poll_interval, QObject * parent, ReceiveClock receive_clock)
  : PollingTransceiver {logger, poll_interval, parent}
  , wrapped_ {std::move (wrapped)}
  , rx_ {rignr}
  , server_ {address}
  , use_for_ptt_ {use_for_ptt}
  , errortable {tr("ConnectionRefused"),
                tr("RemoteHostClosed"),
                tr("HostNotFound"),
                tr("SocketAccess"),
                tr("SocketResource"),
                tr("SocketTimeout"),
                tr("DatagramTooLarge"),
                tr("Network"),
                tr("AddressInUse"),
                tr("SocketAddressNotAvailable"),
                tr("UnsupportedSocketOperation"),
                tr("UnfinishedSocketOperation"),
                tr("ProxyAuthenticationRequired"),
                tr("SslHandshakeFailed"),
                tr("ProxyConnectionRefused"),
                tr("ProxyConnectionClosed"),
                tr("ProxyConnectionTimeout"),
                tr("ProxyNotFound"),
                tr("ProxyProtocol"),
                tr("Operation"),
                tr("SslInternal"),
                tr("SslInvalidUserData"),
                tr("Temporary"),
                tr("UnknownSocket") }
  , error_ {""}
  , do_snr_ {(poll_interval & do__snr) == do__snr}
  , do_pwr_ {(poll_interval & do__pwr) == do__pwr}
  , rig_power_ {(poll_interval & rig__power) == rig__power}
  , rig_power_off_ {(poll_interval & rig__power_off) == rig__power_off}
  , tci_audio_ {(poll_interval & tci__audio) == tci__audio}
  , commander_ {nullptr}
  , tci_timer1_ {nullptr}
  , tci_loop1_ {nullptr}
  , tci_timer2_ {nullptr}
  , tci_loop2_ {nullptr}
  , tci_timer3_ {nullptr}
  , tci_loop3_ {nullptr}
  , tci_timer4_ {nullptr}
  , tci_loop4_ {nullptr}
  , tci_timer5_ {nullptr}
  , tci_loop5_ {nullptr}
  , tci_timer6_ {nullptr}
  , tci_loop6_ {nullptr}
  , tci_timer7_ {nullptr}
  , tci_loop7_ {nullptr}
  , tci_timer8_ {nullptr}
  , tci_loop8_ {nullptr}
  , m_downSampleFactor {4}
  , m_buffer ((m_downSampleFactor > 1) ?
              new short [max_buffer_size * m_downSampleFactor] : nullptr)
  , m_quickClose {false}
  , m_phi {0.0}
  , m_toneSpacing {0.0}
  , m_fSpread {0.0}
  , m_state {Idle}
  , m_jttyDrainTimer {nullptr}
  , m_jttyDrainGuard {24000}
  , m_tciBackendStartSequence {0}
  , m_tciSuccessfullyWrittenFrames {0}
  , m_tciStartMsecs {0}
  , m_tciLastReportMsecs {0}
  , m_tciFinalSnapshotEmitted {false}
  , m_tuning {false}
  , m_cwLevel {false}
  , m_j0 {-1}
  , m_toneFrequency0 {1500.0}
  , wav_file_ {QDir(QStandardPaths::writableLocation (QStandardPaths::DataLocation)).absoluteFilePath ("tx.wav").toStdString()}
{
  receive_clock_ = std::move (receive_clock);
  m_samplesPerFFT = 6912 / 2;
  tci_Ready = false;
  trxA = 0;
  trxB = 0;
  cntIQ = 0;
  bIQ = false;
  inConnected = false;
  audioSampleRate = 48000u;
  mapCmd_[CmdDevice]       = Cmd_Device;
  mapCmd_[CmdReceiveOnly]  = Cmd_ReceiveOnly;
  mapCmd_[CmdTrxCount]     = Cmd_TrxCount;
  mapCmd_[CmdChannelCount] = Cmd_ChannelCount;
  mapCmd_[CmdVfoLimits]    = Cmd_VfoLimits;
  mapCmd_[CmdIfLimits]     = Cmd_IfLimits;
  mapCmd_[CmdModeList]     = Cmd_ModeList;
  mapCmd_[CmdMode]         = Cmd_Mode;
  mapCmd_[CmdReady]        = Cmd_Ready;
  mapCmd_[CmdStop]         = Cmd_Stop;
  mapCmd_[CmdStart]        = Cmd_Start;
  mapCmd_[CmdPreamp]       = Cmd_Preamp;
  mapCmd_[CmdDds]          = Cmd_Dds;
  mapCmd_[CmdIf]           = Cmd_If;
  mapCmd_[CmdTrx]          = Cmd_Trx;
  mapCmd_[CmdRxEnable]     = Cmd_RxEnable;
  mapCmd_[CmdTxEnable]     = Cmd_TxEnable;
  mapCmd_[CmdRxChannelEnable] = Cmd_RxChannelEnable;
  mapCmd_[CmdRitEnable]    = Cmd_RitEnable;
  mapCmd_[CmdRitOffset]    = Cmd_RitOffset;
  mapCmd_[CmdXitEnable]    = Cmd_XitEnable;
  mapCmd_[CmdXitOffset]    = Cmd_XitOffset;
  mapCmd_[CmdSplitEnable]  = Cmd_SplitEnable;
  mapCmd_[CmdIqSR]         = Cmd_IqSR;
  mapCmd_[CmdIqStart]      = Cmd_IqStart;
  mapCmd_[CmdIqStop]       = Cmd_IqStop;
  mapCmd_[CmdCWSpeed]      = Cmd_CWSpeed;
  mapCmd_[CmdCWDelay]      = Cmd_CWDelay;
  mapCmd_[CmdFilterBand]   = Cmd_FilterBand;
  mapCmd_[CmdVFO]          = Cmd_VFO;
  mapCmd_[CmdVersion]      = Cmd_Version;
  mapCmd_[CmdTune]         = Cmd_Tune;
  mapCmd_[CmdRxMute]       = Cmd_RxMute;
  mapCmd_[CmdSmeter]       = Cmd_Smeter;
  mapCmd_[CmdPower]        = Cmd_Power;
  mapCmd_[CmdSWR]          = Cmd_SWR;
  mapCmd_[CmdECoderRX]     = Cmd_ECoderRX;
  mapCmd_[CmdECoderVFO]    = Cmd_ECoderVFO;
  mapCmd_[CmdAudioSR]      = Cmd_AudioSR;
  mapCmd_[CmdAudioStart]   = Cmd_AudioStart;
  mapCmd_[CmdAudioStop]    = Cmd_AudioStop;
  mapCmd_[CmdAppFocus]     = Cmd_AppFocus;
  mapCmd_[CmdVolume]       = Cmd_Volume;
  mapCmd_[CmdSqlEnable]    = Cmd_SqlEnable;
  mapCmd_[CmdSqlLevel]     = Cmd_SqlLevel;
  mapCmd_[CmdDrive]        = Cmd_Drive;
  mapCmd_[CmdTuneDrive]    = Cmd_TuneDrive;
  mapCmd_[CmdMute]         = Cmd_Mute;
  mapCmd_[CmdRxSensorsEnable] = Cmd_RxSensorsEnable;
  mapCmd_[CmdTxSensorsEnable] = Cmd_TxSensorsEnable;
  mapCmd_[CmdRxSensors]    = Cmd_RxSensors;
  mapCmd_[CmdTxSensors]    = Cmd_TxSensors;
  mapCmd_[CmdAgcMode]      = Cmd_AgcMode;
  mapCmd_[CmdAgcGain]      = Cmd_AgcGain;
  mapCmd_[CmdLock]         = Cmd_Lock;

  m_jttyDrainTimer = new QTimer {this};
  m_jttyDrainTimer->setInterval (25);
  connect (m_jttyDrainTimer, &QTimer::timeout, this, &TCITransceiver::poll_jtty_drain);
}

void TCITransceiver::onConnected()
{
  inConnected = true;
  CAT_TRACE ("TCITransceiver entered TCI onConnected and inConnected==true\n");
}

void TCITransceiver::onDisconnected()
{
  inConnected = false;
  receive_discontinuity (JttyReceiveReason::InputError);
  CAT_TRACE ("TCITransceiver entered TCI onDisonnected and inConnected==false\n");
}


void TCITransceiver::onError(QAbstractSocket::SocketError err)
{
  receive_discontinuity (JttyReceiveReason::InputError);
  qDebug() << "WebInThread::onError";
  CAT_TRACE ("TCITransceiver entered TCI onError and ErrorNumber is " + QString::number(err) + '\n');
  auto const error_index = static_cast<int> (err);
  auto const error_name = error_index >= 0 && error_index < errortable.size ()
    ? errortable.at (error_index)
    : tr ("UnknownSocketError");
  error_ = tr ("TCI websocket error: %1").arg (error_name);
}

int TCITransceiver::do_start ()
{
  if (tci_audio_) QThread::currentThread()->setPriority(QThread::HighPriority);
  CAT_TRACE ("TCITransceiver entered TCI do_start and tci_Ready is " + QString::number(tci_Ready) + '\n');
  qDebug () << "qDebug says do_start tci_Ready is: " << tci_Ready;
  if (wrapped_) wrapped_->start (0);
  url_.setUrl("ws://" + server_);
  if (url_.host() == "") url_.setHost("localhost");
  if (url_.port() == -1) url_.setPort(40001);

  if (!commander_) {
    commander_ = new QWebSocket {};
    CAT_TRACE ("TCITransceiver entered TCI do_start and commander created\n");
    connect(commander_,SIGNAL(connected()),this,SLOT(onConnected()));
    connect(commander_,SIGNAL(disconnected()),this,SLOT(onDisconnected()));
    connect(commander_,SIGNAL(binaryMessageReceived(QByteArray)),this,SLOT(onBinaryReceived(QByteArray)));
    connect(commander_,SIGNAL(textMessageReceived(QString)),this,SLOT(onMessageReceived(QString)));
    connect(commander_,SIGNAL(error(QAbstractSocket::SocketError)),this,SLOT(onError(QAbstractSocket::SocketError)));
  }
  if (!tci_loop1_) {
    tci_loop1_ = new QEventLoop  {this};
  }
  if (!tci_timer1_) {
    tci_timer1_ = new QTimer {this};
    tci_timer1_ -> setSingleShot(true);
    connect( tci_timer1_, &QTimer::timeout, tci_loop1_, &QEventLoop::quit);
    connect( this, &TCITransceiver::tci_done1, tci_loop1_, &QEventLoop::quit);
  }
  if (!tci_loop2_) {
    tci_loop2_ = new QEventLoop  {this};
  }
  if (!tci_timer2_) {
    tci_timer2_ = new QTimer {this};
    tci_timer2_ -> setSingleShot(true);
    connect( tci_timer2_, &QTimer::timeout, tci_loop2_, &QEventLoop::quit);
    connect( this, &TCITransceiver::tci_done2, tci_loop2_, &QEventLoop::quit);
  }
  if (!tci_loop3_) {
    tci_loop3_ = new QEventLoop  {this};
  }
  if (!tci_timer3_) {
    tci_timer3_ = new QTimer {this};
    tci_timer3_ -> setSingleShot(true);
    connect( tci_timer3_, &QTimer::timeout, tci_loop3_, &QEventLoop::quit);
    connect( this, &TCITransceiver::tci_done3, tci_loop3_, &QEventLoop::quit);
  }
  if (!tci_loop4_) {
    tci_loop4_ = new QEventLoop  {this};
  }
  if (!tci_timer4_) {
    tci_timer4_ = new QTimer {this};
    tci_timer4_ -> setSingleShot(true);
    connect( tci_timer4_, &QTimer::timeout, tci_loop4_, &QEventLoop::quit);
    connect( this, &TCITransceiver::tci_done4, tci_loop4_, &QEventLoop::quit);
  }
  if (!tci_loop5_) {
    tci_loop5_ = new QEventLoop  {this};
  }
  if (!tci_timer5_) {
    tci_timer5_ = new QTimer {this};
    tci_timer5_ -> setSingleShot(true);
    connect( tci_timer5_, &QTimer::timeout, tci_loop5_, &QEventLoop::quit);
    connect( this, &TCITransceiver::tci_done5, tci_loop5_, &QEventLoop::quit);
  }
  if (!tci_loop6_) {
    tci_loop6_ = new QEventLoop  {this};
  }
  if (!tci_timer6_) {
    tci_timer6_ = new QTimer {this};
    tci_timer6_ -> setSingleShot(true);
    connect( tci_timer6_, &QTimer::timeout, tci_loop6_, &QEventLoop::quit);
    connect( this, &TCITransceiver::tci_done6, tci_loop6_, &QEventLoop::quit);
  }
  if (!tci_loop7_) {
      tci_loop7_ = new QEventLoop  {this};
  }
  if (!tci_timer7_) {
      tci_timer7_ = new QTimer {this};
      tci_timer7_ -> setSingleShot(true);
      connect( tci_timer7_, &QTimer::timeout, tci_loop7_, &QEventLoop::quit);
      connect( this, &TCITransceiver::tci_done7, tci_loop7_, &QEventLoop::quit);
  }
  if (!tci_loop8_) {
      tci_loop8_ = new QEventLoop  {this};
  }
  if (!tci_timer8_) {
      tci_timer8_ = new QTimer {this};
      tci_timer8_ -> setSingleShot(true);
      connect( tci_timer8_, &QTimer::timeout, tci_loop8_, &QEventLoop::quit);
      connect( this, &TCITransceiver::tci_done8, tci_loop8_, &QEventLoop::quit);
  }

  tx_fifo = 0; tx_top_ = true;
  tci_Ready = false;
  ESDR3 = false;
  HPSDR = false;
  stream_channels_supported_ = false;
  band_change = false;
  trxA = 0;
  trxB = 0;
  busy_rx_frequency_ = false;
  busy_mode_ = false;
  busy_other_frequency_ = false;
  busy_split_ = false;
  busy_drive_ = false;
  busy_PTT_ = false;
  busy_rx2_ = false;
  rx2_ = false;
  requested_rx2_ = false;
  started_rx2_ = false;
  split_ = false;
  requested_split_ = false;
  started_split_ = false;
  PTT_ = false;
  requested_PTT_ = false;
  mode_ = "";
  requested_mode_ = "";
  started_mode_ = "";
  requested_rx_frequency_ = "";
  rx_frequency_ = "";
  requested_other_frequency_ = "";
  other_frequency_ = "";
  requested_drive_ = "";
  drive_ = "";
  level_ = -54;
  txAtten = 45;
  power_ = 0;
  swr_ = 0;
  m_bufferPos = 0;
  m_downSampleFactor =4;
  m_ns = 999;
  audio_ = false;
  requested_stream_audio_ = false;
  stream_audio_ = false;
  _power_ = false;
  CAT_TRACE ("TCITransceiver entered TCI do_start and url " + url_.toString() + " rig_power:" + QString::number(rig_power_) + " rig_power_off:" + QString::number(rig_power_off_) + " tci_audio:" + QString::number(tci_audio_) + " do_snr:" + QString::number(do_snr_) + " do_pwr:" + QString::number(do_pwr_) + '\n');
  commander_->open (url_);
  mysleep7(2000);
  busy_split_ = true;
  const QString cmd = CmdSplitEnable + SmDP + "false" + SmTZ;
  sendTextMessage(cmd);
  busy_split_ = false;
  if (error_.isEmpty()) {
    tci_Ready = true;
    if (!_power_) {
      if (rig_power_) {
        rig_power(true);
        mysleep7(1000);
        if(!_power_) throw error {tr ("TCI SDR could not be switched on")};
      } else {
        tci_Ready = false;
        throw error {tr ("TCI SDR is not switched on")};
      }
    }
    if (rx_ == "1" && !rx2_) {
      rx2_enable (true);
      if (!rx2_) {
        tci_Ready = false;
        throw error {tr ("TCI RX2 could not be enabled")};
      }
    }
    if (tci_audio_) {
      stream_audio (true);
      mysleep7(500);
      if (!stream_audio_) {
        tci_Ready = false;
        throw error {tr ("TCI Audio could not be switched on")};
      }
    }
    if (ESDR3) {
      const QString cmd = CmdRxSensorsEnable + SmDP + (do_snr_ ? "true" : "false") + SmCM + "500" +  SmTZ;
      sendTextMessage(cmd);
    } else if (do_snr_) {
      const QString cmd = CmdSmeter + SmDP + rx_ + SmCM + "0" +  SmTZ;
      sendTextMessage(cmd);
    }
    do_poll ();
    if (ESDR3) {
      const QString cmd = CmdTxSensorsEnable + SmDP + (do_pwr_ ? "true" : "false") + SmCM + "500" +  SmTZ;
      sendTextMessage(cmd);
    }
    if (stream_audio_) do_audio(true);

    CAT_TRACE ("TCITransceiver started\n");
    return 0;
  } else {
    CAT_TRACE("TCITransceiver not started with error " + error_ + '\n');

    if (error_.isEmpty())
      throw error {tr ("TCI could not be opened")};
    else
      throw error {error_};
  }
}

void TCITransceiver::do_stop ()
{
  bool const endingContinuous = m_receivePolicy == ReceivePolicy::ContinuousJtty;
  if (m_receivePolicy == ReceivePolicy::ContinuousJtty) audio_ = false;
  receive_discontinuity (JttyReceiveReason::SourceChanged);
  m_receivePolicy = ReceivePolicy::Timed;
  m_receiveContext = 0;
  m_jttyPublisher.setContext (0);
  if (endingContinuous) Q_EMIT continuousReceptionStopped (m_jttyPublisher.mailbox ());
  CAT_TRACE ("TCITransceiver TCI close\n");
  if (!commander_) return;
  if (stream_audio_ && tci_Ready && inConnected && _power_) {
    stream_audio (false);
    mysleep7(500);
    CAT_TRACE ("TCI audio closed\n");
  }
  if (tci_Ready && inConnected && _power_) {
    requested_other_frequency_ = "";
    busy_split_ = true;
    const QString cmd = CmdSplitEnable + SmDP + "false" + SmTZ;
    sendTextMessage(cmd);
    mysleep5(500);
    busy_split_ = false;
    requested_split_ = false;
    rig_split();
    if (started_mode_ != mode_) sendTextMessage(mode_to_command(started_mode_));
    if (!started_rx2_ && rx2_) {
      rx2_enable (false);
    }
  }
  if (_power_ && rig_power_off_ && tci_Ready && inConnected) {
    rig_power(false);
    mysleep1(500);
    CAT_TRACE ("TCI power down\n");
  }
  tci_Ready = false;
  if (commander_)
  {
    if (inConnected) commander_->close(QWebSocketProtocol::CloseCodeNormal,"end");
    delete commander_, commander_ = nullptr;
    CAT_TRACE ("deleted commander & closed websocket & deleted:");
  }
  // The wait helpers are parent-owned and reused when the adapter restarts.
  if (tci_timer1_)
  {
    if (tci_timer1_->isActive()) tci_timer1_->stop();
    CAT_TRACE ("timer1 ");
  }
  if (tci_loop1_)
  {
    tci_loop1_->quit();
    CAT_TRACE ("loop1 ");
  }
  if (tci_timer2_)
  {
    if (tci_timer2_->isActive()) tci_timer2_->stop();
    CAT_TRACE ("timer2 ");
  }
  if (tci_loop2_)
  {
    tci_loop2_->quit();
    CAT_TRACE ("loop2 ");
  }
  if (tci_timer3_)
  {
    if (tci_timer3_->isActive()) tci_timer3_->stop();
    CAT_TRACE ("timer3 ");
  }
  if (tci_loop3_)
  {
    tci_loop3_->quit();
    CAT_TRACE ("loop3 ");
  }
  if (tci_timer4_)
  {
    if (tci_timer4_->isActive()) tci_timer4_->stop();
    CAT_TRACE ("timer4 ");
  }
  if (tci_loop4_)
  {
    tci_loop4_->quit();
    CAT_TRACE ("loop4 ");
  }
  if (tci_timer5_)
  {
    if (tci_timer5_->isActive()) tci_timer5_->stop();
    CAT_TRACE ("timer5 ");
  }
  if (tci_loop5_)
  {
    tci_loop5_->quit();
    CAT_TRACE ("loop5 ");
  }
  if (tci_timer6_)
  {
    if (tci_timer6_->isActive()) tci_timer6_->stop();
    CAT_TRACE ("timer6 ");
  }
  if (tci_loop6_)
  {
    tci_loop6_->quit();
    CAT_TRACE ("loop6 ");
  }
  if (tci_timer7_)
  {
      if (tci_timer7_->isActive()) tci_timer7_->stop();
      CAT_TRACE ("timer7 ");
  }
  if (tci_loop7_)
  {
      tci_loop7_->quit();
      CAT_TRACE ("loop7 ");
  }
  if (tci_timer8_)
  {
      if (tci_timer8_->isActive()) tci_timer8_->stop();
      CAT_TRACE ("timer8 ");
  }
  if (tci_loop8_)
  {
      tci_loop8_->quit();
      CAT_TRACE ("loop8 ");
  }

  if (wrapped_) wrapped_->stop ();
  CAT_TRACE ("& closed TCITransceiver\n");
}

void TCITransceiver::onMessageReceived(const QString &str)
{
  qDebug() << "From WEB" << str;
  QStringList cmd_list = str.split(";", SkipEmptyParts);
  for (QString cmds : cmd_list){
    QStringList cmd = cmds.split(":", SkipEmptyParts);
    if (cmd.isEmpty ()) continue;
    QStringList args = cmd.last().split(",", SkipEmptyParts);
    Tci_Cmd idCmd = mapCmd_[cmd.first()];
    if (idCmd != Cmd_Power && idCmd != Cmd_SWR && idCmd != Cmd_Smeter && idCmd != Cmd_AppFocus && idCmd != Cmd_RxSensors && idCmd != Cmd_TxSensors) { printf("%s TCI message received:|%s| ",QDateTime::QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),str.toStdString().c_str()); printf("idCmd : %d args : %s\n",idCmd,args.join("|").toStdString().c_str());}
    qDebug() << cmds << idCmd;
    if (idCmd <=0) continue;

    switch (idCmd) {
      case Cmd_Smeter:
        if (!has_required_args (args, 3)) break;
        if(args.at(0)==rx_ && args.at(1) == "0") level_ = args.at(2).toInt() + 73;
        break;
      case Cmd_RxSensors:
        if (!has_required_args (args, 2)) break;
        if(args.at(0)==rx_) level_ = args.at(1).split(".")[0].toInt() + 73;
        printf("Smeter=%d\n",level_);
        break;
      case Cmd_TxSensors:
        if (!has_required_args (args, 5)) break;
        if(args.at(0)==rx_) {
          int power;
          int swr;
          if (!decimal_tenths (args.at (3), &power) ||
              !decimal_tenths (args.at (4), &swr)) break;
          power_ = power;
          swr_ = swr;
          printf("Power=%d SWR=%d\n",power_,swr_);
        }
        break;
      case Cmd_SWR:
        if (!has_required_args (args, 1)) break;
        printf("%s Cmd_SWR : %s\n",QDateTime::QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),args.join("|").toStdString().c_str());
        {
          int swr;
          if (!decimal_tenths (args.at (0), &swr)) break;
          swr_ = swr;
        }
        break;
      case Cmd_Power:
        if (!has_required_args (args, 1)) break;
        {
          int power;
          if (!decimal_tenths (args.at (0), &power)) break;
          power_ = power;
        }
        printf("%s Cmd_Power : %s %d\n",QDateTime::QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),args.join("|").toStdString().c_str(),power_);
        break;
      case Cmd_VFO:
      {
        printf("%s Cmd_VFO : %s\n",QDateTime::QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),args.join("|").toStdString().c_str());
        printf("band_change:%d busy_other_frequency_:%d timer1_remaining:%d timer2_remaining:%d",band_change,busy_other_frequency_,tci_timer7_->remainingTime(),tci_timer2_->remainingTime());
        if (!has_required_args (args, 1) || args.at (0) != rx_) break;
        if (!has_required_args (args, 3)
            || (args.at (1) != "0" && args.at (1) != "1"))
          {
            error_ = tr ("TCI sent an invalid VFO frequency");
            CAT_TRACE (error_);
            break;
          }
        Frequency received_frequency;
        if (!TciProtocol::parse_frequency (args.at (2), &received_frequency))
          {
            error_ = tr ("TCI sent an invalid VFO frequency");
            CAT_TRACE (error_ + ": " + args.at (2));
            break;
          }
        auto const received_frequency_text = QString::number (received_frequency);
        if(args.at(1) == "0") {
          rx_frequency_ = received_frequency_text;
          CAT_TRACE("Rx VFO Frequency from SDR is :");
          CAT_TRACE(rx_frequency_);
          if (!tci_Ready && requested_rx_frequency_.isEmpty()) requested_rx_frequency_ = rx_frequency_;
          if (busy_rx_frequency_ && !band_change) {
            printf (" cmdvfo0 done1");
            tci_done7();
          } else if (!tci_timer2_->isActive() && split_) {
            printf (" cmdvfo0 timer2 start 210");
            tci_timer2_->start(210);
          }
        }
        else {
          other_frequency_ = received_frequency_text;
          CAT_TRACE("Tx VFO (other) Frequency from SDR is :");
          CAT_TRACE(other_frequency_);
          if (!tci_Ready && requested_other_frequency_.isEmpty()) requested_other_frequency_ = other_frequency_;
          if (band_change && tci_timer7_->isActive()) {
            printf (" cmdvfo1 done1");
            band_change = false;
            tci_timer2_->start(210);
            tci_done7();
          } else if (busy_other_frequency_) {
            printf (" cmdvfo1 done2");
            tci_done2();
          } else if (tci_timer2_->isActive()) {
            printf (" cmdvfo1 timer2 reset 210");
            tci_timer2_->start(210);
          } else if (other_frequency_ != requested_other_frequency_ && tci_Ready && split_ && !tci_timer2_->isActive()) {
            printf (" cmdvfo1 timer2 start 210");
            tci_timer2_->start(210);
          }
        }
        break;
      }
      case Cmd_Mode:
        printf("%s Cmd_Mode : %s\n",QDateTime::QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),args.join("|").toStdString().c_str());
        if (!has_required_args (args, 2)) break;
        if(args.at(0)==rx_) {
          if (ESDR3 || HPSDR) {
            if (args.at(1) == "0" ) {
              if (!has_required_args (args, 3)) break;
              mode_ = args.at(2).toLower();
            } else {
              mode_ = args.at(1).toLower();
            }
          } else mode_ = args.at(1);
          if (started_mode_.isEmpty()) started_mode_ = mode_;
          if (busy_mode_) {
            if (requested_mode_.isEmpty() || requested_mode_ == mode_) tci_done8();
            return;
          }
          else if (!requested_mode_.isEmpty() && requested_mode_ != mode_ && !band_change) {
            sendTextMessage(mode_to_command(requested_mode_));
          }
        }
        break;
      case Cmd_SplitEnable:
        printf("%s Cmd_SplitEnable : %s\n",QDateTime::QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),args.join("|").toStdString().c_str());
        if (!has_required_args (args, 2)) break;
        if(args.at(0)==rx_) {
          if (args.at(1) == "false") split_ = false;
          else if (args.at(1) == "true") split_ = true;
          if (!tci_Ready) {started_split_ = split_;}
          else if (busy_split_) tci_done5();
          else if (requested_split_ != split_ && !tci_timer5_->isActive()) {
              CAT_TRACE("tci_timer5 started in onMessageReceived-Cmd_SplitEnable");
            tci_timer5_->start(210);
            rig_split();
          }
        }
        break;
      case Cmd_Drive:
        printf("%s Cmd_Drive : %s\n",QDateTime::QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),args.join("|").toStdString().c_str());
        if ((!ESDR3 && !HPSDR && !has_required_args (args, 1)) || ((ESDR3 || HPSDR) && !has_required_args (args, 2))) break;
        if((!ESDR3 && !HPSDR) || args.at(0)==rx_) {
          if (ESDR3 || HPSDR) drive_ = args.at(1); else drive_ = args.at(0);
          if (requested_drive_.isEmpty()) requested_drive_ = drive_;
          busy_drive_ = false;
        }
        break;
      case Cmd_Volume:
        break;
      case Cmd_Trx:
        printf("%s Cmd_Trx : %s\n",QDateTime::QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),args.join("|").toStdString().c_str());
        if (!has_required_args (args, 2)) break;
        if(args.at(0)==rx_) {
          if (args.at(1) == "false") PTT_ = false;
          else if (args.at(1) == "true") PTT_ = true;
          if (tci_Ready && requested_PTT_ == PTT_) tci_done3();
          else if (tci_Ready && !PTT_) {
            requested_PTT_ = PTT_;
            update_PTT(PTT_);
            power_ = 0; if (do_pwr_) update_power (0);
            swr_ = 0; if (do_pwr_) update_swr (0);
          }
        }
        break;
      case Cmd_AudioStart:
        printf("%s Cmd_AudioStart : %s\n",QDateTime::QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),args.join("|").toStdString().c_str());
        if (!has_required_args (args, 1)) break;
        if(args.at(0)==rx_) {
          stream_audio_ = true;
          if (tci_Ready) {
            printf ("cmdaudiostart done1\n");
            tci_done7();
          }
        }
        break;
      case Cmd_RxEnable:
        printf("%s Cmd_RxEnable : %s\n",QDateTime::QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),args.join("|").toStdString().c_str());
        if (!has_required_args (args, 2)) break;
        if(args.at(0)=="1") {
          if (args.at(1) == "false") rx2_ = false;
          else if (args.at(1) == "true") rx2_ = true;
          if(!tci_Ready) {requested_rx2_ = rx2_; started_rx2_ = rx2_;}
          else if (tci_Ready && busy_rx2_ && requested_rx2_ == rx2_) {
            tci_done4();
          }
        }
        break;
      case Cmd_AudioStop:
        printf("%s CmdAudioStop : %s\n",QDateTime::QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),args.join("|").toStdString().c_str());
        if (!has_required_args (args, 1)) break;
        if(args.at(0)==rx_) {
          stream_audio_ = false;
          if (tci_Ready) {
            printf ("cmdaudiostop done1\n");
            tci_done7();
          }
        }
        break;
      case Cmd_Start:
        printf("%s CmdStart : %s\n",QDateTime::QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),args.join("|").toStdString().c_str());
        _power_ = true;
        printf ("cmdstart done1\n");
        if (tci_Ready) {
          tci_done7();
        }
        break;
      case Cmd_Stop:
        printf("%s CmdStop : %s\n",QDateTime::QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),args.join("|").toStdString().c_str());
        if (tci_Ready && PTT_) {
          PTT_ = false;
          requested_PTT_ = PTT_;
          update_PTT(PTT_);
          power_ = 0; if (do_pwr_) update_power (0);
          swr_ = 0; if (do_pwr_) update_swr (0);
          m_state = Idle;
          if (m_jttyDrainTimer && m_jttyDrainTimer->isActive ()) m_jttyDrainTimer->stop ();
          Q_EMIT tci_mod_active(m_state != Idle);
        }
        _power_ = false;
        if (tci_timer1_->isActive()) {
          printf ("cmdstop done1\n");
          tci_done1();
        } else {
          tci_Ready = false;
        }
        break;
      case Cmd_Version:
        printf("%s CmdVersion : %s\n",QDateTime::QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),args.join("|").toStdString().c_str());
        if (!has_required_args (args, 1)) break;
        if(args.at(0)=="ExpertSDR3") ESDR3 = true;
        else if (args.at(0)=="Thetis") HPSDR = true;
        stream_channels_supported_ = has_required_args (args, 2)
          && TciStream::protocol_has_channels (args.at (1));
        break;
      case Cmd_Device:
        printf("%s CmdDevice : %s\n",QDateTime::QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),args.join("|").toStdString().c_str());
        if (!has_required_args (args, 1)) break;
        if((args.at(0)=="SunSDR2DX" || args.at(0)=="SunSDR2PRO") && !ESDR3) tx_top_ = false;
        printf ("tx_top_:%d\n",tx_top_);
        break;
      case Cmd_Ready:
        printf("%s CmdReady : %s\n",QDateTime::QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),args.join("|").toStdString().c_str());
        tci_done7();
        break;

      default:
        break;
    }
  }
}

void TCITransceiver::sendTextMessage(const QString &message)
{
  if (inConnected) {
    commander_->sendTextMessage(message);
    CAT_TRACE ("TCI Command Sent: " + message + '\n');
  }
}

void TCITransceiver::onBinaryReceived(const QByteArray &data)
{
  auto const * pStream = TciStream::header (data);
  if (!pStream) {
    return;
  }

  if (pStream->type != last_type) {
    last_type = pStream->type;
  }
  if (pStream->type == TciStream::IqStream){
    if (!TciStream::has_complete_float_payload (data, pStream->length)) {
      return;
    }
    bool tx = false;
    if (pStream->receiver == 0){
      tx = trxA == 0;
      trxA = 1;
    }
    if (pStream->receiver == 1) {
      tx = trxB == 0;
      trxB = 1;
    }
    printf("sendIqData\n");
    emit sendIqData(pStream->receiver,pStream->length,
                    const_cast<float *> (TciStream::float_payload (data)),tx);
    qDebug() << "IQ" << data.size() << pStream->length;
  } else if (pStream->type == TciStream::RxAudioStream && audio_  && pStream->receiver == rx_.toUInt()) {
    if (!TciStream::has_complete_float_payload (data, pStream->length)) {
      receive_discontinuity (JttyReceiveReason::InputError);
      return;
    }
    writeAudioData(const_cast<float *> (TciStream::float_payload (data)),pStream->length);
  } else if (pStream->type == TciStream::TxChrono &&  pStream->receiver == rx_.toUInt()) {
    quint32 channels;
    if (!TciStream::valid_tx_chrono (*pStream, stream_channels_supported_,
                                     audioSampleRate, &channels)) {
      return;
    }

    qint64 generatedScalars {0};
    {
      std::lock_guard<std::mutex> lock {mtx_};
      tx_fifo += 1; tx_fifo &= 7;
      if (!TciStream::prepare_tx_audio_frame (&m_tx1[tx_fifo], *pStream, channels)) {
        return;
      }

      auto * response = TciStream::header (&m_tx1[tx_fifo]);
      auto * payload = TciStream::float_payload (&m_tx1[tx_fifo]);
      auto generated = readAudioData (payload, response->length, channels, txAtten);
      generatedScalars = generated;
      if (generated < response->length) {
        generatedScalars += readAudioData (payload + generated,
                                           response->length - generated,
                                           channels, txAtten);
      }
      tx_fifo2 = tx_fifo;
    }

    if (!inConnected || commander_->sendBinaryMessage(m_tx1[tx_fifo2]) != m_tx1[tx_fifo2].size()) {
      return;
    }

    // A generated source frame is committed only when its containing WebSocket
    // response is sent completely; protocol padding past the source extent is
    // not evidence that omitted source audio reached the radio.
    qint64 const frames = TxEvidence::interleavedFrameCount (generatedScalars,
                                                             int (channels));
    m_tciSuccessfullyWrittenFrames += frames;
    emit_tci_playout_snapshot (false, m_state == Idle);
  }
}

void TCITransceiver::txAudioData(quint32 len, float * data)
{
  if (len % TciStream::DefaultChannels || (len && !data)) {
    return;
  }

  TciStream::Header chrono {};
  chrono.receiver = 0u;
  chrono.sampleRate = audioSampleRate;
  chrono.length = len;
  QByteArray tx;
  if (!TciStream::prepare_tx_audio_frame (&tx, chrono, TciStream::DefaultChannels)) {
    return;
  }

  if (len) {
    std::memcpy (TciStream::float_payload (&tx), data, len * sizeof (float));
  }
  commander_->sendBinaryMessage(tx);
}

void TCITransceiver::enqueue_jtty_pcm (QByteArray const& samples,
                                       TxAudioQueueEpoch epoch,
                                       qint64 enqueueId) noexcept
{
  if (samples.isEmpty () || samples.size () % int (sizeof (qint16)))
    {
      Q_EMIT jtty_enqueue_failed (
        epoch, enqueueId, TxAudioQueueEnqueueFailure::Capacity);
      return;
    }

  qint64 const count = samples.size () / int (sizeof (qint16));
  qint16 const * pcm = reinterpret_cast<qint16 const *> (samples.constData ());
  auto const result = m_txAudioQueue.enqueue (pcm, count, epoch);
  if (!result.accepted)
    {
      if (epoch == result.progress.epoch)
        {
          CAT_WARNING ("JTTY TCI transmit FIFO overflow; rejecting PCM enqueue\n");
        }
      else
        {
          CAT_DEBUG ("JTTY TCI transmit queue epoch changed; rejecting stale PCM enqueue\n");
        }
      Q_EMIT jtty_enqueue_failed (epoch, enqueueId, result.failure);
      return;
    }
  Q_EMIT jtty_enqueue_accepted (enqueueId, count, result.progress);
}

void TCITransceiver::clear_jtty_pcm (TxAudioQueueEpoch epoch) noexcept
{
  m_txAudioQueue.clear (epoch);
  // PCM enqueue and TxChrono consumption both run on this rig thread.
  m_txAudioQueue.applyPendingReset ();
}

void TCITransceiver::poll_jtty_drain ()
{
  // TCI audio is pulled while responding to TxChrono packets. Emitting the
  // completion signal here keeps Qt work out of that packet/audio path.
  if (m_state == Idle || m_txMode != "JTTY") return;
  auto const current = m_txAudioQueue.progress ();
  if (current.epoch.isValid ()
      && (current.epoch != m_jttyLastProgress.epoch
          || current.served_samples != m_jttyLastProgress.served_samples
          || current.total_samples != m_jttyLastProgress.total_samples))
    {
      m_jttyLastProgress = current;
      Q_EMIT jtty_progress (current);
    }
  auto const drain = m_txAudioQueue.takeDrainReady ();
  if (drain.ready)
    {
      Q_EMIT jtty_drained (drain);
    }
}

void TCITransceiver::clear ()
{
  m_receiveAudioProducer.reset (m_period);
  m_bufferPos = 0;
}

quint32 TCITransceiver::writeAudioData (float * data, qint32 maxSize)
{
  if (dec_data_input_blocked ())
    {
      receive_discontinuity (JttyReceiveReason::Replay);
      return maxSize;
    }

  QVector<qint64> frame_counts;
  QVector<ReceiveAudio> audio;
  bool continuousNotify = false;
  bool const continuous = m_receivePolicy == ReceivePolicy::ContinuousJtty;
  qint64 const now = receive_clock_ ? receive_clock_ () : QDateTime::currentMSecsSinceEpoch ();
  qint64 const packetFrames = maxSize / static_cast<qint32> (rxChannels);
  qint64 const packetDurationMs = audioSampleRate
    ? qRound64 (1000.0 * packetFrames / audioSampleRate) : 0;
  qint64 const packetStartUtc = now - packetDurationMs;
  qint64 ms0 = now % 86400000;
  unsigned mstr = continuous ? 0 : ms0 % int(1000.0*m_period);

  if(data == NULL) {
    QMutexLocker lock {&dec_data_mutex ()};
    if (dec_data_input_blocked ()) return maxSize;
    if(!continuous && mstr < m_lastPeriodOffsetMs/2) { //When mstr has wrapped around to 0, restart the buffer
      clear ();
    }
    m_lastPeriodOffsetMs=mstr;
    return maxSize;    // we drop any data past the end of the buffer on
    // the floor until the next period starts
  }

  double const receiveGain = std::pow (10.0, 0.05 * rxAtten);

  {
    QMutexLocker lock {&dec_data_mutex ()};
    auto& producer = m_receiveAudioProducer.data ();
    if (dec_data_input_blocked ()) {
      receive_discontinuity (JttyReceiveReason::Replay);
      return maxSize;
    }

    if(!continuous && mstr < m_lastPeriodOffsetMs/2) { //When mstr has wrapped around to 0, restart the buffer
      clear ();
    }
    m_lastPeriodOffsetMs=mstr;
    if (continuous) continuousNotify = m_jttyPublisher.begin (packetStartUtc);

    // no torn frames
    Q_ASSERT (!(maxSize % static_cast<qint32> (rxChannels)));

    // these are in terms of input frames (not down sampled)
    size_t framesAcceptable (continuous ? maxSize / rxChannels : (sizeof producer.d2 /
                                 sizeof producer.d2[0] - m_receiveAudioProducer.frames ()) * m_downSampleFactor);
    size_t framesAccepted (qMin (static_cast<size_t> (maxSize /
                                                      rxChannels), framesAcceptable));

    if (framesAccepted < static_cast<size_t> (maxSize / rxChannels)) {
      qDebug () << "dropped " << maxSize / rxChannels - framesAccepted
               << " frames of data on the floor!"
               << m_receiveAudioProducer.frames () << mstr;
    }

    for (unsigned remaining = framesAccepted; remaining; ) {
      size_t numFramesProcessed (qMin (m_samplesPerFFT *
                                       m_downSampleFactor - m_bufferPos, remaining));

      if(m_downSampleFactor > 1) {
        store (&data[(framesAccepted - remaining) * rxChannels],
              numFramesProcessed, &m_buffer[m_bufferPos], receiveGain);
        m_bufferPos += numFramesProcessed;

        if(m_bufferPos==m_samplesPerFFT*m_downSampleFactor) {
          qint32 framesToProcess (m_samplesPerFFT * m_downSampleFactor);
          qint32 framesAfterDownSample (m_samplesPerFFT);
          if (continuous) {
            fil4_state_ (m_buffer.data (), &framesToProcess, m_jttyOutput.data (),
                         &framesAfterDownSample, m_downsampleState.data ());
            continuousNotify = m_jttyPublisher.append (m_jttyOutput.data (), framesAfterDownSample)
              || continuousNotify;
          } else if(m_downSampleFactor > 1 && m_receiveAudioProducer.frames ()>=0 &&
              m_receiveAudioProducer.frames () < (NTMAX*12000 - framesAfterDownSample)) {
            fil4_state_(&m_buffer[0], &framesToProcess,
                  &producer.d2[m_receiveAudioProducer.frames ()],
                  &framesAfterDownSample, m_downsampleState.data ());
            m_receiveAudioProducer.setFrames (m_receiveAudioProducer.frames () + framesAfterDownSample);
          } else {
            qDebug() << "framesToProcess     = " << framesToProcess;
            qDebug() << "receive audio frames = " << m_receiveAudioProducer.frames ();
            qDebug() << "framesAfterDownSample" << framesAfterDownSample;
          }
          if (!continuous) {
            frame_counts << m_receiveAudioProducer.frames ();
            audio << m_receiveAudioProducer.capture (m_receiveAudioProducer.frames (), m_period);
          }
          m_bufferPos = 0;
        }

      } else {
        store (&data[(framesAccepted - remaining) * rxChannels],
              numFramesProcessed, continuous ? m_jttyOutput.data () + m_bufferPos
                : &producer.d2[m_receiveAudioProducer.frames ()], receiveGain);
        m_bufferPos += numFramesProcessed;
        if (!continuous) m_receiveAudioProducer.setFrames (m_receiveAudioProducer.frames () + numFramesProcessed);
        if (m_bufferPos == static_cast<unsigned> (m_samplesPerFFT)) {
          if (continuous) {
            continuousNotify = m_jttyPublisher.append (m_jttyOutput.data (), m_bufferPos)
              || continuousNotify;
          } else {
            frame_counts << m_receiveAudioProducer.frames ();
            audio << m_receiveAudioProducer.capture (m_receiveAudioProducer.frames (), m_period);
          }
          m_bufferPos = 0;
        }
      }
      remaining -= numFramesProcessed;
    }
  }

  for (auto frames : frame_counts) {
    Q_EMIT tciframeswritten (frames);
  }
  for (auto const& block : audio) Q_EMIT receiveAudio (block);
  if (continuousNotify) Q_EMIT continuousAudioAvailable (m_jttyPublisher.mailbox ());

  return maxSize;    // we drop any data past the end of the buffer on
  // the floor until the next period starts
}

void TCITransceiver::rx2_enable (bool on)
{
  printf("%s TCI rx2_enable:%d->%d busy:%d\n",QDateTime::QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),rx2_,on,busy_rx2_);
  if (busy_rx2_) return;
  requested_rx2_ = on;
  busy_rx2_ = true;
  const QString cmd = CmdRxEnable + SmDP + "1" + SmCM + (requested_rx2_ ? "true" : "false") + SmTZ;
  sendTextMessage(cmd);
  mysleep4(1000);
  busy_rx2_ = false;
}

void TCITransceiver::rig_split ()
{
  printf("%s TCI rig_split:%d->%d busy:%d\n",QDateTime::QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),split_,requested_split_,busy_split_);
  if (busy_split_) return;
  if (tci_timer5_->isActive()) mysleep5(0);
  busy_split_ = true;
  const QString cmd = CmdSplitEnable + SmDP + rx_ + SmCM + (requested_split_ ? "true" : "false") + SmTZ;
  sendTextMessage(cmd);
  mysleep5(500);
  busy_split_ = false;
  if (requested_split_ == split_) update_split (split_);
}

void TCITransceiver::rig_power (bool on)
{
  TRACE_CAT ("TCITransceiver", on << state ());
  printf("%s TCI rig_power:%d _power_:%d\n",QDateTime::QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),on,_power_);
  if (on != _power_) {
    if (on) {
      const QString cmd = CmdStart + SmTZ;
      sendTextMessage(cmd);
    } else {
      const QString cmd = CmdStop + SmTZ;
      sendTextMessage(cmd);
    }
  }
}

void TCITransceiver::stream_audio (bool on)
{
  TRACE_CAT ("TCITransceiver", on << state ());
  if (on != stream_audio_ && tci_Ready) {
    requested_stream_audio_ = on;
    if (on) {
      const QString cmd = CmdAudioStart + SmDP + rx_ + SmTZ;
      sendTextMessage(cmd);
    } else {
      const QString cmd = CmdAudioStop + SmDP + rx_ + SmTZ;
      sendTextMessage(cmd);
    }
  }
}

void TCITransceiver::do_audio (bool on)
{
  TRACE_CAT ("TCITransceiver", on << state ());
  receive_discontinuity (on ? JttyReceiveReason::SourceChanged : m_inputStopReason);
  if (on) {
    QMutexLocker lock {&dec_data_mutex ()};
    m_bufferPos = 0;
    if (!dec_data_input_blocked ()) clear ();
  }
  audio_ = on;
  if (!on)
    {
      m_inputStopReason = JttyReceiveReason::MonitorStopped;
      if (m_receivePolicy == ReceivePolicy::ContinuousJtty)
        Q_EMIT continuousReceptionStopped (m_jttyPublisher.mailbox ());
    }
}

void TCITransceiver::do_period (double period)
{
  TRACE_CAT ("TCITransceiver", period << state ());
  if (m_period != period)
    {
      QMutexLocker lock {&dec_data_mutex ()};
      m_period = period;
      if (m_receivePolicy == ReceivePolicy::Timed && !dec_data_input_blocked ()) clear ();
    }
}

void TCITransceiver::do_receive_policy (ReceivePolicy policy)
{
  if (policy == m_receivePolicy) return;
  bool const endingContinuous = m_receivePolicy == ReceivePolicy::ContinuousJtty;
  receive_discontinuity (JttyReceiveReason::ModeChanged);
  m_receivePolicy = policy;
  m_downsampleState.fill (0);
  QMutexLocker lock {&dec_data_mutex ()};
  clear ();
  if (endingContinuous) Q_EMIT continuousReceptionStopped (m_jttyPublisher.mailbox ());
}

void TCITransceiver::do_receive_context (quint64 context)
{
  if (context == m_receiveContext) return;
  receive_discontinuity (JttyReceiveReason::SourceChanged);
  m_receiveContext = context;
  m_jttyPublisher.setContext (context);
}

void TCITransceiver::receive_discontinuity (JttyReceiveReason reason)
{
  if (m_receivePolicy != ReceivePolicy::ContinuousJtty) return;
  bool notify = false;
  if (m_jttyPublisher.active () && m_bufferPos)
    {
      qint32 inputFrames = m_bufferPos - m_bufferPos % m_downSampleFactor;
      qint32 outputFrames = inputFrames / m_downSampleFactor;
      if (m_downSampleFactor > 1 && inputFrames)
        fil4_state_ (m_buffer.data (), &inputFrames, m_jttyOutput.data (),
                     &outputFrames, m_downsampleState.data ());
      notify = m_jttyPublisher.append (m_jttyOutput.data (), outputFrames);
    }
  notify = m_jttyPublisher.end (reason) || notify;
  m_bufferPos = 0;
  m_downsampleState.fill (0);
  if (notify) Q_EMIT continuousAudioAvailable (m_jttyPublisher.mailbox ());
}

void TCITransceiver::do_volume (qreal volume)
{
  rxAtten = volume;
}


void TCITransceiver::do_txvolume (qreal txvolume)
{
  txAtten = txvolume;
}

void TCITransceiver::do_blocksize (qint32 blocksize)
{
  TRACE_CAT ("TCITransceiver", blocksize << state ());
  if (blocksize <= 0 || size_t (blocksize) > max_buffer_size
      || blocksize == m_samplesPerFFT) return;
  // Finish partial continuous audio before changing the block's write boundary.
  receive_discontinuity (JttyReceiveReason::SourceChanged);
  m_bufferPos = 0;
  m_samplesPerFFT = blocksize;
}

void TCITransceiver::do_ptt (bool on)
{
  TRACE_CAT ("TCITransceiver", on << state ());
  if (use_for_ptt_) {
    if (on != PTT_) {
      if (!inConnected && !error_.isEmpty()) throw error {error_};
      else if (busy_PTT_ || !tci_Ready || !_power_) return;
      else busy_PTT_ = true;
      requested_PTT_ = on;
      if (ESDR3) {
        const QString cmd = CmdTrx + SmDP + rx_ + SmCM + (on ? "true" : "false") + SmCM + "tci"+ SmTZ;
        sendTextMessage(cmd);
      } else {
        const QString cmd = CmdTrx + SmDP + rx_ + SmCM + (on ? "true" : "false") + SmTZ;
        sendTextMessage(cmd);
      }
      mysleep3(1000);
      busy_PTT_ = false;
      if (requested_PTT_ == PTT_) {
        update_PTT(PTT_);
        if (PTT_ && do_snr_) {
          update_level (-54);
        } else {
          power_ = 0;
          if (do_pwr_) update_power (0);
          swr_ = 0;
          if (do_pwr_) update_swr (0);
        }
      } else {
        printf("%s TCI failed set ptt %d->%d\n",QDateTime::QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),PTT_,requested_PTT_);
        error_ = tr ("TCI failed to set ptt");
        tci_Ready = false;
        throw error {tr ("TCI failed to set ptt")};
      }
    } else update_PTT(on);
  }
  else
  {
    TRACE_CAT ("TCITransceiver", "TCI should use PTT via CAT");
    throw error {tr ("TCI should use PTT via CAT")};
  }
}

void TCITransceiver::do_frequency (Frequency f, MODE m, bool no_ignore)
{
  qDebug() << no_ignore;
  TRACE_CAT ("TCITransceiver", f << state ());
  auto f_string = frequency_to_string (f);
  if (busy_rx_frequency_) {
    return;
  } else {
    requested_rx_frequency_ = f_string;
    requested_mode_ = map_mode (m);
  }
  if (tci_Ready && _power_) {
    if ((rx_frequency_ != requested_rx_frequency_)) {
      busy_rx_frequency_ = true;
      band_change = TciProtocol::frequency_difference_exceeds (
        string_to_frequency (rx_frequency_), f, band_change_threshold_hz);
      const QString cmd = CmdVFO + SmDP + rx_ + SmCM + "0" + SmCM + requested_rx_frequency_ + SmTZ;
      if(f > 100000 && f< 250000000000) sendTextMessage(cmd);
      mysleep7(2000);
      band_change2 = TciProtocol::frequency_difference_exceeds (
        string_to_frequency (rx_frequency_), f, band_change_threshold_hz);
      if (!band_change2) update_rx_frequency (f);
      else {
        printf("%s TCI failed set rxfreq:%s->%s\n",QDateTime::QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),rx_frequency_.toStdString().c_str(),requested_rx_frequency_.toStdString().c_str());
        error_ = tr ("TCI failed set rxfreq");
        CAT_TRACE("TCI failed set rxfreq.  Rx freq is:");
        CAT_TRACE(rx_frequency_);
        CAT_TRACE("TCI failed set rxfreq.  Requested Rx freq is:");
        CAT_TRACE(requested_rx_frequency_);
        printf("rx_frequency is %s and requested_rx_frequency is %s\n",rx_frequency_.toStdString().c_str(),requested_rx_frequency_.toStdString().c_str());
        tci_Ready = false;
        throw error {tr ("TCI failed set rxfreq")};
      }
      busy_rx_frequency_ = false;
    } else update_rx_frequency (string_to_frequency (rx_frequency_));

    if (!requested_mode_.isEmpty() && requested_mode_ != mode_ && !busy_mode_) {
      busy_mode_ = true;
      sendTextMessage(mode_to_command(requested_mode_));
      mysleep8(1000);
      if (requested_mode_.isEmpty() || requested_mode_ == mode_) update_mode (m);
      else {
        printf("%s TCI failed set mode %s->%s",QDateTime::QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),mode_.toStdString().c_str(),requested_mode_.toStdString().c_str());
        error_ = tr ("TCI failed set mode");
      }
      busy_mode_ = false;
    }
  } else {
    update_rx_frequency (f);
    update_mode (m);
  }
}

void TCITransceiver::do_tx_frequency (Frequency tx, MODE mode, bool no_ignore)
{
  TRACE_CAT ("%s TCITransceiver", tx << state ());
  auto f_string = frequency_to_string (tx);
  if (tci_Ready && busy_other_frequency_ && no_ignore) {
      CAT_TRACE("TCI do_txfrequency critical no_ignore set tx vfo will be missed\n");
    printf("%s TCI do_txfrequency critical no_ignore set tx vfo will be missed\n",QDateTime::QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str());
  }
  if (busy_other_frequency_) return;
  requested_other_frequency_ = f_string;
  requested_mode_ = map_mode (mode);
  if (tx) {
    requested_split_ = true;
    if (tci_Ready && _power_) {
      if (band_change && !tci_timer2_->isActive()) {
        if (!HPSDR) {
          mysleep2(210);
        } else {
          mysleep2(2000);
        }
      } else {
        if (tci_timer2_->isActive()) mysleep2(0);
      }
      if (requested_split_ != split_) rig_split();
      else update_split (split_);
      if (other_frequency_ != requested_other_frequency_) {
        busy_other_frequency_ = true;
        printf("%s TCI VFO1 command sent\n",QDateTime::QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str());
        const QString cmd = CmdVFO + SmDP + rx_ + SmCM + "1" + SmCM + requested_other_frequency_ + SmTZ;
        if(tx > 100000 && tx < 250000000000) sendTextMessage(cmd);
        mysleep2(1000);
        other_band_change = TciProtocol::frequency_difference_exceeds (
          string_to_frequency (other_frequency_), tx, band_change_threshold_hz);
        if (!other_band_change) update_other_frequency (tx);
        else {
          printf("%s TCI failed set txfreq:%s->%s\n",QDateTime::QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),other_frequency_.toStdString().c_str(),requested_other_frequency_.toStdString().c_str());
          CAT_TRACE("TCI failed set txfreq");
        }
        busy_other_frequency_ = false;
      } else update_other_frequency (string_to_frequency (other_frequency_));

    } else {
      update_split (requested_split_);
      update_other_frequency (tx);
    }
  }
  else {
    requested_split_ = false;
    requested_other_frequency_ = "";
    if (tci_Ready && _power_) {
      if (band_change) {
        mysleep2(2000);
        if (!HPSDR) mysleep2(200);
      }
      if (tci_timer2_->isActive()) mysleep2(0);
      if (requested_split_ != split_) rig_split();
      else update_split (split_);
      update_other_frequency (tx);
    } else {
      update_split (requested_split_);
      update_other_frequency (tx);
    }
  }
}

void TCITransceiver::do_mode (MODE m)
{
  TRACE_CAT ("TCITransceiver", m << state ());
  auto m_string = map_mode (m);
  if (requested_mode_ != m_string) requested_mode_ = m_string;
  if (!requested_mode_.isEmpty() && mode_ != requested_mode_ && !busy_mode_) {
    busy_mode_ = true;
    sendTextMessage(mode_to_command(requested_mode_));
        mysleep8(1000);
    if (requested_mode_ == mode_) update_mode (m);
    else {
      printf("%s TCI failed set mode %s->%s",QDateTime::QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),mode_.toStdString().c_str(),requested_mode_.toStdString().c_str());
      error_ = tr ("TCI failed set mode");
    }
    busy_mode_ = false;
  }
}

void TCITransceiver::do_poll ()
{
  if (!error_.isEmpty()) {tci_Ready = false; throw error {error_};}
  else if (!tci_Ready) throw error {tr ("TCI could not be opened")};
  update_rx_frequency (string_to_frequency (rx_frequency_));
  update_split(split_);
  if (state ().split ()) {
    if (other_frequency_ == requested_other_frequency_) update_other_frequency (string_to_frequency (other_frequency_));
    else if (!busy_rx_frequency_) do_tx_frequency(string_to_frequency (requested_other_frequency_),get_mode(true),false);
  }
  update_mode (get_mode());
  if (do_pwr_ && PTT_) {update_power (power_ * 100); update_swr (swr_*10);}
  if (do_snr_ && !PTT_) {
    update_level (level_);
    if(!ESDR3) {
      const QString cmd = CmdSmeter + SmDP + rx_ + SmCM + "0" +  SmTZ;
      sendTextMessage(cmd);
    }
  }
}

auto TCITransceiver::get_mode (bool requested) -> MODE
{
  MODE m {UNK};
  if (requested) {
    if ("am" == requested_mode_)
    {
      m = AM;
    }
    else if ("cw" == requested_mode_)
    {
      m = CW;
    }
    else if ("wfm" == requested_mode_)
    {
      m = FM;
    }
    else if ("nfm" == requested_mode_)
    {
      m = DIG_FM;
    }
    else if ("lsb" == requested_mode_)
    {
      m = LSB;
    }
    else if ("usb" == requested_mode_)
    {
      m = USB;
    }
    else if ("digl" == requested_mode_)
    {
      m = DIG_L;
    }
    else if ("digu" == requested_mode_)
    {
      m = DIG_U;
    }
  } else {
    if ("am" == mode_)
    {
      m = AM;
    }
    else if ("cw" == mode_)
    {
      m = CW;
    }
    else if ("wfm" == mode_)
    {
      m = FM;
    }
    else if ("nfm" == mode_)
    {
      m = DIG_FM;
    }
    else if ("lsb" == mode_)
    {
      m = LSB;
    }
    else if ("usb" == mode_)
    {
      m = USB;
    }
    else if ("digl" == mode_)
    {
      m = DIG_L;
    }
    else if ("digu" == mode_)
    {
      m = DIG_U;
    }
  }
  return m;
}

QString TCITransceiver::mode_to_command (QString m_string) const
{
  const QString cmd = CmdMode + SmDP + rx_ + SmCM + m_string + SmTZ;
  return cmd;
}

QString TCITransceiver::frequency_to_string (Frequency f) const
{
  // Frequency is an integer number of hertz, so decimal conversion is locale-independent.
  auto f_string = QString {}.setNum(f);
  printf ("frequency_to_string3 |%s|\n",f_string.toStdString().c_str());
  return f_string;
}

auto TCITransceiver::string_to_frequency (QString const& s) const -> Frequency
{
  Frequency frequency;
  if (!TciProtocol::parse_frequency (s, &frequency))
    {
      throw error {tr ("TCI sent an invalid VFO frequency")};
    }
  return frequency;
}

void TCITransceiver::mysleep1 (int ms)
{
  if (ms) tci_timer1_->start(ms);
  tci_loop1_->exec();
  if (tci_timer1_->isActive() && tci_Ready) tci_timer1_->stop();
}
void TCITransceiver::mysleep2 (int ms)
{
  if (ms) tci_timer2_->start(ms);
  tci_loop2_->exec();
  if (tci_timer2_->isActive()) tci_timer2_->stop();
}
void TCITransceiver::mysleep3 (int ms)
{
  if (ms) tci_timer3_->start(ms);
  tci_loop3_->exec();
  if (tci_timer3_->isActive()) tci_timer3_->stop();
}
void TCITransceiver::mysleep4 (int ms)
{
  if (ms) tci_timer4_->start(ms);
  tci_loop4_->exec();
  if (tci_timer4_->isActive()) tci_timer4_->stop();
}
void TCITransceiver::mysleep5 (int ms)
{
  if((tci_loop5_ && (tci_loop5_->isRunning())) || (tci_timer5_ && tci_timer5_->isActive())) return;
  if (ms) tci_timer5_->start(ms);
  tci_loop5_->exec();
  if (tci_timer5_->isActive()) tci_timer5_->stop();
}
void TCITransceiver::mysleep6 (int ms)
{
  if (ms) tci_timer6_->start(ms);
  tci_loop6_->exec();
  if (tci_timer6_->isActive()) tci_timer6_->stop();
}
void TCITransceiver::mysleep7 (int ms)
{
    if (ms) tci_timer7_->start(ms);
    tci_loop7_->exec();
    if (tci_timer7_->isActive()) tci_timer7_->stop();
}
void TCITransceiver::mysleep8 (int ms)
{
    if (ms) tci_timer8_->start(ms);
    tci_loop8_->exec();
    if (tci_timer8_->isActive()) tci_timer8_->stop();
}
// Modulator part

void TCITransceiver::do_modulator_start (TxEvidence::TxRequest const& request)
{
  // Time according to this computer which becomes our base time
  qint64 ms0 = QDateTime::currentMSecsSinceEpoch() % 86400000;
  qDebug() << "ModStart" << QDateTime::QDateTime::currentDateTimeUtc().toString("hh:mm:ss.sss");
  unsigned mstr = ms0 % int(1000.0*m_period); // ms into the nominal Tx start time
  if (m_state != Idle) {
    throw error {tr ("TCI modulator not Idle")};
  }
  m_quickClose = false;
  m_txMode = request.mode;
  m_jttyLastProgress = {};
  m_symbolsLength = request.symbols_length;
  m_isym0 = std::numeric_limits<unsigned>::max (); // big number
  m_frequency0 = 0.;
  m_phi = 0.;
  m_addNoise = request.snr_db < 0.;
  m_nsps = request.frames_per_symbol;
  m_trfrequency = request.frequency_hz;
  m_amp = std::numeric_limits<qint16>::max ();
  m_toneSpacing = request.tone_spacing;
  m_bFastMode=request.fast_mode;
  m_TRperiod=request.tr_period_s;
  m_tuning=request.tuning;
  m_cwId=request.cw_id;
  unsigned delay_ms=1000;

  if((request.mode=="FT8" and m_nsps==1920) or (request.mode=="FST4" and m_nsps==720)) delay_ms=500;  //FT8, FST4-15
  if((request.mode=="FT8" and m_nsps==1024)) delay_ms=400;            //SuperFox Qary Polar Code transmission
  if(request.mode=="Q65" and m_nsps<=3600) delay_ms=500;              //Q65-15 and Q65-30
  if(request.mode=="FT4") delay_ms=300;                               //FT4

  // noise generator parameters
  if (m_addNoise) {
    m_snr = qPow (10.0, 0.05 * (request.snr_db - 6.0));
    m_fac = 3000.0;
    if (m_snr > 1.0) m_fac = 3000.0 / m_snr;
  }

  // round up to an exact portion of a second that allows for startup delays
  auto mstr2 = mstr - delay_ms;
  if (mstr <= delay_ms) {
    m_ic = 0;
  } else {
    m_ic = mstr2 * (audioSampleRate / 1000);
  }

  m_silentFrames = 0;
  // calculate number of silent frames to send
  if (m_ic == 0 && request.synchronize && !request.tuning)	{
    m_silentFrames = audioSampleRate / (1000 / delay_ms) - (mstr * (audioSampleRate / 1000));
  }
  m_state = (request.synchronize && m_silentFrames) ?
                Synchronizing : Active;
  m_txStartSnapshot.session_id = request.session_id;
  m_txStartSnapshot.generation = request.generation;
  m_txStartSnapshot.mode = m_txMode;
  m_txStartSnapshot.sample_rate_hz = int (audioSampleRate);
  m_txStartSnapshot.committed_end_sample = bounded_source_frames (request.tuning);
  m_txStartSnapshot.target_known = m_txStartSnapshot.committed_end_sample >= 0;
  m_txStartSnapshot.diagnostic = tr ("TCI source commitment; playout evidence is protocol-send dead reckoning, not DAC confirmation");
  ++m_tciBackendStartSequence;
  m_tciSuccessfullyWrittenFrames = 0;
  m_tciStartMsecs = QDateTime::currentMSecsSinceEpoch ();
  m_tciLastReportMsecs = m_tciStartMsecs;
  m_tciFinalSnapshotEmitted = false;
  printf("%s TCI modulator startdelay_ms=%d ASR=%d mstr=%d mstr2=%d m_ic=%d s_Frames=%lld synchronize=%d m_tuning=%d State=%d\n",QDateTime::QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),delay_ms,audioSampleRate,mstr,mstr2,m_ic,m_silentFrames,request.synchronize,m_tuning,m_state);
  if (m_txMode == "JTTY" && !m_jttyDrainTimer->isActive ()) m_jttyDrainTimer->start ();
  Q_EMIT tci_mod_active(m_state != Idle);
  Q_EMIT txSourceCommitted (m_txStartSnapshot);
  emit_tci_playout_snapshot (true, true);
}

void TCITransceiver::do_tune (bool newState)
{
  m_tuning = newState;
  if (!m_tuning) do_modulator_stop (true);
}

void TCITransceiver::do_modulator_stop (bool quick)
{
  m_quickClose = quick;
  if(m_state != Idle) {
    m_state = Idle;
    Q_EMIT tci_mod_active(m_state != Idle);
  }
  if (m_jttyDrainTimer->isActive ()) m_jttyDrainTimer->stop ();
  emit_tci_playout_snapshot (false, true);
  tx_audio_ = false;
}

qint64 TCITransceiver::bounded_source_frames (bool tuning) const
{
  if (tuning || m_txMode == "JTTY" || m_txMode == "CW" || !m_cwId.isEmpty ()) return -1;

  qint64 i1 = qint64 (m_symbolsLength * 4.0 * m_nsps);
  if (m_bFastMode)
    {
      i1 = qint64 (m_TRperiod * 48000.0 - 24000.0);
    }
  return TxEvidence::boundedCommittedEndSample (m_silentFrames, m_ic, i1);
}

void TCITransceiver::emit_tci_playout_snapshot (bool start_event, bool force)
{
  qint64 const now = QDateTime::currentMSecsSinceEpoch ();
  bool const final = m_state == Idle;
  if (!start_event && !force && now - m_tciLastReportMsecs < 1000) return;
  if (final && m_tciFinalSnapshotEmitted) return;

  TxEvidence::TxRawPlayoutSnapshot snapshot;
  snapshot.tier = TxEvidence::TxPlayoutTier::DeadReckoning;
  snapshot.backend_start_sequence = m_tciBackendStartSequence;
  snapshot.start_event = start_event;
  snapshot.available = inConnected;
  snapshot.state = final ? TxEvidence::TxBackendState::Idle : TxEvidence::TxBackendState::Active;
  snapshot.elapsed_usecs = (now - m_tciStartMsecs) * 1000;
  snapshot.successfully_written_frames = m_tciSuccessfullyWrittenFrames;
  snapshot.sample_rate_hz = int (audioSampleRate);
  snapshot.report_interval_ms = int (now - m_tciLastReportMsecs);
  snapshot.diagnostic = tr ("TCI WebSocket send progress; no radio DAC or RF playback confirmation");
  if (m_txMode == "JTTY")
    {
      auto const progress = m_txAudioQueue.progress ();
      snapshot.source_served_frames = progress.served_samples;
      snapshot.source_total_frames = progress.total_samples;
    }
  Q_EMIT rawTxPlayoutSnapshot (snapshot);
  m_tciLastReportMsecs = now;
  if (final) m_tciFinalSnapshotEmitted = true;
}

quint16 TCITransceiver::readAudioData (float * data, qint32 maxSize, quint32 channels, qreal txAtten)
{
  Q_ASSERT (channels == 1u || channels == 2u);
  Q_ASSERT (maxSize >= 0 && !(static_cast<quint32> (maxSize) % channels));

  double toneFrequency=1500.0;
  if(m_nsps==6) {
    toneFrequency=1000.0;
    m_trfrequency=1000.0;
    m_frequency0=1000.0;
  }
  if(maxSize==0) return 0;

  qreal newVolume = pow(2.22222 * (45 - txAtten) * 0.01,2);

  qint64 numFrames (maxSize/channels);
  float * samples (reinterpret_cast<float *> (data));
  float * end (samples + numFrames * channels);
  qint64 framesGenerated (0);

  switch (m_state)
  {
    case Synchronizing:
    {
      if (m_silentFrames)	{  // send silence up to first second
        framesGenerated = qMin (m_silentFrames, numFrames);
        for ( ; samples != end; samples = load (0, channels, samples)) { // silence
        }
        m_silentFrames -= framesGenerated;
        return framesGenerated * channels;
      }
      m_state = Active;
      Q_EMIT tci_mod_active(m_state != Idle);
      m_cwLevel = false;
      m_ramp = 0;		// prepare for CW wave shaping
    }
      // fall through

    case Active:
    {
      if (m_txMode == "JTTY" && !m_tuning)
        {
          return readJttyAudioData (data, maxSize, channels, txAtten);
        }

      unsigned int isym=0;
      qint16 sample=0;
      if(!m_tuning) isym=m_ic/(4.0*m_nsps);          // Actual fsample=48000
      bool slowCwId=((isym >= m_symbolsLength) && !m_cwId.isEmpty ());
      m_nspd=2560;                 // 22.5 WPM

      if(m_TRperiod > 16.0 && slowCwId) {     // Transmit CW ID?
        m_dphi = m_twoPi*m_trfrequency/audioSampleRate;
        unsigned ic0 = m_symbolsLength * 4 * m_nsps;
        unsigned j(0);

        while (samples != end) {
          j = (m_ic - ic0)/m_nspd + 1; // symbol of this sample
          if (j == 0 || j > static_cast<unsigned> (m_cwId.size ()))
            {
              m_state = Idle;
              Q_EMIT tci_mod_active(m_state != Idle);
              return framesGenerated * channels;
            }
          bool level {bool (m_cwId.at (j - 1))};
          m_phi += m_dphi;
          if (m_phi > m_twoPi) m_phi -= m_twoPi;
          sample=0;
          float amp=32767.0;
          float x=0.0;
          if(m_ramp!=0) {
            x=qSin(float(m_phi));
            if(SOFT_KEYING) {
              amp=qAbs(qint32(m_ramp));
              if(amp>32767.0) amp=32767.0;
            }
            sample=round(newVolume * amp * x);
          }
          samples = load (postProcessSample (sample), channels, samples);
          ++framesGenerated;
          ++m_ic;

          // adjust ramp
          if ((m_ramp != 0 && m_ramp != std::numeric_limits<qint16>::min ()) || level != m_cwLevel) {
            // either ramp has terminated at max/min or direction has changed
            m_ramp += RAMP_INCREMENT; // ramp
          }
          m_cwLevel = level;
        }
        return framesGenerated * channels;
      } //End of code for CW ID

      double const baud (12000.0 / m_nsps);
      // fade out parameters (no fade out for tuning)
      unsigned int i0,i1;
      if(m_tuning) {
        i1 = i0 =  (m_bFastMode ? 999999 : 9999) * m_nsps;
      } else {
        i0=(m_symbolsLength - 0.017) * 4.0 * m_nsps;
        i1= m_symbolsLength * 4.0 * m_nsps;
      }
      if(m_bFastMode and !m_tuning) {
        i1=m_TRperiod*48000.0 - 24000.0;
        i0=i1-816;
      }

      sample=0;
      for (unsigned i = 0; i < numFrames && m_ic <= i1; ++i) {
        isym=0;
        if(!m_tuning and m_TRperiod!=3.0) isym=m_ic/(4.0*m_nsps);   //Actual fsample=48000
        if(m_bFastMode) isym=isym%m_symbolsLength;
        if (isym != m_isym0 || m_trfrequency != m_frequency0) {
          if(itone[0]>=100) {
            m_toneFrequency0=itone[0];
          } else {
            if(m_toneSpacing==0.0) {
              m_toneFrequency0=m_trfrequency + itone[isym]*baud;
            } else {
              m_toneFrequency0=m_trfrequency + itone[isym]*m_toneSpacing;
            }
          }
          m_dphi = m_twoPi * m_toneFrequency0 / audioSampleRate;
          m_isym0 = isym;
          m_frequency0 = m_trfrequency;         //???
        }

        int j=m_ic/480;
        if(m_fSpread>0.0 and j!=m_j0) {
#if QT_VERSION >= QT_VERSION_CHECK(5, 15, 0)
          float x1=QRandomGenerator::global ()->generateDouble ();
          float x2=QRandomGenerator::global ()->generateDouble ();
#else
          float x1=(float)qrand()/RAND_MAX;
          float x2=(float)qrand()/RAND_MAX;
#endif
          toneFrequency = m_toneFrequency0 + 0.5*m_fSpread*(x1+x2-1.0);
          m_dphi = m_twoPi * toneFrequency / audioSampleRate;
          m_j0=j;
        }

        m_phi += m_dphi;
        if (m_phi > m_twoPi) m_phi -= m_twoPi;
        //ramp for first tone
        if (m_ic==0) m_amp = m_amp * 0.008144735;
        if (m_ic > 0 and  m_ic < 191) m_amp = m_amp / 0.975;
        //ramp for last tone
        if (m_ic > i0) m_amp = 0.99 * m_amp;
        if (m_ic > i1) m_amp = 0.0;
        sample=qRound(newVolume * m_amp*qSin(m_phi));

        //transmit from a precomputed FT8 wave[] array:
        if(!m_tuning and (m_toneSpacing < 0.0)) {
          m_amp=32767.0;
          sample=qRound(newVolume * m_amp*foxcom_.wave[m_ic]);
        }
        samples = load (postProcessSample (sample), channels, samples);
        ++framesGenerated;
        ++m_ic;
      }

      if (m_amp == 0.0) { // TODO G4WJS: compare double with zero might not be wise
        if (m_cwId.isEmpty ()) {
          // no CW ID to send
          m_state = Idle;
          Q_EMIT tci_mod_active(m_state != Idle);
          return framesGenerated * channels;
        }
        m_phi = 0.0;
      }

      m_frequency0 = m_trfrequency;
      // done for this chunk - continue on next call
      if (samples != end && framesGenerated) {
      }
      while (samples != end) { // pad block with silence
        samples = load (0, channels, samples);
        ++framesGenerated;
      }
      return framesGenerated * channels;
    }
      // fall through

    case Idle:
      while (samples != end) samples = load (0, channels, samples);
  }

  Q_ASSERT (Idle == m_state);
  return 0;
}

quint16 TCITransceiver::readJttyAudioData (float * data, qint32 maxSize, quint32 channels, qreal txAtten)
{
  Q_ASSERT (channels == 1u || channels == 2u);
  Q_ASSERT (maxSize >= 0 && !(static_cast<quint32> (maxSize) % channels));

  if(maxSize==0) return 0;

  qreal const newVolume = pow(2.22222 * (45 - txAtten) * 0.01,2);
  qint64 const numFrames (maxSize/channels);
  float * samples (reinterpret_cast<float *> (data));
  qint64 framesGenerated (0);

  // JTTY is pre-rendered mono PCM shared with the soundcard path. When the FIFO
  // runs dry we keep sending silence until the drain guard proves the last real
  // sample has cleared the backend.
  for (qint64 i = 0; i < numFrames; ++i)
    {
      qint32 sample = qRound (newVolume * m_txAudioQueue.pullSample (m_jttyDrainGuard));
      if (sample > std::numeric_limits<qint16>::max ()) sample = std::numeric_limits<qint16>::max ();
      if (sample < std::numeric_limits<qint16>::min ()) sample = std::numeric_limits<qint16>::min ();
      samples = load (postProcessSample (qint16 (sample)), channels, samples);
      ++framesGenerated;
    }

  return framesGenerated * channels;
}

qint16 TCITransceiver::postProcessSample (qint16 sample) const
{
  if (m_addNoise) {  // Test frame, we'll add noise
    qint32 s = m_fac * (gran () + sample * m_snr / 32768.0);
    if (s > std::numeric_limits<qint16>::max ()) {
      s = std::numeric_limits<qint16>::max ();
    }
    if (s < std::numeric_limits<qint16>::min ()) {
      s = std::numeric_limits<qint16>::min ();
    }
    sample = s;
  }
  return sample;
}
