#include "Configuration.hpp"

//
// Read me!
//
// This file defines a configuration dialog with the user. The general
// strategy is to expose agreed  configuration parameters via a custom
// interface (See  Configuration.hpp). The state exposed  through this
// public   interface  reflects   stored  or   derived  data   in  the
// Configuration::impl object.   The Configuration::impl  structure is
// an implementation of the PIMPL (a.k.a.  Cheshire Cat or compilation
// firewall) implementation hiding idiom that allows internal state to
// be completely removed from the public interface.
//
// There  is a  secondary level  of parameter  storage which  reflects
// current settings UI  state, these parameters are not  copied to the
// state   store  that   the  public   interface  exposes   until  the
// Configuration:impl::accept() operation is  successful. The accept()
// operation is  tied to the settings  OK button. The normal  and most
// convenient place to store this intermediate settings UI state is in
// the data models of the UI  controls, if that is not convenient then
// separate member variables  must be used to store that  state. It is
// important for the user experience that no publicly visible settings
// are changed  while the  settings UI are  changed i.e.  all settings
// changes   must    be   deferred   until   the    "OK"   button   is
// clicked. Conversely, all changes must  be discarded if the settings
// UI "Cancel" button is clicked.
//
// There is  a complication related  to the radio interface  since the
// this module offers  the facility to test the  radio interface. This
// test means  that the  public visibility to  the radio  being tested
// must be  changed.  To  maintain the  illusion of  deferring changes
// until they  are accepted, the  original radio related  settings are
// stored upon showing  the UI and restored if the  UI is dismissed by
// canceling.
//
// It  should be  noted that  the  settings UI  lives as  long as  the
// application client that uses it does. It is simply shown and hidden
// as it  is needed rather than  creating it on demand.  This strategy
// saves a  lot of  expensive UI  drawing at the  expense of  a little
// storage and  gives a  convenient place  to deliver  settings values
// from.
//
// Here is an overview of the high level flow of this module:
//
// 1)  On  construction the  initial  environment  is initialized  and
// initial   values  for   settings  are   read  from   the  QSettings
// database. At  this point  default values for  any new  settings are
// established by  providing a  default value  to the  QSettings value
// queries. This should be the only place where a hard coded value for
// a   settings  item   is   defined.   Any   remaining  one-time   UI
// initialization is also done. At the end of the constructor a method
// initialize_models()  is called  to  load the  UI  with the  current
// settings values.
//
// 2) When the settings UI is displayed by a client calling the exec()
// operation, only temporary state need be stored as the UI state will
// already mirror the publicly visible settings state.
//
// 3) As  the user makes  changes to  the settings UI  only validation
// need be  carried out since the  UI control data models  are used as
// the temporary store of unconfirmed settings.  As some settings will
// depend  on each  other a  validate() operation  is available,  this
// operation implements a check of any complex multi-field values.
//
// 4) If the  user discards the settings changes by  dismissing the UI
// with the  "Cancel" button;  the reject()  operation is  called. The
// reject() operation calls initialize_models()  which will revert all
// the  UI visible  state  to  the values  as  at  the initial  exec()
// operation.  No   changes  are  moved   into  the  data   fields  in
// Configuration::impl that  reflect the  settings state  published by
// the public interface (Configuration.hpp).
//
// 5) If  the user accepts the  settings changes by dismissing  the UI
// with the "OK" button; the  accept() operation is called which calls
// the validate() operation  again and, if it passes,  the fields that
// are used  to deliver  the settings  state are  updated from  the UI
// control models  or other temporary  state variables. At the  end of
// the accept()  operation, just  before hiding  the UI  and returning
// control to the caller; the new  settings values are stored into the
// settings database by a call to the write_settings() operation, thus
// ensuring that  settings changes are  saved even if  the application
// crashes or is subsequently killed.
//
// 6)  On  destruction,  which   only  happens  when  the  application
// terminates,  the settings  are saved  to the  settings database  by
// calling the  write_settings() operation. This is  largely redundant
// but is still done to save the default values of any new settings on
// an initial run.
//
// To add a new setting:
//
// 1) Update the UI with the new widget to view and change the value.
//
// 2)  Add  a member  to  Configuration::impl  to store  the  accepted
// setting state. If the setting state is dynamic; add a new signal to
// broadcast the setting value.
//
// 3) Add a  query method to the  public interface (Configuration.hpp)
// to access the  new setting value. If the settings  is dynamic; this
// step  is optional  since  value  changes will  be  broadcast via  a
// signal.
//
// 4) Add a forwarding operation to implement the new query (3) above.
//
// 5)  Add a  settings read  call to  read_settings() with  a sensible
// default value. If  the setting value is dynamic, add  a signal emit
// call to broadcast the setting value change.
//
// 6) Add  code to  initialize_models() to  load the  widget control's
// data model with the current value.
//
// 7) If there is no convenient data model field, add a data member to
// store the proposed new value. Ensure  this member has a valid value
// on exit from read_settings().
//
// 8)  Add  any  required  inter-field validation  to  the  validate()
// operation.
//
// 9) Add code to the accept()  operation to extract the setting value
// from  the  widget   control  data  model  and  load   it  into  the
// Configuration::impl  member  that  reflects  the  publicly  visible
// setting state. If  the setting value is dynamic; add  a signal emit
// call to broadcast any changed state of the setting.
//
// 10) Add  a settings  write call  to save the  setting value  to the
// settings database.
//

#include <stdexcept>
#include <iterator>
#include <algorithm>
#include <functional>
#include <limits>
#include <cmath>

#include <QApplication>
#include <QCursor>
#include <QMetaType>
#include <QList>
#include <QPair>
#include <QVariant>
#include <QSettings>
#include <QAudio>
#include <QAudioDeviceInfo>
#include <QAudioInput>
#include <QAudioOutput>
#include <QSound>
#include <QDialog>
#include <QAction>
#include <QKeyEvent>
#include <QScreen>
#include <QShowEvent>
#include <QTabBar>
#include <QWindow>
#include <QFileDialog>
#include <QDir>
#include <QTemporaryFile>
#include <QFormLayout>
#include <QItemSelectionModel>
#include <QString>
#include <QStringList>
#include <QStringListModel>
#include <QLineEdit>
#include <QRegularExpression>
#include <QRegularExpressionValidator>
#include <QKeyEvent>
#include <QIntValidator>
#include <QDoubleValidator>
#include <QLocale>
#include <QThread>
#include <QTimer>
#include <QStandardPaths>
#include <QFont>
#include <QFontDialog>
#include <QComboBox>
#include <QScopedValueRollback>
#include <QScopedPointer>
#include <QSignalBlocker>
#include <QNetworkInterface>
#include <QHostInfo>
#include <QHostAddress>
#include <QStandardItem>
#include <QDebug>
#include <QDateTimeEdit>
#include <QJsonObject>
#include <QJsonDocument>
#include <QJsonArray>
#include <QSerialPortInfo>
#include <QItemSelectionModel>
#include <QMenu>
#include <QFrame>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QSet>
#include <vector>
#include <utility>
#include <iostream>

#include "pimpl_impl.hpp"
#include "Logger.hpp"
#include "PerformanceTrace.hpp"
#include "Transceiver/TxInhibitTransceiver.hpp"
#include "qt_helpers.hpp"
#include "MetaDataRegistry.hpp"
#include "SettingsGroup.hpp"
#include "widgets/FrequencyLineEdit.hpp"
#include "widgets/FrequencyDeltaLineEdit.hpp"
#include "item_delegates/CandidateKeyFilter.hpp"
#include "item_delegates/ForeignKeyDelegate.hpp"
#include "item_delegates/FrequencyDelegate.hpp"
#include "item_delegates/FrequencyDeltaDelegate.hpp"
#include "item_delegates/MessageItemDelegate.hpp"
#include "Transceiver/TransceiverFactory.hpp"
#include "Transceiver/Transceiver.hpp"
#include "models/Bands.hpp"
#include "models/IARURegions.hpp"
#include "models/Modes.hpp"
#include "models/FrequencyList.hpp"
#include "models/FrequencySuggestions.hpp"
#include "models/StationList.hpp"
#include "Network/NetworkServerLookup.hpp"
#include "Network/FoxVerifier.hpp"
#include "widgets/MessageBox.hpp"
#include "widgets/SettingsDialogLayout.hpp"
#include "widgets/SuggestedFrequenciesDialog.hpp"
#include "validators/MaidenheadLocatorValidator.hpp"
#include "validators/CallsignValidator.hpp"
#include "Network/LotWUsers.hpp"
#include "Network/Cloudlog.hpp"
#include "models/DecodeHighlightingModel.hpp"
#include "logbook/logbook.h"
#include "widgets/LazyFillComboBox.hpp"
#include "Network/FileDownload.hpp"

#include "ui_Configuration.h"
#include "moc_Configuration.cpp"

namespace
{
  class LocationLineEditEnterFilter final : public QObject
  {
  public:
    explicit LocationLineEditEnterFilter (QObject * parent) : QObject {parent} {}

  protected:
    bool eventFilter (QObject * watched, QEvent * event) override
    {
      if (event->type () == QEvent::KeyPress)
        {
          auto key_event = static_cast<QKeyEvent *> (event);
          if (key_event->key () == Qt::Key_Return || key_event->key () == Qt::Key_Enter)
            {
              if (auto edit = qobject_cast<QLineEdit *> (watched))
                {
                  edit->clearFocus ();
                  return true;
                }
            }
        }
      return QObject::eventFilter (watched, event);
    }
  };

  // Centre of a four- or six-character Maidenhead locator, with
  // conventional east-positive longitude.  Four-character locators are
  // treated as their "mm" subsquare, as grid2deg() does.
  bool grid_centre (QString grid, double& lat, double& lon)
  {
    grid = grid.trimmed ();
    if (grid.size () < 4) return false;
    grid = grid.left (6);
    if (grid.size () < 6) grid += "mm";
    if (grid.size () != 6) return false;
    grid[0] = grid[0].toUpper ();
    grid[1] = grid[1].toUpper ();
    grid[4] = grid[4].toLower ();
    grid[5] = grid[5].toLower ();
    if (grid[0] < 'A' || grid[0] > 'R' || grid[1] < 'A' || grid[1] > 'R'
        || !grid[2].isDigit () || !grid[3].isDigit ()
        || grid[4] < 'a' || grid[4] > 'x' || grid[5] < 'a' || grid[5] > 'x') return false;
    auto west = 180. - 20. * (grid[0].unicode () - 'A')
      - 2. * (grid[2].unicode () - '0')
      - 5. * ((grid[4].unicode () - 'a') + .5) / 60.;
    lat = -90. + 10. * (grid[1].unicode () - 'A')
      + (grid[3].unicode () - '0')
      + 2.5 * ((grid[5].unicode () - 'a') + .5) / 60.;
    lon = -west;
    return true;
  }

  // True when lat/lon are just the centre of the locator, i.e. they were
  // derived from My Grid rather than entered as precise coordinates.
  // Coordinates are displayed and stored to six decimal places, so allow
  // for that rounding.
  bool coordinates_are_grid_centre (QString const& grid, double lat, double lon)
  {
    double centre_lat, centre_lon;
    return grid_centre (grid, centre_lat, centre_lon)
      && std::abs (lat - centre_lat) < 1.e-6 && std::abs (lon - centre_lon) < 1.e-6;
  }

  // Convert conventional signed decimal degrees to a six-character
  // Maidenhead locator.  Longitude is east-positive here, matching the UI.
  bool coordinates_to_grid (double lat, double lon, QString& grid)
  {
    if (lat < -90. || lat > 90. || lon < -180. || lon > 180.) return false;

    auto east = lon;
    auto lat_for_grid = lat;
    if (east == 180.) east = std::nextafter (180., 0.);
    if (lat_for_grid == 90.) lat_for_grid = std::nextafter (90., 0.);
    auto x = east + 180.;
    auto y = lat_for_grid + 90.;
    int field_lon = static_cast<int> (std::floor (x / 20.));
    int field_lat = static_cast<int> (std::floor (y / 10.));
    x -= field_lon * 20.;
    y -= field_lat * 10.;
    int square_lon = static_cast<int> (std::floor (x / 2.));
    int square_lat = static_cast<int> (std::floor (y));
    x -= square_lon * 2.;
    y -= square_lat;
    int sub_lon = static_cast<int> (std::floor (x * 12.));
    int sub_lat = static_cast<int> (std::floor (y * 24.));

    grid.clear ();
    grid += QChar::fromLatin1 (static_cast<char> ('A' + field_lon));
    grid += QChar::fromLatin1 (static_cast<char> ('A' + field_lat));
    grid += QChar::fromLatin1 (static_cast<char> ('0' + square_lon));
    grid += QChar::fromLatin1 (static_cast<char> ('0' + square_lat));
    grid += QChar::fromLatin1 (static_cast<char> ('a' + sub_lon));
    grid += QChar::fromLatin1 (static_cast<char> ('a' + sub_lat));
    return true;
  }

  // these undocumented flag values when stored in (Qt::UserRole - 1)
  // of a ComboBox item model index allow the item to be enabled or
  // disabled
  int const combo_box_item_enabled (32 | 1);
  int const combo_box_item_disabled (0);

//  QRegExp message_alphabet {"[- A-Za-z0-9+./?]*"};
  QRegularExpression message_alphabet {"[- @A-Za-z0-9+./?#<>;$]*"};
  QRegularExpression RTTY_roundup_exchange_re {
    R"(
        (
           AL|AZ|AR|CA|CO|CT|DE|FL|GA      # 48 contiguous states
          |ID|IL|IN|IA|KS|KY|LA|ME|MD
          |MA|MI|MN|MS|MO|MT|NE|NV|NH|NJ
          |NM|NY|NC|ND|OH|OK|OR|PA|RI|SC
          |SD|TN|TX|UT|VT|VA|WA|WV|WI|WY
          |NB|NS|QC|ON|MB|SK|AB|BC|NWT|NF  # VE provinces
          |LB|NU|YT|PEI
          |DC                              # District of Columbia
          |DX                              # anyone else
          |SCC                             # Slovenia Contest Club contest
          |DR|FR|GD|GR|OV|ZH|ZL            # Dutch provinces (also FL,NH,UT,NB,LB)
          |X01|X02|X03|X04|X05|X06|X07     # 99 neutral exchanges
          |X08|X09|X10|X11|X12|X13|X14
          |X15|X16|X17|X18|X19|X20|X21
          |X22|X23|X24|X25|X26|X27|X28
          |X29|X30|X31|X32|X33|X34|X35
          |X36|X37|X38|X39|X40|X41|X42
          |X43|X44|X45|X46|X47|X48|X49
          |X50|X51|X52|X53|X54|X55|X56
          |X57|X58|X59|X60|X61|X62|X63
          |X64|X65|X66|X67|X68|X69|X70
          |X71|X72|X73|X74|X75|X76|X77
          |X78|X79|X80|X81|X82|X83|X84
          |X85|X86|X87|X88|X89|X90|X91
          |X92|X93|X94|X95|X96|X97|X98
          |X99
          |[0][0][0][1-9]                  # 4-digit numbers
          |[0][0-9][1-9][0-9]              # between 0001
          |[1-7][0-9][0-9][0-9]            # and 7999
        )
      )", QRegularExpression::CaseInsensitiveOption | QRegularExpression::ExtendedPatternSyntaxOption};

  QRegularExpression field_day_exchange_re {
    R"(
        (
           [1-9]                          # # transmitters (1 to 32 inc.)
          |[0-2]\d
          |3[0-2]
        )
        [A-F]\ *                          # class and optional space
        (
           AB|AK|AL|AR|AZ|BC|CO|CT|DE|EB  # ARRL/RAC section
          |EMA|ENY|EPA|EWA|GA|GH|IA|ID
          |IL|IN|KS|KY|LA|LAX|MB|MDC|ME
          |MI|MN|MO|MS|MT|NB|NC|ND|NE|NFL
          |NH|NL|NLI|NM|NNJ|NNY|NS|NTX|NV
          |OH|OK|ONE|ONN|ONS|OR|ORG|PAC
          |PE|PR|QC|RI|SB|SC|SCV|SD|SDG
          |SF|SFL|SJV|SK|SNJ|STX|SV|TER
          |TN|UT|VA|VI|VT|WCF|WI|WMA|WNY
          |WPA|WTX|WV|WWA|WY
          |DX                             # anyone else
        )
      )", QRegularExpression::CaseInsensitiveOption | QRegularExpression::ExtendedPatternSyntaxOption};

  // Magic numbers for file validation
  constexpr quint32 qrg_magic {0xadbccbdb};
  constexpr quint32 qrg_version {101}; // M.mm
  constexpr quint32 qrg_version_100 {100};

  QString cloudlog_connection_check_style (Cloudlog::ConnectionCheckStatus status)
  {
    switch (status)
      {
      case Cloudlog::ConnectionCheckStatus::Success:
        return QStringLiteral ("QPushButton {background-color: green;}");
      case Cloudlog::ConnectionCheckStatus::ReadOnlyKey:
        return QStringLiteral ("QPushButton {background-color: orange;}");
      case Cloudlog::ConnectionCheckStatus::InvalidKey:
      case Cloudlog::ConnectionCheckStatus::StationProfileUnavailable:
      case Cloudlog::ConnectionCheckStatus::EndpointUnavailable:
      case Cloudlog::ConnectionCheckStatus::UploadShapeRejected:
      case Cloudlog::ConnectionCheckStatus::NetworkError:
      case Cloudlog::ConnectionCheckStatus::UnexpectedResponse:
        return QStringLiteral ("QPushButton {background-color: red;}");
      }

    return {};
  }
}


//
// Dialog to get a new Frequency item
//
class FrequencyDialog final
  : public QDialog
{
  Q_OBJECT

public:
  using Item = FrequencyList_v2_101::Item;

  explicit FrequencyDialog (IARURegions * regions_model, Modes * modes_model, QWidget * parent = nullptr)
    : QDialog {parent}
  {
    start_date_time_edit_ = new QDateTimeEdit(QDateTime(QDate::currentDate(), QTime(0,0,0,0), Qt::UTC), parent);
    end_date_time_edit_ = new QDateTimeEdit(QDateTime(QDate::currentDate().addDays(2), QTime(0,0,0,0), Qt::UTC), parent);

    enable_dates_checkbox_ = new QCheckBox {tr ("")};
    start_date_time_edit_->setDisplayFormat("yyyy.MM.dd hh:mm:ss 'UTC'");
    start_date_time_edit_->setTimeSpec(Qt::UTC);
    start_date_time_edit_->setMinimumDate(QDate::currentDate().addDays(-365));

    end_date_time_edit_->setDisplayFormat("yyyy.MM.dd hh:mm:ss 'UTC'");
    end_date_time_edit_->setTimeSpec(Qt::UTC);
    end_date_time_edit_->setMinimumDate(QDate::currentDate().addDays(-365));
    preferred_frequency_checkbox_ = new QCheckBox {tr ("")};

    setWindowTitle (QApplication::applicationName () + " - " +
                    tr ("Add Frequency"));

    region_combo_box_.setModel (regions_model);
    mode_combo_box_.setModel (modes_model);

    auto form_layout = new QFormLayout ();
    form_layout->addRow (tr ("IARU &Region:"), &region_combo_box_);
    form_layout->addRow (tr ("&Mode:"), &mode_combo_box_);
    form_layout->addRow (tr ("&Frequency (MHz):"), &frequency_line_edit_);
    form_layout->addRow (tr ("&Preferred for Band/Mode:"), preferred_frequency_checkbox_);
    form_layout->addRow (tr ("&Description:"), &description_line_edit_);
    form_layout->addRow (tr ("&Enable Date Range:"), enable_dates_checkbox_);
    form_layout->addRow (tr ("S&tart:"), start_date_time_edit_);
    form_layout->addRow (tr ("&End:"), end_date_time_edit_);
    form_layout->addRow (tr ("&Source:"), &source_line_edit_);

    auto main_layout = new QVBoxLayout (this);
    main_layout->addLayout (form_layout);

    button_box = new QDialogButtonBox {QDialogButtonBox::Ok | QDialogButtonBox::Cancel};
    main_layout->addWidget (button_box);

    connect (button_box, &QDialogButtonBox::accepted, this, &FrequencyDialog::accept);
    connect (button_box, &QDialogButtonBox::rejected, this, &FrequencyDialog::reject);
    connect (&frequency_line_edit_, &QLineEdit::textChanged, this, &FrequencyDialog::update_accept_button);
    connect (start_date_time_edit_, &QDateTimeEdit::dateTimeChanged, this, &FrequencyDialog::checkSaneDates);
    connect (end_date_time_edit_, &QDateTimeEdit::dateTimeChanged, this, &FrequencyDialog::checkSaneDates);
    connect (enable_dates_checkbox_, &QCheckBox::stateChanged, this, &FrequencyDialog::toggleValidity);
    toggleValidity();
  }

    void toggleValidity()
    {
        start_date_time_edit_->setEnabled(enable_dates_checkbox_->isChecked());
        end_date_time_edit_->setEnabled(enable_dates_checkbox_->isChecked());
        checkSaneDates();
    }

    void checkSaneDates()
    {
        if (!dates_are_sane ())
        {
            QMessageBox::warning(this, tr("Invalid Date Range"), tr("Start date must be before end date"));
        }
        update_accept_button ();
    }

  Item item () const
  {
    QDateTime start_time = enable_dates_checkbox_->isChecked() ? start_date_time_edit_->dateTime() : QDateTime();
    QDateTime end_time = enable_dates_checkbox_->isChecked() ? end_date_time_edit_->dateTime()  : QDateTime();
    return {
            frequency_line_edit_.frequency(),
            Modes::value(mode_combo_box_.currentText()),
            IARURegions::value(region_combo_box_.currentText()),
            description_line_edit_.text(), source_line_edit_.text(),
            start_time,
            end_time,
            preferred_frequency_checkbox_->isChecked()
    };
  }

private:
  bool dates_are_sane () const
  {
    return !enable_dates_checkbox_->isChecked ()
      || !start_date_time_edit_->dateTime ().isValid ()
      || !end_date_time_edit_->dateTime ().isValid ()
      || start_date_time_edit_->dateTime () <= end_date_time_edit_->dateTime ();
  }

  void update_accept_button ()
  {
    button_box->button (QDialogButtonBox::Ok)->setEnabled (frequency_line_edit_.hasAcceptableInput ()
        && dates_are_sane ());
  }

  QComboBox region_combo_box_;
  QComboBox mode_combo_box_;
  QComboBox voices_combo_box_;
  FrequencyLineEdit frequency_line_edit_;
  QLineEdit description_line_edit_;
  QLineEdit source_line_edit_;
  QDialogButtonBox * button_box;
  QCheckBox *enable_dates_checkbox_;
  QCheckBox *preferred_frequency_checkbox_;
  QDateTimeEdit *end_date_time_edit_;
  QDateTimeEdit *start_date_time_edit_;
};


//
// Dialog to get a new Station item
//
class StationDialog final
  : public QDialog
{
  Q_OBJECT

public:
  explicit StationDialog (StationList const * stations, Bands * bands, QWidget * parent = nullptr)
    : QDialog {parent}
    , filtered_bands_ {new CandidateKeyFilter {bands, stations, 0, 0}}
  {
    setWindowTitle (QApplication::applicationName () + " - " + tr ("Add Station"));

    band_.setModel (filtered_bands_.data ());
      
    auto form_layout = new QFormLayout ();
    form_layout->addRow (tr ("&Band:"), &band_);
    form_layout->addRow (tr ("&Offset (MHz):"), &delta_);
    form_layout->addRow (tr ("&Antenna:"), &description_);

    auto main_layout = new QVBoxLayout (this);
    main_layout->addLayout (form_layout);

    button_box_ = new QDialogButtonBox {QDialogButtonBox::Ok | QDialogButtonBox::Cancel};
    main_layout->addWidget (button_box_);

    connect (button_box_, &QDialogButtonBox::accepted, this, &StationDialog::accept);
    connect (button_box_, &QDialogButtonBox::rejected, this, &StationDialog::reject);
    connect (&delta_, &QLineEdit::textChanged, this, &StationDialog::update_accept_button);

    if (delta_.text ().isEmpty ())
      {
        delta_.setText ("0");
      }
    update_accept_button ();
  }

  StationList::Station station () const
  {
    return {band_.currentText (), delta_.frequency_delta (), description_.text ()};
  }

  int exec () override
  {
    filtered_bands_->set_active_key ();
    return QDialog::exec ();
  }

private:
  void update_accept_button ()
  {
    button_box_->button (QDialogButtonBox::Ok)->setEnabled (delta_.hasAcceptableInput ());
  }

  QScopedPointer<CandidateKeyFilter> filtered_bands_;

  QComboBox band_;
  FrequencyDeltaLineEdit delta_;
  QLineEdit description_;
  QDialogButtonBox * button_box_;
};

class RearrangableMacrosModel
  : public QStringListModel
{
public:
  Qt::ItemFlags flags (QModelIndex const& index) const override
  {
    auto flags = QStringListModel::flags (index);
    if (index.isValid ())
      {
        // disallow drop onto existing items
        flags &= ~Qt::ItemIsDropEnabled;
      }
    return flags;
  }
};




// Internal implementation of the Configuration class.
class Configuration::impl final
  : public QDialog
{
  friend class TestConfigurationRadio;
  Q_OBJECT;

public:
  using FrequencyDelta = Radio::FrequencyDelta;
  using port_type = Configuration::port_type;
  using audio_info_type = QPair<QAudioDeviceInfo , QList<QVariant> >;

  explicit impl (Configuration * self
                 , QNetworkAccessManager * network_manager
                 , QDir const& temp_directory
                 , QSettings * settings
                 , LogBook * logbook
                 , QWidget * parent);
  ~impl ();

  bool have_rig ();
  bool can_control_rig (char const * command) const;
  void mark_rig_offline ();
  static QString summarize_transceiver_failure (QString const& reason);

  RigFrequencyChangePolicy::Activity frequency_change_activity () const;
  bool frequency_change_allowed (RigFrequencyChangePolicy::ChangeKind) const;
  bool transceiver_frequency (Frequency, RigFrequencyChangePolicy::ChangeKind);
  bool transceiver_tx_frequency (Frequency, RigFrequencyChangePolicy::ChangeKind);
  void transceiver_mode (MODE);
  void transceiver_ptt (bool);
  void transceiver_audio (bool);
  void transceiver_tune (bool);
  void transceiver_period (double);
  void transceiver_blocksize (qint32);
  void transceiver_modulator_start (TxEvidence::TxRequest const&);
  void transceiver_enqueue_jtty_pcm (QByteArray const&, TxAudioQueueEpoch, qint64);
  void transceiver_clear_jtty_pcm (TxAudioQueueEpoch);
  void transceiver_modulator_stop (bool);
  void transceiver_spread (double);
  void transceiver_nsym (int);
  void transceiver_trfrequency (double);
  void transceiver_volume (double);
  void transceiver_txvolume (double, bool = false);
  void sync_transceiver (bool force_signal);

  Q_SLOT int exec () override;
  Q_SLOT void accept () override;
  Q_SLOT void reject () override;
  Q_SLOT void done (int) override;

private:
  typedef QList<QAudioDeviceInfo> AudioDevices;
  struct SettingsFocusPage
  {
    QWidget * page;
    QList<QWidget *> tab_stops;
  };

  bool eventFilter (QObject *, QEvent *) override;
  void showEvent (QShowEvent *) override;
  void register_settings_focus_page (QWidget * page, QList<QWidget *> const& tab_stops);
  QList<QWidget *> current_settings_focus_path () const;
  QList<QWidget *> settings_dialog_buttons () const;
  int settings_focus_index (QList<QWidget *> const& path, QWidget * widget) const;
  bool move_settings_focus (QList<QWidget *> const& path, int current_index, bool reverse);

  void read_settings ();
  void write_settings ();

  void find_audio_devices ();
  QAudioDeviceInfo find_audio_device (QAudio::Mode, QComboBox *, QString const& device_name);
  void load_audio_devices (QAudio::Mode, QComboBox *, QAudioDeviceInfo *);
  void update_audio_channels (QComboBox const *, int, QComboBox *, bool);

  void load_network_interfaces (CheckableItemComboBox *, QStringList current);
  Q_SLOT void validate_network_interfaces (QString const&);
  QStringList get_selected_network_interfaces (CheckableItemComboBox *);
  Q_SLOT void host_info_results (QHostInfo);
  void check_multicast (QHostAddress const&);

  void find_tab (QWidget *);

  void initialize_models ();
  bool split_mode () const
  {
    return
      (WSJT_RIG_NONE_CAN_SPLIT || !rig_is_dummy_) &&
      (rig_params_.split_mode != TransceiverFactory::split_mode_none);
  }
  void set_cached_mode ();
  bool open_rig (bool force = false);
  bool rig_restart_required (TransceiverFactory::ParameterPack const&, bool) const;
  bool tx_inhibit_blocks_rig_restart (TransceiverFactory::ParameterPack const&, bool) const;
  void warn_tx_inhibit_restart_blocked ();
  //bool set_mode ();
  void close_rig (bool failed = false);
  TransceiverFactory::ParameterPack gather_rig_data ();
  void enumerate_rigs ();
  void normalize_rig_selections (bool restore = false);
  void set_rig_invariants ();
  enum class RadioValidationError { none, invalid_ptt_method, invalid_ptt_port };
  RadioValidationError validate_radio_settings ();
  bool validate ();
  void fill_port_combo_box (QComboBox *);
  Frequency apply_calibration (Frequency) const;
  Frequency remove_calibration (Frequency) const;

  void delete_frequencies ();
  void load_frequencies ();
  void merge_frequencies ();
  void save_frequencies ();
  void reset_frequencies ();
  void insert_frequency ();
  void show_suggested_frequencies ();
  void refresh_suggestion_notice ();
  void dismiss_suggestions ();
  void persist_seen_suggestions ();
  void size_frequency_table_columns();

    FrequencyList_v2_101::FrequencyItems read_frequencies_file (QString const&);

  void delete_stations ();
  void insert_station ();
  void handle_cloudlog_connection_check_result (Cloudlog::ConnectionCheckResult const& result);
  void set_cloudlog_station_profiles (QList<Cloudlog::StationProfile> const& profiles);
  qint32 cloudlog_station_profile_id () const;

  Q_SLOT void on_font_push_button_clicked ();
  Q_SLOT void on_decoded_text_font_push_button_clicked ();
  Q_SLOT void on_PTT_port_combo_box_currentTextChanged (QString const&);
  Q_SLOT void on_CAT_port_combo_box_currentTextChanged (QString const&);
  Q_SLOT void on_CAT_serial_baud_combo_box_currentIndexChanged (int);
  Q_SLOT void on_CAT_poll_interval_spin_box_valueChanged (int);
  Q_SLOT void on_test_CAT_push_button_clicked ();
  Q_SLOT void on_test_PTT_push_button_clicked (bool checked);
  Q_SLOT void on_pbTestCloudlog_clicked ();
  Q_SLOT void on_cbCloudlog_toggled (bool checked);
  Q_SLOT void on_cbEQSL_toggled (bool checked);
  Q_SLOT void on_force_DTR_combo_box_currentIndexChanged (int);
  Q_SLOT void on_force_RTS_combo_box_currentIndexChanged (int);
  Q_SLOT void on_rig_combo_box_currentIndexChanged (int);
  Q_SLOT void on_refresh_push_button_clicked ();
  Q_SLOT void on_tci_audio_check_box_clicked(bool checked);
  Q_SLOT void on_TCI_spin_box_valueChanged(double a);
  Q_SLOT void on_add_macro_push_button_clicked (bool = false);
  Q_SLOT void on_delete_macro_push_button_clicked (bool = false);
  Q_SLOT void on_move_macro_up_push_button_clicked (bool = false);
  Q_SLOT void on_move_macro_down_push_button_clicked (bool = false);
  Q_SLOT void on_grid_line_edit_editingFinished ();
  Q_SLOT void on_latitude_line_edit_editingFinished ();
  Q_SLOT void on_longitude_line_edit_editingFinished ();
  void update_home_coordinates_style ();
  Q_SLOT void on_add_macro_line_edit_editingFinished ();
  Q_SLOT void delete_macro ();
  void delete_selected_macros (QModelIndexList);
  void move_selected_macros (int);
  void move_selected_highlighting_rule (int);
  void after_CTY_downloaded();
  void set_CTY_DAT_version(QString const& version);
  void error_during_CTY_download (QString const& reason);
  void after_CALL3_downloaded();
  void error_during_CALL3_download (QString const& reason);
  void read_CALL3_version();
  Q_SLOT void on_udp_server_line_edit_textChanged (QString const&);
  Q_SLOT void on_udp_server_line_edit_editingFinished ();
  Q_SLOT void on_save_path_select_push_button_clicked (bool);
  Q_SLOT void on_azel_path_select_push_button_clicked (bool);
  Q_SLOT void on_calibration_intercept_spin_box_valueChanged (double);
  Q_SLOT void handle_leavingSettings ();
  Q_SLOT void on_calibration_slope_ppm_spin_box_valueChanged (double);
  Q_SLOT void handle_transceiver_tciframeswritten (qint64);
  Q_SLOT void handle_transceiver_tci_mod_active (bool);
  Q_SLOT void handle_transceiver_update (TransceiverState const&, unsigned sequence_number);
  Q_SLOT void handle_transceiver_failure (QString const& reason);
  Q_SLOT void on_DXCC_check_box_toggled (bool);
  void update_DXCC_control_availability ();
  Q_SLOT void on_PWR_and_SWR_check_box_toggled (bool);
  void update_PWR_and_SWR_control_availability ();
  void apply_color_preset (DecodeHighlightingModel::ColorPreset const& preset);
  void reset_highlighting (QString const& confirmation, DecodeHighlightingModel::HighlightItems const& items);
  Q_SLOT void on_move_highlighting_up_push_button_clicked (bool = false);
  Q_SLOT void on_move_highlighting_down_push_button_clicked (bool = false);
  Q_SLOT void on_rescan_log_push_button_clicked (bool);
  Q_SLOT void on_CTY_download_button_clicked (bool);
  Q_SLOT void on_CALL3_download_button_clicked (bool);
  Q_SLOT void on_CALL3_EME_download_button_clicked (bool);
  Q_SLOT void on_LotW_CSV_fetch_push_button_clicked (bool);
  Q_SLOT void on_hamlib_download_button_clicked (bool);
  Q_SLOT void on_revert_update_button_clicked (bool);
  void error_during_hamlib_download (QString const& reason);
  void after_hamlib_downloaded();
  void display_file_information();
  void check_visibility();

  Q_SLOT void on_cbx2ToneSpacing_toggled (bool);
  Q_SLOT void on_cbx4ToneSpacing_toggled (bool);
  Q_SLOT void on_prompt_to_log_check_box_toggled (bool);
  Q_SLOT void on_cbAutoLog_toggled (bool);
  void update_logging_control_availability ();
  Q_SLOT void on_Field_Day_Exchange_editingFinished ();
  Q_SLOT void on_RTTY_Exchange_editingFinished ();
  Q_SLOT void on_OTPUrl_textEdited (QString const&);
  Q_SLOT void on_OTPSeed_textEdited (QString const&);
  Q_SLOT void on_cbSortAlphabetically_clicked(bool);
  Q_SLOT void on_cbHideCARD_clicked(bool);
  Q_SLOT void on_Contest_Name_editingFinished ();
  Q_SLOT void on_Blacklist1_editingFinished ();
  Q_SLOT void on_Blacklist2_editingFinished ();
  Q_SLOT void on_Blacklist3_editingFinished ();
  Q_SLOT void on_Blacklist4_editingFinished ();
  Q_SLOT void on_Blacklist5_editingFinished ();
  Q_SLOT void on_Blacklist6_editingFinished ();
  Q_SLOT void on_Blacklist7_editingFinished ();
  Q_SLOT void on_Blacklist8_editingFinished ();
  Q_SLOT void on_Blacklist9_editingFinished ();
  Q_SLOT void on_Blacklist10_editingFinished ();
  Q_SLOT void on_Blacklist11_editingFinished ();
  Q_SLOT void on_Blacklist12_editingFinished ();
  Q_SLOT void on_Whitelist1_editingFinished ();
  Q_SLOT void on_Whitelist2_editingFinished ();
  Q_SLOT void on_Whitelist3_editingFinished ();
  Q_SLOT void on_Whitelist4_editingFinished ();
  Q_SLOT void on_Whitelist5_editingFinished ();
  Q_SLOT void on_Whitelist6_editingFinished ();
  Q_SLOT void on_Whitelist7_editingFinished ();
  Q_SLOT void on_Whitelist8_editingFinished ();
  Q_SLOT void on_Whitelist9_editingFinished ();
  Q_SLOT void on_Whitelist10_editingFinished ();
  Q_SLOT void on_Whitelist11_editingFinished ();
  Q_SLOT void on_Whitelist12_editingFinished ();
  Q_SLOT void on_Pass1_editingFinished ();
  Q_SLOT void on_Pass2_editingFinished ();
  Q_SLOT void on_Pass3_editingFinished ();
  Q_SLOT void on_Pass4_editingFinished ();
  Q_SLOT void on_Pass5_editingFinished ();
  Q_SLOT void on_Pass6_editingFinished ();
  Q_SLOT void on_Pass7_editingFinished ();
  Q_SLOT void on_Pass8_editingFinished ();
  Q_SLOT void on_Pass9_editingFinished ();
  Q_SLOT void on_Pass10_editingFinished ();
  Q_SLOT void on_Pass11_editingFinished ();
  Q_SLOT void on_Pass12_editingFinished ();
  Q_SLOT void on_Territory1_editingFinished ();
  Q_SLOT void on_Territory2_editingFinished ();
  Q_SLOT void on_Territory3_editingFinished ();
  Q_SLOT void on_Territory4_editingFinished ();
  Q_SLOT void on_highlight_orange_callsigns_editingFinished ();
  Q_SLOT void on_highlight_blue_callsigns_editingFinished ();
  Q_SLOT void on_voices_combo_box_currentIndexChanged (int);
  Q_SLOT void on_pb_test_alerts_clicked (bool);
  void read_voices ();
  void read_voice_directory ();

  // typenames used as arguments must match registered type names :(
  Q_SIGNAL void start_transceiver (unsigned seqeunce_number) const;
  Q_SIGNAL void set_transceiver (Transceiver::TransceiverState const&,
                                 unsigned sequence_number) const;
  Q_SIGNAL void stop_transceiver () const;
  Q_SIGNAL void enqueue_jtty_pcm (QByteArray const&, TxAudioQueueEpoch, qint64) const;
  Q_SIGNAL void clear_jtty_pcm (TxAudioQueueEpoch) const;
  Q_SIGNAL void receive_discontinuity (JttyReceiveReason) const;
  Q_SIGNAL void receive_stop_reason (JttyReceiveReason) const;
  Q_SIGNAL void receive_drain (quint64 requestId) const;

  PerformanceTrace::Phase construction_trace_;
  Configuration * const self_;  // back pointer to public interface

  QThread * transceiver_thread_;
  TransceiverFactory transceiver_factory_;
  QList<QMetaObject::Connection> rig_connections_;

  QScopedPointer<Ui::configuration_dialog> ui_;
  QList<SettingsFocusPage> settings_focus_pages_;

  QNetworkAccessManager * network_manager_;
  QSettings * settings_;
  bool use_default_geometry_ {false};
  LogBook * logbook_;

  QDir doc_dir_;
  QDir data_dir_;
  QDir temp_dir_;
  QDir writeable_data_dir_;
  QDir default_save_directory_;
  QDir save_directory_;
  QDir default_azel_directory_;
  QDir azel_directory_;

  QFont font_;
  QFont next_font_;

  QFont decoded_text_font_;
  QFont next_decoded_text_font_;

  LotWUsers lotw_users_;
  Cloudlog cloudlog_;

  bool restart_sound_input_device_;
  bool restart_sound_output_device_;
  bool restart_tci_device_;

  Type2MsgGen type_2_msg_gen_;

  QStringListModel macros_;
  RearrangableMacrosModel next_macros_;
  QAction * macro_delete_action_;

  Bands bands_;
  IARURegions regions_;
  IARURegions::Region region_;
  Modes modes_;
  FrequencyList_v2_101 frequencies_;
  FrequencyList_v2_101 next_frequencies_;
  StationList stations_;
  StationList next_stations_;
  FrequencyDelta current_offset_;
  FrequencyDelta current_tx_offset_;

  QAction * frequency_delete_action_;
  QAction * frequency_insert_action_;
  QAction * load_frequencies_action_;
  QAction * save_frequencies_action_;
  QAction * merge_frequencies_action_;
  QAction * reset_frequencies_action_;
  QAction * suggested_frequencies_action_;
  FrequencyDialog * frequency_dialog_;
  QFrame * suggestions_notice_ {nullptr};
  QLabel * suggestions_notice_label_ {nullptr};
  QPushButton * suggestions_browse_button_ {nullptr};
  QPushButton * suggestions_dismiss_button_ {nullptr};
  FrequencySuggestions::NoticeState suggestion_notice_state_;

  QAction station_delete_action_;
  QAction station_insert_action_;
  StationDialog * station_dialog_;

  DecodeHighlightingModel decode_highlighing_model_;
  DecodeHighlightingModel next_decode_highlighing_model_;
  bool highlight_by_mode_;
  bool highlight_only_fields_;
  bool include_WAE_entities_;
  bool highlight_73_;
  bool highlight_orange_;
  bool highlight_blue_;
  bool bSpecialOp_;
  bool alternate_erase_button_;
  bool show_country_names_;
  int LotW_days_since_upload_;
  int voice_;

  TransceiverFactory::ParameterPack rig_params_;
  TransceiverFactory::ParameterPack saved_rig_params_;
  TransceiverFactory::Capabilities::PortType last_port_type_;
  bool rig_is_dummy_;
  bool is_tci_;
  bool rig_active_;
  bool tx_inhibit_active_ {false};
  bool tx_inhibit_status_forwarded_ {false};
  quint64 tx_inhibit_generation_ {0};
  bool have_rig_;
  bool rig_changed_;
  TransceiverState cached_rig_state_;
  int rig_resolution_;          // see Transceiver::resolution signal
  CalibrationParams calibration_;
  bool frequency_calibration_disabled_; // not persistent
  unsigned transceiver_command_number_;
  bool initializing_models_;
  QString dynamic_grid_;

  // configuration fields that we publish
  QString my_callsign_;
  QString my_grid_;
  double home_latitude_ {0.};
  double home_longitude_ {0.};
  bool have_home_coordinates_ {false};
  QString FD_exchange_;
  QString RTTY_exchange_;
  QString Contest_Name_;
  QString Blacklist1_;
  QString Blacklist2_;
  QString Blacklist3_;
  QString Blacklist4_;
  QString Blacklist5_;
  QString Blacklist6_;
  QString Blacklist7_;
  QString Blacklist8_;
  QString Blacklist9_;
  QString Blacklist10_;
  QString Blacklist11_;
  QString Blacklist12_;
  QString Whitelist1_;
  QString Whitelist2_;
  QString Whitelist3_;
  QString Whitelist4_;
  QString Whitelist5_;
  QString Whitelist6_;
  QString Whitelist7_;
  QString Whitelist8_;
  QString Whitelist9_;
  QString Whitelist10_;
  QString Whitelist11_;
  QString Whitelist12_;
  QString Pass1_;
  QString Pass2_;
  QString Pass3_;
  QString Pass4_;
  QString Pass5_;
  QString Pass6_;
  QString Pass7_;
  QString Pass8_;
  QString Pass9_;
  QString Pass10_;
  QString Pass11_;
  QString Pass12_;
  QString Territory1_;
  QString Territory2_;
  QString Territory3_;
  QString Territory4_;
  QString highlight_orange_callsigns_;
  QString highlight_blue_callsigns_;
  QString hamlib_backed_up_;
  QString cloudLogApiUrl_;
  QString cloudLogApiKey_;
  QDir voice_directory_;
  bool send_to_eqsl_;
  QString eqsl_username_;
  QString eqsl_passwd_;
  QString eqsl_nickname_;

  QString OTPUrl_;
  QString OTPSeed_;
  bool  OTPEnabled_;
  bool  ShowOTP_;
  qint32 OTPinterval_;

  qint32 id_interval_;
  qint32 align_steps_;
  qint32 align_steps2_;
  qint32 ntrials_;
  qint32 volume_;
  qint32 aggressive_;
  qint32 RxBandwidth_;
  qint32 cloudLogStationID_;
  bool PWR_and_SWR_;
  bool check_SWR_;
  double degrade_;
  double txDelay_;
  bool tci_audio_;
  bool id_after_73_;
  bool tx_frequency_corrections_allowed_;
  bool progressBar_red_;
  bool spot_to_psk_reporter_;
  bool psk_reporter_tcpip_;
  bool monitor_off_at_startup_;
  bool monitor_last_used_;
  bool log_as_RTTY_;
  bool report_in_comments_;
  bool specOp_in_comments_;
  bool prompt_to_log_;
  bool autoLog_;
  bool contestingOnly_;
  bool ZZ00_;
  bool log4digitGrids_;
  bool decodes_from_top_;
  bool insert_blank_;
  bool detailed_blank_;
  bool DXCC_;
  bool gridMap_;
  bool gridMapAll_;
  bool ppfx_;
  bool miles_;
  bool quick_call_;
  bool disable_TX_on_73_;
  bool force_call_1st_;
  bool alternate_bindings_;
  int watchdog_;
  int tune_watchdog_time_;
  bool tune_watchdog_;
  bool TX_messages_;
  bool enable_VHF_features_;
  bool decode_at_52s_;
  bool kHz_without_k_;
  bool button_coloring_disabled_;
  bool Wait_features_enabled_;
  bool showDistance_;
  bool showAzimuth_;
  bool align_;
  bool repeat_Tx_;
  bool auto_astro_;
  bool single_decode_;
  bool twoPass_;
  bool bSuperFox_;
  bool Individual_Contest_Name_;
  bool NCCC_Sprint_;
  bool Blacklisted_;
  bool Whitelisted_;
  bool AlwaysPass_;
  bool filters_for_Wait_and_Pounce_only_;
  bool filters_for_word2_;
  bool twoDays_;
  bool bCloudLog_;
  int  SelectedActivity_;
  bool x2ToneSpacing_;
  bool x4ToneSpacing_;
  bool use_dynamic_grid_;
  QString opCall_;
  QString udp_server_name_;
  bool udp_server_name_edited_;
  int dns_lookup_id_;
  port_type udp_server_port_;
  QStringList udp_interface_names_;
  QString loopback_interface_name_;
  int udp_TTL_;
  QString n1mm_server_name_;
  port_type n1mm_server_port_;
  bool broadcast_to_n1mm_;
  bool accept_udp_requests_;
  bool udpWindowToFront_;
  bool udpWindowRestore_;
  DataMode data_mode_;
  bool bLowSidelobes_;
  bool sortAlphabetically_;
  bool hideCARD_;
  bool AzElExtraLines_;
  bool pwrBandTxMemory_;
  bool pwrBandTuneMemory_;
  bool highlight_DXcall_;
  bool clear_DXcall_;
  bool highlight_DXgrid_;
  bool clear_DXgrid_;
  bool erase_BandActivity_;
  bool set_RXtoTX_;
  bool alert_CQ_;
  bool alert_MyCall_;
  bool alert_DXCC_;
  bool alert_DXCCOB_;
  bool alert_Grid_;
  bool alert_GridOB_;
  bool alert_Continent_;
  bool alert_ContinentOB_;
  bool alert_CQZ_;
  bool alert_CQZOB_;
  bool alert_ITUZ_;
  bool alert_ITUZOB_;
  bool alert_DXcall_;
  bool alert_Wanted_;
  bool alert_QSYmessage_;
  bool alert_Enabled_;

  QAudioDeviceInfo audio_input_device_;
  QAudioDeviceInfo next_audio_input_device_;
  AudioDevice::Channel audio_input_channel_;
  AudioDevice::Channel next_audio_input_channel_;
  QAudioDeviceInfo audio_output_device_;
  QAudioDeviceInfo next_audio_output_device_;
  AudioDevice::Channel audio_output_channel_;
  AudioDevice::Channel next_audio_output_channel_;
  FileDownload cty_download_;
  FileDownload call3_download_;
  FileDownload hamlib_download_;
  
  bool default_audio_input_device_selected_;
  bool default_audio_output_device_selected_;
  
  friend class Configuration;
};

#include "Configuration.moc"


// delegate to implementation class
Configuration::Configuration (QNetworkAccessManager * network_manager, QDir const& temp_directory,
                              QSettings * settings, LogBook * logbook, QWidget * parent)
  : m_ {this, network_manager, temp_directory, settings, logbook, parent}
{
}

Configuration::~Configuration ()
{
}
QDir Configuration::doc_dir () const {return m_->doc_dir_;}
QDir Configuration::data_dir () const {return m_->data_dir_;}
QDir Configuration::writeable_data_dir () const {return m_->writeable_data_dir_;}
QDir Configuration::temp_dir () const {return m_->temp_dir_;}

void Configuration::select_tab (int index) {m_->ui_->configuration_tabs->setCurrentIndex (index);}
int Configuration::exec () {return m_->exec ();}
bool Configuration::is_active () const {return m_->isVisible ();}

QAudioDeviceInfo const& Configuration::audio_input_device () const {return m_->audio_input_device_;}
AudioDevice::Channel Configuration::audio_input_channel () const {return m_->audio_input_channel_;}
QAudioDeviceInfo const& Configuration::audio_output_device () const {return m_->audio_output_device_;}
AudioDevice::Channel Configuration::audio_output_channel () const {return m_->audio_output_channel_;}
bool Configuration::restart_audio_input () const {return m_->restart_sound_input_device_;}
bool Configuration::restart_audio_output () const {return m_->restart_sound_output_device_;}
bool Configuration::restart_tci () const {return m_->restart_tci_device_;}
auto Configuration::type_2_msg_gen () const -> Type2MsgGen {return m_->type_2_msg_gen_;}
QString Configuration::my_callsign () const {return m_->my_callsign_;}
QFont Configuration::text_font () const {return m_->font_;}
QFont Configuration::decoded_text_font () const {return m_->decoded_text_font_;}
qint32 Configuration::id_interval () const {return m_->id_interval_;}
qint32 Configuration::align_steps () const {return m_->align_steps_;}
qint32 Configuration::align_steps2 () const {return m_->align_steps2_;}
qint32 Configuration::ntrials() const {return m_->ntrials_;}
qint32 Configuration::volume() const {return m_->volume_;}
qint32 Configuration::aggressive() const {return m_->aggressive_;}
double Configuration::degrade() const {return m_->degrade_;}
double Configuration::txDelay() const {return m_->txDelay_;}
qint32 Configuration::RxBandwidth() const {return m_->RxBandwidth_;}
bool Configuration::tci_audio () const {return m_->tci_audio_;}
bool Configuration::id_after_73 () const {return m_->id_after_73_;}
bool Configuration::tx_frequency_corrections_allowed () const {return m_->tx_frequency_corrections_allowed_;}
bool Configuration::progressBar_red () const {return m_->progressBar_red_;}
bool Configuration::spot_to_psk_reporter () const
{
  // rig must be open and working to spot externally
  return is_transceiver_online () && m_->spot_to_psk_reporter_;
}
bool Configuration::psk_reporter_tcpip () const {return m_->psk_reporter_tcpip_;}
bool Configuration::send_to_eqsl () const {return m_->send_to_eqsl_;}
QString Configuration::eqsl_username () const {return m_->eqsl_username_;}
QString Configuration::eqsl_passwd () const {return m_->eqsl_passwd_;}
QString Configuration::eqsl_nickname () const {return m_->eqsl_nickname_;}
bool Configuration::monitor_off_at_startup () const {return m_->monitor_off_at_startup_;}
bool Configuration::monitor_last_used () const {return m_->rig_is_dummy_ || m_->monitor_last_used_;}
bool Configuration::log_as_RTTY () const {return m_->log_as_RTTY_;}
bool Configuration::report_in_comments () const {return m_->report_in_comments_;}
bool Configuration::specOp_in_comments () const {return m_->specOp_in_comments_;}
bool Configuration::cloudlog_enabled () const {return m_->bCloudLog_;}
QString Configuration::cloudlog_api_url () const {return m_->cloudLogApiUrl_;}
QString Configuration::cloudlog_api_key () const {return m_->cloudLogApiKey_;}
qint32 Configuration::cloudlog_api_station_id () const {return m_->cloudLogStationID_;}
bool Configuration::prompt_to_log () const {return m_->prompt_to_log_;}
bool Configuration::autoLog() const {return m_->autoLog_;}
bool Configuration::contestingOnly() const {return m_->contestingOnly_;}
bool Configuration::ZZ00() const {return m_->ZZ00_;}
bool Configuration::log4digitGrids() const {return m_->log4digitGrids_;}
bool Configuration::decodes_from_top () const {return m_->decodes_from_top_;}
bool Configuration::insert_blank () const {return m_->insert_blank_;}
bool Configuration::detailed_blank () const {return m_->detailed_blank_;}
bool Configuration::DXCC () const {return m_->DXCC_;}
bool Configuration::GridMap() const { return m_->gridMap_;}
bool Configuration::GridMapAll() const { return m_->gridMapAll_;}
bool Configuration::ppfx() const {return m_->ppfx_;}
bool Configuration::miles () const {return m_->miles_;}
bool Configuration::quick_call () const {return m_->quick_call_;}
bool Configuration::disable_TX_on_73 () const {return m_->disable_TX_on_73_;}
bool Configuration::force_call_1st() const {return m_->force_call_1st_;}
bool Configuration::alternate_bindings() const {return m_->alternate_bindings_;}
int Configuration::watchdog () const {return m_->watchdog_;}
int Configuration::tune_watchdog_time () const {return m_->tune_watchdog_time_;}
bool Configuration::tune_watchdog () const {return m_->tune_watchdog_;}
bool Configuration::TX_messages () const {return m_->TX_messages_;}
bool Configuration::enable_VHF_features () const {return m_->enable_VHF_features_;}
bool Configuration::decode_at_52s () const {return m_->decode_at_52s_;}
bool Configuration::kHz_without_k () const {return m_->kHz_without_k_;}
bool Configuration::button_coloring_disabled () const {return m_->button_coloring_disabled_;}
bool Configuration::Wait_features_enabled () const {return m_->Wait_features_enabled_;}
bool Configuration::showDistance() const {return m_->showDistance_;}
bool Configuration::showAzimuth() const {return m_->showAzimuth_;}
bool Configuration::align() const {return m_->align_;}
bool Configuration::repeat_Tx () const {return m_->repeat_Tx_;}
bool Configuration::auto_astro () const {return m_->auto_astro_;}
bool Configuration::single_decode () const {return m_->single_decode_;}
bool Configuration::twoPass() const {return m_->twoPass_;}
bool Configuration::superFox() const {return m_->bSuperFox_;}
bool Configuration::Individual_Contest_Name() const {return m_->Individual_Contest_Name_;}
bool Configuration::NCCC_Sprint() const {return m_->NCCC_Sprint_;}
bool Configuration::Blacklisted() const {return m_->Blacklisted_;}
bool Configuration::Whitelisted() const {return m_->Whitelisted_;}
bool Configuration::AlwaysPass() const {return m_->AlwaysPass_;}
bool Configuration::filters_for_Wait_and_Pounce_only() const {return m_->filters_for_Wait_and_Pounce_only_;}
bool Configuration::filters_for_word2() const {return m_->filters_for_word2_;}
bool Configuration::twoDays() const {return m_->twoDays_;}
bool Configuration::PWR_and_SWR () const {return m_->PWR_and_SWR_;}
bool Configuration::check_SWR () const {return m_->check_SWR_;}
bool Configuration::x2ToneSpacing() const {return m_->x2ToneSpacing_;}
bool Configuration::x4ToneSpacing() const {return m_->x4ToneSpacing_;}
bool Configuration::split_mode () const {return m_->split_mode ();}
QString Configuration::opCall() const {return m_->opCall_;}
void Configuration::opCall (QString const& call) {m_->opCall_ = call;}
QString Configuration::udp_server_name () const {return m_->udp_server_name_;}
auto Configuration::udp_server_port () const -> port_type {return m_->udp_server_port_;}
QStringList Configuration::udp_interface_names () const {return m_->udp_interface_names_;}
int Configuration::udp_TTL () const {return m_->udp_TTL_;}
bool Configuration::accept_udp_requests () const {return m_->accept_udp_requests_;}
QString Configuration::n1mm_server_name () const {return m_->n1mm_server_name_;}
auto Configuration::n1mm_server_port () const -> port_type {return m_->n1mm_server_port_;}
bool Configuration::broadcast_to_n1mm () const {return m_->broadcast_to_n1mm_;}
bool Configuration::broadcast_to_cloudlog () const {return m_->bCloudLog_;}
bool Configuration::lowSidelobes() const {return m_->bLowSidelobes_;}
bool Configuration::udpWindowToFront () const {return m_->udpWindowToFront_;}
bool Configuration::udpWindowRestore () const {return m_->udpWindowRestore_;}
Bands * Configuration::bands () {return &m_->bands_;}
Bands const * Configuration::bands () const {return &m_->bands_;}
StationList * Configuration::stations () {return &m_->stations_;}
StationList const * Configuration::stations () const {return &m_->stations_;}
IARURegions::Region Configuration::region () const {return m_->region_;}
FrequencyList_v2_101 * Configuration::frequencies () {return &m_->frequencies_;}
FrequencyList_v2_101 const * Configuration::frequencies () const {return &m_->frequencies_;}
QStringListModel * Configuration::macros () {return &m_->macros_;}
QStringListModel const * Configuration::macros () const {return &m_->macros_;}
QDir Configuration::save_directory () const {return m_->save_directory_;}
QDir Configuration::azel_directory () const {return m_->azel_directory_;}
QString Configuration::rig_name () const {return m_->rig_params_.rig_name;}
bool Configuration::AzElExtraLines () const {return m_->AzElExtraLines_;}
bool Configuration::pwrBandTxMemory () const {return m_->pwrBandTxMemory_;}
bool Configuration::pwrBandTuneMemory () const {return m_->pwrBandTuneMemory_;}
LotWUsers const& Configuration::lotw_users () const {return m_->lotw_users_;}
DecodeHighlightingModel const& Configuration::decode_highlighting () const {return m_->decode_highlighing_model_;}
bool Configuration::highlight_by_mode () const {return m_->highlight_by_mode_;}
bool Configuration::highlight_only_fields () const {return m_->highlight_only_fields_;}
bool Configuration::include_WAE_entities () const {return m_->include_WAE_entities_;}
bool Configuration::highlight_73 () const {return m_->highlight_73_;}
bool Configuration::highlight_orange () const {return m_->highlight_orange_;}
bool Configuration::highlight_blue () const {return m_->highlight_blue_;}
bool Configuration::bSpecialOp () const {return m_->bSpecialOp_;}
bool Configuration::alternate_erase_button () const {return m_->alternate_erase_button_;}
bool Configuration::show_country_names () const {return m_->show_country_names_;}
bool Configuration::highlight_DXcall () const {return m_->highlight_DXcall_;}
bool Configuration::clear_DXcall () const {return m_->clear_DXcall_;}
bool Configuration::highlight_DXgrid () const {return m_->highlight_DXgrid_;}
bool Configuration::clear_DXgrid () const {return m_->clear_DXgrid_;}
bool Configuration::erase_BandActivity () const {return m_->erase_BandActivity_;}
bool Configuration::set_RXtoTX () const {return m_->set_RXtoTX_;}
bool Configuration::alert_CQ () const {return m_->alert_CQ_;}
bool Configuration::alert_MyCall () const {return m_->alert_MyCall_;}
bool Configuration::alert_DXCC () const {return m_->alert_DXCC_;}
bool Configuration::alert_DXCCOB () const {return m_->alert_DXCCOB_;}
bool Configuration::alert_Grid () const {return m_->alert_Grid_;}
bool Configuration::alert_GridOB () const {return m_->alert_GridOB_;}
bool Configuration::alert_Continent () const {return m_->alert_Continent_;}
bool Configuration::alert_ContinentOB () const {return m_->alert_ContinentOB_;}
bool Configuration::alert_CQZ () const {return m_->alert_CQZ_;}
bool Configuration::alert_CQZOB () const {return m_->alert_CQZOB_;}
bool Configuration::alert_ITUZ () const {return m_->alert_ITUZ_;}
bool Configuration::alert_ITUZOB () const {return m_->alert_ITUZOB_;}
bool Configuration::alert_DXcall () const {return m_->alert_DXcall_;}
bool Configuration::alert_Wanted () const {return m_->alert_Wanted_;}
bool Configuration::alert_QSYmessage () const {return m_->alert_QSYmessage_;}
bool Configuration::alert_Enabled () const {return m_->alert_Enabled_;}


void Configuration::set_CTY_DAT_version(QString const& version)
{
  m_->set_CTY_DAT_version(version);
}

void Configuration::read_CALL3_version ()
{
  m_->read_CALL3_version ();
}

void Configuration::set_calibration (CalibrationParams params)
{
  m_->calibration_ = params;
}

void Configuration::enable_calibration (bool on)
{
  auto target_frequency = m_->remove_calibration (m_->cached_rig_state_.frequency ()) - m_->current_offset_;
  m_->frequency_calibration_disabled_ = !on;
  transceiver_frequency (
    target_frequency, RigFrequencyChangePolicy::ChangeKind::TxPathCorrection);
}

bool Configuration::is_transceiver_online () const
{
  return m_->rig_active_;
}

bool Configuration::is_dummy_rig () const
{
  return m_->rig_is_dummy_;
}

bool Configuration::is_tci () const
{
  return m_->is_tci_;
}

bool Configuration::transceiver_online ()
{
  LOG_TRACE (m_->cached_rig_state_);
  return m_->have_rig ();
}

int Configuration::transceiver_resolution () const
{
  return m_->rig_resolution_;
}

void Configuration::transceiver_offline ()
{
  LOG_TRACE (m_->cached_rig_state_);
  m_->close_rig ();
}

bool Configuration::transceiver_frequency (Frequency f, RigFrequencyChangePolicy::ChangeKind kind)
{
  LOG_TRACE (f << ' ' << m_->cached_rig_state_);
  if (!m_->frequency_change_allowed (kind)) return false;
  if (!m_->can_control_rig ("transceiver_frequency")) return false;
  return m_->transceiver_frequency (f, kind);
}

bool Configuration::transceiver_tx_frequency (Frequency f, RigFrequencyChangePolicy::ChangeKind kind)
{
  LOG_TRACE (f << ' ' << m_->cached_rig_state_);
  if (!m_->frequency_change_allowed (kind)) return false;
  if (!m_->can_control_rig ("transceiver_tx_frequency")) return false;
  return m_->transceiver_tx_frequency (f, kind);
}

void Configuration::transceiver_mode (MODE mode)
{
  LOG_TRACE (mode << ' ' << m_->cached_rig_state_);
  if (!m_->can_control_rig ("transceiver_mode")) return;
  m_->transceiver_mode (mode);
}

void Configuration::transceiver_ptt (bool on)
{
  LOG_TRACE (on << ' ' << m_->cached_rig_state_);
  if (!m_->can_control_rig ("transceiver_ptt")) return;
  m_->transceiver_ptt (on);
}

void Configuration::transceiver_audio (bool on)
{
  LOG_TRACE (on << ' ' << m_->cached_rig_state_);
  if (!m_->can_control_rig ("transceiver_audio")) return;
  m_->transceiver_audio (on);
}

void Configuration::transceiver_tune (bool on)
{
  LOG_TRACE (on << ' ' << m_->cached_rig_state_);
  if (!m_->can_control_rig ("transceiver_tune")) return;
  m_->transceiver_tune (on);
}

void Configuration::transceiver_period (double period)
{
#if WSJT_TRACE_CAT
  qDebug () << "Configuration::transceiver_period:" << period << m_->cached_rig_state_;
#endif

  if (!m_->can_control_rig ("transceiver_period")) return;
  m_->transceiver_period (period);
}

void Configuration::transceiver_receive_policy (ReceivePolicy policy)
{
  m_->cached_rig_state_.receive_policy (policy);
  if (m_->cached_rig_state_.online () && m_->can_control_rig ("transceiver_receive_policy"))
    Q_EMIT m_->set_transceiver (m_->cached_rig_state_, ++m_->transceiver_command_number_);
}

void Configuration::transceiver_receive_discontinuity (JttyReceiveReason reason)
{
  Q_EMIT m_->receive_discontinuity (reason);
}

void Configuration::transceiver_receive_context (quint64 context)
{
  m_->cached_rig_state_.receive_context (context);
  if (m_->cached_rig_state_.online () && m_->can_control_rig ("transceiver_receive_context"))
    Q_EMIT m_->set_transceiver (m_->cached_rig_state_, ++m_->transceiver_command_number_);
}

void Configuration::transceiver_receive_stop_reason (JttyReceiveReason reason)
{
  Q_EMIT m_->receive_stop_reason (reason);
}

void Configuration::requestContinuousReceiveDrain (quint64 requestId)
{
  if (!m_->rig_active_)
    {
      Q_EMIT continuousReceiveDrained (requestId, {});
      return;
    }
  Q_EMIT m_->receive_drain (requestId);
}

void Configuration::transceiver_blocksize (qint32 blocksize)
{
#if WSJT_TRACE_CAT
  qDebug () << "Configuration::transceiver_blocksize:" << blocksize << m_->cached_rig_state_;
#endif

  if (!m_->can_control_rig ("transceiver_blocksize")) return;
  m_->transceiver_blocksize (blocksize);
}

void Configuration::transceiver_modulator_start (TxEvidence::TxRequest request)
{
#if WSJT_TRACE_CAT
  qDebug () << "Configuration::transceiver_modulator_start:" << request.symbols_length << m_->cached_rig_state_;
#endif

  if (!m_->can_control_rig ("transceiver_modulator_start")) return;
  m_->transceiver_modulator_start (request);
}

void Configuration::transceiver_enqueue_jtty_pcm (QByteArray const& samples,
                                                   TxAudioQueueEpoch epoch,
                                                   qint64 enqueueId)
{
  m_->transceiver_enqueue_jtty_pcm (samples, epoch, enqueueId);
}

void Configuration::transceiver_clear_jtty_pcm (TxAudioQueueEpoch epoch)
{
  m_->transceiver_clear_jtty_pcm (epoch);
}

void Configuration::transceiver_modulator_stop (bool on)
{
#if WSJT_TRACE_CAT
  qDebug () << "Configuration::transceiver_stop:" << on << m_->cached_rig_state_;
#endif

  if (!m_->can_control_rig ("transceiver_modulator_stop")) return;
  m_->transceiver_modulator_stop (on);
}

void Configuration::transceiver_spread (double spread)
{
#if WSJT_TRACE_CAT
  qDebug () << "Configuration::transceiver_spread:" << spread << m_->cached_rig_state_;
#endif

  if (!m_->can_control_rig ("transceiver_spread")) return;
  m_->transceiver_spread (spread);
}

void Configuration::transceiver_nsym (qint32 nsym)
{
#if WSJT_TRACE_CAT
  qDebug () << "Configuration::transceiver_nsym:" << nsym << m_->cached_rig_state_;
#endif

  if (!m_->can_control_rig ("transceiver_nsym")) return;
  m_->transceiver_nsym (nsym);
}

void Configuration::transceiver_trfrequency (double trfrequency)
{
#if WSJT_TRACE_CAT
  qDebug () << "Configuration::transceiver_trfrequency:" << trfrequency << m_->cached_rig_state_;
#endif

  if (!m_->can_control_rig ("transceiver_trfrequency")) return;
  m_->transceiver_trfrequency (trfrequency);
}

void Configuration::transceiver_txvolume (qreal txvolume, bool force)
{
#if WSJT_TRACE_CAT
  qDebug () << "Configuration::transceiver_txvolume:" << txvolume << m_->cached_rig_state_;
#endif

  if (!m_->can_control_rig ("transceiver_txvolume")) return;
  m_->transceiver_txvolume (txvolume, force);
}

void Configuration::transceiver_volume (qreal volume)
{
#if WSJT_TRACE_CAT
  qDebug () << "Configuration::transceiver_volume:" << volume << m_->cached_rig_state_;
#endif

  if (!m_->can_control_rig ("transceiver_volume")) return;
  m_->transceiver_volume (volume);
}


void Configuration::sync_transceiver (bool force_signal, bool enforce_mode_and_split)
{
  LOG_TRACE ("force signal: " << force_signal << " enforce_mode_and_split: " << enforce_mode_and_split << ' ' << m_->cached_rig_state_);
  if (!m_->can_control_rig ("sync_transceiver")) return;
  m_->sync_transceiver (force_signal);
  if (!enforce_mode_and_split)
    {
      m_->transceiver_tx_frequency (0, RigFrequencyChangePolicy::ChangeKind::TxPathCorrection);
    }
}

void Configuration::invalidate_audio_input_device (QString /* error */)
{
  m_->audio_input_device_ = QAudioDeviceInfo {};
}

void Configuration::invalidate_audio_output_device (QString /* error */)
{
  m_->audio_output_device_ = QAudioDeviceInfo {};
}

// OTP seed can be empty, in which case it is not used, or a valid 16 character base32 string.
bool Configuration::validate_otp_seed(QString seed)
{
  if (seed.isEmpty())
    {
      return true;
    }
  if (seed.size() != 16)
    {
      return false;
    }
  for (QChar c: seed)
  {
    if (!QString(BASE32_CHARSET).contains(c))
    {
      return false;
    }
  }
  return true;
}
bool Configuration::valid_n1mm_info () const
{
  // do very rudimentary checking on the n1mm server name and port number.
  //
  auto server_name = m_->n1mm_server_name_;
  auto port_number = m_->n1mm_server_port_;
  return(!(server_name.trimmed().isEmpty() || port_number == 0));
}

QString Configuration::my_grid() const
{
  auto the_grid = m_->my_grid_;
  if (m_->use_dynamic_grid_ && m_->dynamic_grid_.size () >= 4) {
    the_grid = m_->dynamic_grid_;
  }
  return the_grid;
}

bool Configuration::has_precise_home_coordinates () const
{
  // Coordinates that are just the centre of My Grid add no precision, so
  // leave the astronomical calculation on its original grid-based path.
  return m_->have_home_coordinates_ && !(m_->use_dynamic_grid_ && m_->dynamic_grid_.size () >= 4)
    && !coordinates_are_grid_centre (m_->my_grid_, m_->home_latitude_, m_->home_longitude_);
}

double Configuration::home_latitude () const
{
  return m_->home_latitude_;
}

double Configuration::home_longitude () const
{
  return m_->home_longitude_;
}

QString Configuration::Field_Day_Exchange() const
{
  return m_->FD_exchange_;
}

QString Configuration::RTTY_Exchange() const
{
  return m_->RTTY_exchange_;
}

QString Configuration::Contest_Name() const
{
  return m_->Contest_Name_;
}

QString Configuration::Blacklist1() const
{
  return m_->Blacklist1_;
}

QString Configuration::Blacklist2() const
{
  return m_->Blacklist2_;
}

QString Configuration::Blacklist3() const
{
  return m_->Blacklist3_;
}

QString Configuration::Blacklist4() const
{
  return m_->Blacklist4_;
}

QString Configuration::Blacklist5() const
{
  return m_->Blacklist5_;
}

QString Configuration::Blacklist6() const
{
  return m_->Blacklist6_;
}

QString Configuration::Blacklist7() const
{
  return m_->Blacklist7_;
}

QString Configuration::Blacklist8() const
{
  return m_->Blacklist8_;
}

QString Configuration::Blacklist9() const
{
  return m_->Blacklist9_;
}

QString Configuration::Blacklist10() const
{
  return m_->Blacklist10_;
}

QString Configuration::Blacklist11() const
{
  return m_->Blacklist11_;
}

QString Configuration::Blacklist12() const
{
  return m_->Blacklist12_;
}

QString Configuration::Whitelist1() const
{
  return m_->Whitelist1_;
}

QString Configuration::Whitelist2() const
{
  return m_->Whitelist2_;
}

QString Configuration::Whitelist3() const
{
  return m_->Whitelist3_;
}

QString Configuration::Whitelist4() const
{
  return m_->Whitelist4_;
}

QString Configuration::Whitelist5() const
{
  return m_->Whitelist5_;
}

QString Configuration::Whitelist6() const
{
  return m_->Whitelist6_;
}

QString Configuration::Whitelist7() const
{
  return m_->Whitelist7_;
}

QString Configuration::Whitelist8() const
{
  return m_->Whitelist8_;
}

QString Configuration::Whitelist9() const
{
  return m_->Whitelist9_;
}

QString Configuration::Whitelist10() const
{
  return m_->Whitelist10_;
}

QString Configuration::Whitelist11() const
{
  return m_->Whitelist11_;
}

QString Configuration::Whitelist12() const
{
  return m_->Whitelist12_;
}

QString Configuration::Pass1() const
{
  return m_->Pass1_;
}

QString Configuration::Pass2() const
{
  return m_->Pass2_;
}

QString Configuration::Pass3() const
{
  return m_->Pass3_;
}

QString Configuration::Pass4() const
{
  return m_->Pass4_;
}

QString Configuration::Pass5() const
{
  return m_->Pass5_;
}

QString Configuration::Pass6() const
{
  return m_->Pass6_;
}

QString Configuration::Pass7() const
{
  return m_->Pass7_;
}

QString Configuration::Pass8() const
{
  return m_->Pass8_;
}

QString Configuration::Pass9() const
{
  return m_->Pass9_;
}

QString Configuration::Pass10() const
{
  return m_->Pass10_;
}

QString Configuration::Pass11() const
{
  return m_->Pass11_;
}

QString Configuration::Pass12() const
{
  return m_->Pass12_;
}

QString Configuration::Territory1() const
{
  return m_->Territory1_;
}

QString Configuration::Territory2() const
{
  return m_->Territory2_;
}

QString Configuration::Territory3() const
{
  return m_->Territory3_;
}

QString Configuration::Territory4() const
{
  return m_->Territory4_;
}

QString Configuration::highlight_orange_callsigns() const
{
  return m_->highlight_orange_callsigns_;
}

QString Configuration::highlight_blue_callsigns() const
{
  return m_->highlight_blue_callsigns_;
}

QDir Configuration::voice_directory () const
{
  return m_->voice_directory_;
}

QStringList Configuration::pass_keywords() const
{
  return {m_->Pass1_, m_->Pass2_, m_->Pass3_, m_->Pass4_, m_->Pass5_, m_->Pass6_,
          m_->Pass7_, m_->Pass8_, m_->Pass9_, m_->Pass10_, m_->Pass11_, m_->Pass12_};
}

QStringList Configuration::blacklist_keywords() const
{
  return {m_->Blacklist1_, m_->Blacklist2_, m_->Blacklist3_, m_->Blacklist4_, m_->Blacklist5_, m_->Blacklist6_,
          m_->Blacklist7_, m_->Blacklist8_, m_->Blacklist9_, m_->Blacklist10_, m_->Blacklist11_, m_->Blacklist12_};
}

QStringList Configuration::whitelist_keywords() const
{
  return {m_->Whitelist1_, m_->Whitelist2_, m_->Whitelist3_, m_->Whitelist4_, m_->Whitelist5_, m_->Whitelist6_,
          m_->Whitelist7_, m_->Whitelist8_, m_->Whitelist9_, m_->Whitelist10_, m_->Whitelist11_, m_->Whitelist12_};
}

auto Configuration::special_op_id () const -> SpecialOperatingActivity
{
  return m_->bSpecialOp_ ? static_cast<SpecialOperatingActivity> (m_->SelectedActivity_) : SpecialOperatingActivity::NONE;
}

void Configuration::set_location (QString const& grid_descriptor)
{
  // change the dynamic grid
  // qDebug () << "Configuration::set_location - location:" << grid_descriptor;
  m_->dynamic_grid_ = grid_descriptor.trimmed ();
}

void Configuration::setSpecial_Q65_Pileup()
{
  m_->bSpecialOp_=true;
  m_->ui_->cbSpecialOpActivity->setChecked(m_->bSpecialOp_);
  m_->ui_->rbQ65pileup->setChecked(true);
  m_->SelectedActivity_ = static_cast<int> (SpecialOperatingActivity::Q65_PILEUP);
  m_->write_settings();
}

void Configuration::setSpecial_Hound()
{
  m_->bSpecialOp_=true;
  m_->ui_->cbSpecialOpActivity->setChecked(m_->bSpecialOp_);
  m_->ui_->rbHound->setChecked(true);
  m_->SelectedActivity_ = static_cast<int> (SpecialOperatingActivity::HOUND);
  m_->write_settings();
}

void Configuration::setSpecial_Fox()
{
  m_->bSpecialOp_=true;
  m_->ui_->cbSpecialOpActivity->setChecked(m_->bSpecialOp_);
  m_->ui_->rbFox->setChecked(true);
  m_->SelectedActivity_ = static_cast<int> (SpecialOperatingActivity::FOX);
  m_->write_settings();
}

void Configuration::setSpecial_None()
{
  m_->bSpecialOp_=false;
  m_->ui_->cbSpecialOpActivity->setChecked(m_->bSpecialOp_);
  m_->write_settings();
}

void Configuration::setSpecial_On()
{
  m_->bSpecialOp_=true;
  m_->ui_->cbSpecialOpActivity->setChecked(m_->bSpecialOp_);
  m_->write_settings();
}

void Configuration::toggle_SF()
{
  if (m_->bSuperFox_) {
    m_->ui_->cbSuperFox->setChecked(false);
  } else {
    m_->ui_->cbSuperFox->setChecked(true);
  }
  m_->bSuperFox_ = m_->ui_->cbSuperFox->isChecked ();
  m_->write_settings();
}

QString Configuration::OTPSeed() const
{
  return m_->OTPSeed_;
}

QString Configuration::OTPUrl() const
{
  return m_->OTPUrl_;
}

unsigned int Configuration::OTPinterval() const
{
  return m_->OTPinterval_;
}

bool Configuration::OTPEnabled() const
{
  return m_->OTPSeed_.size() == 16 && m_->OTPEnabled_;
}

bool Configuration::ShowOTP () const
{
  return m_->ShowOTP_;
}

namespace
{
#if defined (Q_OS_MAC)
  char const * app_root = "/../../../";
#else
  char const * app_root = "/../";
#endif
  QString doc_path ()
  {
#if CMAKE_BUILD
    if (QDir::isRelativePath (CMAKE_INSTALL_DOCDIR))
      {
	return QApplication::applicationDirPath () + app_root + CMAKE_INSTALL_DOCDIR;
      }
    return CMAKE_INSTALL_DOCDIR;
#else
    return QApplication::applicationDirPath ();
#endif
  }

}

bool Configuration::impl::eventFilter (QObject *object, QEvent *event)
{
  if (event->type () == QEvent::KeyPress)
    {
      auto key_event = static_cast<QKeyEvent *> (event);
      auto const navigation_modifiers = key_event->modifiers ()
        & (Qt::ShiftModifier | Qt::ControlModifier | Qt::AltModifier | Qt::MetaModifier);
      auto const is_forward_tab = key_event->key () == Qt::Key_Tab
        && navigation_modifiers == Qt::NoModifier;
      auto const is_reverse_tab = (key_event->key () == Qt::Key_Tab
                                   && navigation_modifiers == Qt::ShiftModifier)
        || (key_event->key () == Qt::Key_Backtab
            && (navigation_modifiers == Qt::NoModifier
                || navigation_modifiers == Qt::ShiftModifier));
      auto const is_tab = is_forward_tab || is_reverse_tab;
      if (is_tab)
        {
          auto const path = current_settings_focus_path ();
          auto object_widget = qobject_cast<QWidget *> (object);
          auto current_index = settings_focus_index (path, QApplication::focusWidget ());
          if (current_index < 0)
            {
              current_index = settings_focus_index (path, object_widget);
            }
          if (current_index >= 0)
            {
              return move_settings_focus (path, current_index, is_reverse_tab);
            }
        }
    }

  return QDialog::eventFilter (object, event);
}

void Configuration::impl::register_settings_focus_page (QWidget * page, QList<QWidget *> const& tab_stops)
{
  settings_focus_pages_.append ({page, tab_stops});

  for (auto control : tab_stops)
    {
      control->setFocusPolicy (Qt::StrongFocus);
      control->installEventFilter (this);
    }
}

void Configuration::impl::showEvent (QShowEvent * event)
{
  QDialog::showEvent (event);

  auto * window = windowHandle ();
  auto * screen = window ? window->screen () : QGuiApplication::primaryScreen ();
  if (!screen)
    {
      return;
    }

  auto const requested_size = use_default_geometry_
    ? SettingsDialogLayout::preferredWindowSize (*this, *ui_) : size ();
  use_default_geometry_ = false;
  auto const bounded_size = SettingsDialogLayout::boundedWindowSize (
    requested_size, screen->availableGeometry ().size (),
    window ? window->frameMargins () : QMargins {});
  if (bounded_size != size ())
    {
      resize (bounded_size);
    }
}

QList<QWidget *> Configuration::impl::current_settings_focus_path () const
{
  auto const current_page = ui_->configuration_tabs->currentWidget ();
  for (auto const& focus_page : settings_focus_pages_)
    {
      if (focus_page.page == current_page)
        {
          auto path = QList<QWidget *> {ui_->configuration_tabs};
          path.append (focus_page.tab_stops);
          path.append (settings_dialog_buttons ());
          return path;
        }
    }

  return {};
}

QList<QWidget *> Configuration::impl::settings_dialog_buttons () const
{
  QList<QWidget *> buttons;
  auto const button_box = ui_->configuration_dialog_button_box;
  for (auto button : {
       button_box->button (QDialogButtonBox::Ok),
       button_box->button (QDialogButtonBox::Cancel),
       })
    {
      if (button)
        {
          buttons.append (button);
        }
    }

  std::sort (buttons.begin (), buttons.end (), [button_box] (QWidget * lhs, QWidget * rhs) {
    auto const lhs_center = lhs->geometry ().center ();
    auto const rhs_center = rhs->geometry ().center ();
    if (button_box->orientation () == Qt::Vertical && lhs_center.y () != rhs_center.y ())
      {
        return lhs_center.y () < rhs_center.y ();
      }

    if (button_box->layoutDirection () == Qt::RightToLeft)
      {
        return lhs_center.x () > rhs_center.x ();
      }

    return lhs_center.x () < rhs_center.x ();
  });

  return buttons;
}

int Configuration::impl::settings_focus_index (QList<QWidget *> const& path, QWidget * widget) const
{
  if (!widget)
    {
      return -1;
    }

  auto const tab_bar = ui_->configuration_tabs->tabBar ();
  for (int index = 0; index < path.size (); ++index)
    {
      if (path.at (index) == widget
          || (path.at (index) == ui_->configuration_tabs && tab_bar == widget))
        {
          return index;
        }
    }

  return -1;
}

bool Configuration::impl::move_settings_focus (QList<QWidget *> const& path, int current_index, bool reverse)
{
  if (current_index < 0 || path.isEmpty ())
    {
      return false;
    }

  auto const direction = reverse ? -1 : 1;
  for (int offset = 1; offset <= path.size (); ++offset)
    {
      auto const next_index = (current_index + direction * offset + path.size ()) % path.size ();
      auto next = path.at (next_index);
      if (next->isEnabledTo (this) && next->isVisibleTo (this))
        {
          next->setFocus (reverse ? Qt::BacktabFocusReason : Qt::TabFocusReason);
          return true;
        }
    }

  return false;
}

Configuration::impl::impl (Configuration * self, QNetworkAccessManager * network_manager
                           , QDir const& temp_directory, QSettings * settings, LogBook * logbook
                           , QWidget * parent)
  : QDialog {parent}
  , construction_trace_ {"configuration.construct"}
  , self_ {self}
  , transceiver_thread_ {nullptr}
  , ui_ {new Ui::configuration_dialog}
  , network_manager_ {network_manager}
  , settings_ {settings}
  , logbook_ {logbook}
  , doc_dir_ {doc_path ()}
  , data_dir_ {installed_data_directory ()}
  , temp_dir_ {temp_directory}
  , writeable_data_dir_ {QStandardPaths::writableLocation (QStandardPaths::DataLocation)}
  , lotw_users_ {network_manager_}
  , cloudlog_ {self, network_manager_}
  , restart_sound_input_device_ {false}
  , restart_sound_output_device_ {false}
  , restart_tci_device_ {false}
  , frequencies_ {&bands_}
  , next_frequencies_ {&bands_}
  , stations_ {&bands_}
  , next_stations_ {&bands_}
  , current_offset_ {0}
  , current_tx_offset_ {0}
  , frequency_dialog_ {new FrequencyDialog {&regions_, &modes_, this}}
  , station_delete_action_ {tr ("&Delete"), nullptr}
  , station_insert_action_ {tr ("&Insert ..."), nullptr}
  , station_dialog_ {new StationDialog {&next_stations_, &bands_, this}}
  , highlight_by_mode_ {false}
  , highlight_only_fields_ {false}
  , include_WAE_entities_ {false}
  , highlight_73_ {false}
  , highlight_orange_ {false}
  , highlight_blue_ {false}
  , bSpecialOp_ {false}
  , alternate_erase_button_ {false}
  , show_country_names_ {false}
  , LotW_days_since_upload_ {0}
  , last_port_type_ {TransceiverFactory::Capabilities::none}
  , rig_is_dummy_ {false}
  , is_tci_ {false}
  , rig_active_ {false}
  , have_rig_ {false}
  , rig_changed_ {false}
  , rig_resolution_ {0}
  , frequency_calibration_disabled_ {false}
  , transceiver_command_number_ {0}
  , initializing_models_ {false}
  , degrade_ {0.}               // initialize to zero each run, not
                                // saved in settings
  , udp_server_name_edited_ {false}
  , dns_lookup_id_ {-1}
  , audio_input_channel_ {AudioDevice::Mono}
  , next_audio_input_channel_ {AudioDevice::Mono}
  , audio_output_channel_ {AudioDevice::Mono}
  , next_audio_output_channel_ {AudioDevice::Mono}
  , default_audio_input_device_selected_ {false}
  , default_audio_output_device_selected_ {false}
{
  {
    PerformanceTrace::Phase ui_setup {"configuration.ui_setup"};
    ui_->setupUi (this);
  }

  SettingsDialogLayout::install (*ui_);

  installEventFilter (this);
  ui_->configuration_tabs->setFocusPolicy (Qt::StrongFocus);
  ui_->configuration_tabs->installEventFilter (this);
  ui_->configuration_tabs->tabBar ()->installEventFilter (this);
  ui_->configuration_dialog_button_box->installEventFilter (this);
  for (auto button : settings_dialog_buttons ())
    {
      button->setFocusPolicy (Qt::StrongFocus);
      button->installEventFilter (this);
    }

  auto update_rig_invariants_when_checked = [this] (QButtonGroup *button_group) {
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
    connect (button_group, QOverload<int, bool>::of (&QButtonGroup::buttonToggled),
#else
    connect (button_group, &QButtonGroup::idToggled,
#endif
             this, [this] (int, bool checked) {
               if (checked && !initializing_models_)
                 {
                   set_rig_invariants ();
                 }
             });
  };
  update_rig_invariants_when_checked (ui_->CAT_data_bits_button_group);
  update_rig_invariants_when_checked (ui_->CAT_stop_bits_button_group);
  update_rig_invariants_when_checked (ui_->CAT_handshake_button_group);
  update_rig_invariants_when_checked (ui_->PTT_method_button_group);
  update_rig_invariants_when_checked (ui_->split_mode_button_group);

  auto set_accessible_line_edit_names = [] (QList<QLineEdit *> const& line_edits,
                                            QString const& name_template) {
    for (int index = 0; index < line_edits.size (); ++index)
      {
        line_edits.at (index)->setAccessibleName (name_template.arg (index + 1));
      }
  };
  set_accessible_line_edit_names ({
    ui_->Territory1,
    ui_->Territory2,
    ui_->Territory3,
    ui_->Territory4,
  }, tr ("Wanted territory %1"));
  set_accessible_line_edit_names ({
    ui_->Blacklist1,
    ui_->Blacklist2,
    ui_->Blacklist3,
    ui_->Blacklist4,
    ui_->Blacklist5,
    ui_->Blacklist6,
    ui_->Blacklist7,
    ui_->Blacklist8,
    ui_->Blacklist9,
    ui_->Blacklist10,
    ui_->Blacklist11,
    ui_->Blacklist12,
  }, tr ("Blacklist keyword %1"));
  set_accessible_line_edit_names ({
    ui_->Whitelist1,
    ui_->Whitelist2,
    ui_->Whitelist3,
    ui_->Whitelist4,
    ui_->Whitelist5,
    ui_->Whitelist6,
    ui_->Whitelist7,
    ui_->Whitelist8,
    ui_->Whitelist9,
    ui_->Whitelist10,
    ui_->Whitelist11,
    ui_->Whitelist12,
  }, tr ("Whitelist keyword %1"));
  set_accessible_line_edit_names ({
    ui_->Pass1,
    ui_->Pass2,
    ui_->Pass3,
    ui_->Pass4,
    ui_->Pass5,
    ui_->Pass6,
    ui_->Pass7,
    ui_->Pass8,
    ui_->Pass9,
    ui_->Pass10,
    ui_->Pass11,
    ui_->Pass12,
  }, tr ("Always pass keyword %1"));

  ui_->CAT_port_combo_box->setAccessibleName (tr ("CAT control port"));
  ui_->CAT_serial_baud_combo_box->setAccessibleName (tr ("CAT baud rate"));
  ui_->CAT_default_bit_radio_button->setAccessibleName (tr ("Default CAT data bits"));
  ui_->CAT_7_bit_radio_button->setAccessibleName (tr ("Seven CAT data bits"));
  ui_->CAT_8_bit_radio_button->setAccessibleName (tr ("Eight CAT data bits"));
  ui_->CAT_default_stop_bit_radio_button->setAccessibleName (tr ("Default CAT stop bits"));
  ui_->CAT_one_stop_bit_radio_button->setAccessibleName (tr ("One CAT stop bit"));
  ui_->CAT_two_stop_bit_radio_button->setAccessibleName (tr ("Two CAT stop bits"));
  ui_->CAT_handshake_default_radio_button->setAccessibleName (tr ("Default CAT handshake"));
  ui_->CAT_handshake_none_radio_button->setAccessibleName (tr ("No CAT handshake"));
  ui_->CAT_handshake_xon_radio_button->setAccessibleName (tr ("XON/XOFF CAT handshake"));
  ui_->CAT_handshake_hardware_radio_button->setAccessibleName (tr ("Hardware CAT handshake"));
  ui_->force_DTR_combo_box->setAccessibleName (tr ("Force DTR control line"));
  ui_->force_RTS_combo_box->setAccessibleName (tr ("Force RTS control line"));
  ui_->PTT_VOX_radio_button->setAccessibleName (tr ("VOX PTT method"));
  ui_->PTT_DTR_radio_button->setAccessibleName (tr ("DTR PTT method"));
  ui_->PTT_CAT_radio_button->setAccessibleName (tr ("CAT PTT method"));
  ui_->PTT_RTS_radio_button->setAccessibleName (tr ("RTS PTT method"));
  ui_->PTT_port_combo_box->setAccessibleName (tr ("PTT control port"));
  ui_->TX_source_data_radio_button->setAccessibleName (tr ("Rear or data transmit audio source"));
  ui_->TX_source_mic_radio_button->setAccessibleName (tr ("Front or mic transmit audio source"));
  ui_->mode_none_radio_button->setAccessibleName (tr ("No radio mode control"));
  ui_->mode_USB_radio_button->setAccessibleName (tr ("USB radio mode"));
  ui_->mode_data_radio_button->setAccessibleName (tr ("Data or packet radio mode"));
  ui_->split_none_radio_button->setAccessibleName (tr ("No split operation"));
  ui_->split_rig_radio_button->setAccessibleName (tr ("Rig split operation"));
  ui_->split_emulate_radio_button->setAccessibleName (tr ("Fake It split operation"));
  ui_->CAT_poll_interval_spin_box->setAccessibleName (tr ("CAT poll interval"));
  ui_->calibration_slope_ppm_spin_box->setAccessibleName (tr ("Frequency calibration slope"));
  ui_->calibration_intercept_spin_box->setAccessibleName (tr ("Frequency calibration intercept"));
  ui_->frequencies_table_view->setAccessibleName (tr ("Working frequencies table"));
  suggestions_notice_ = new QFrame {ui_->frequencies_tab};
  suggestions_notice_->setFrameShape (QFrame::StyledPanel);
  auto * suggestions_notice_layout = new QHBoxLayout {suggestions_notice_};
  suggestions_notice_label_ = new QLabel {suggestions_notice_};
  suggestions_notice_label_->setWordWrap (true);
  suggestions_browse_button_ = new QPushButton {tr ("Browse suggestions..."), suggestions_notice_};
  suggestions_dismiss_button_ = new QPushButton {tr ("Dismiss"), suggestions_notice_};
  suggestions_notice_layout->addWidget (suggestions_notice_label_, 1);
  suggestions_notice_layout->addWidget (suggestions_browse_button_);
  suggestions_notice_layout->addWidget (suggestions_dismiss_button_);
  ui_->horizontalLayout->insertWidget (0, suggestions_notice_);
  suggestions_notice_->hide ();
  connect (suggestions_browse_button_, &QPushButton::clicked,
           this, &Configuration::impl::show_suggested_frequencies);
  connect (suggestions_dismiss_button_, &QPushButton::clicked,
           this, &Configuration::impl::dismiss_suggestions);
  ui_->stations_table_view->setAccessibleName (tr ("Station information table"));
  ui_->highlighting_list_view->setAccessibleName (tr ("Decode highlighting rules"));
  ui_->highlighting_list_view->setAccessibleDescription (tr ("Highlighting rules and priorities for decoded messages."));
  ui_->highlighting_actions_tool_button->setAccessibleName (tr ("Decode highlighting actions"));
  ui_->highlighting_actions_tool_button->setAccessibleDescription (
    tr ("Change colors or restore Default 1 colors and enabled state for the selected highlighting rule."));
  ui_->move_highlighting_up_push_button->setAccessibleName (tr ("Move selected highlighting rule up"));
  ui_->move_highlighting_up_push_button->setAccessibleDescription (tr ("Move the selected highlighting rule earlier in priority order."));
  ui_->move_highlighting_down_push_button->setAccessibleName (tr ("Move selected highlighting rule down"));
  ui_->move_highlighting_down_push_button->setAccessibleDescription (tr ("Move the selected highlighting rule later in priority order."));
  ui_->color_presets_tool_button->setAccessibleName (tr ("Decode highlighting color presets"));
  ui_->color_presets_tool_button->setAccessibleDescription (tr ("Apply colors to all decode highlighting rules without changing which rules are enabled or their priority."));
  ui_->reset_highlighting_tool_button->setAccessibleName (tr ("Reset decode highlighting"));
  ui_->reset_highlighting_tool_button->setAccessibleDescription (tr ("Restore colors, enabled rules, and priority order to a complete default configuration."));
  ui_->highlight_orange_callsigns->setAccessibleName (tr ("Orange highlight callsigns and grids"));
  ui_->highlight_blue_callsigns->setAccessibleName (tr ("Blue highlight callsigns and grids"));

  register_settings_focus_page (ui_->general_tab, {
    ui_->callsign_line_edit,
    ui_->grid_line_edit,
    ui_->use_dynamic_grid,
    ui_->region_combo_box,
    ui_->type_2_msg_gen_combo_box,
    ui_->decodes_from_top_check_box,
    ui_->insert_blank_check_box,
    ui_->cb_detailed_blank_line,
    ui_->miles_check_box,
    ui_->cbHighlightDXcall,
    ui_->font_push_button,
    ui_->TX_messages_check_box,
    ui_->cbHighlightDXgrid,
    ui_->decoded_text_font_push_button,
    ui_->DXCC_check_box,
    ui_->ppfx_check_box,
    ui_->show_country_names_check_box,
    ui_->monitor_off_check_box,
    ui_->enable_VHF_features_check_box,
    ui_->repeat_Tx_check_box,
    ui_->monitor_last_used_check_box,
    ui_->tx_frequency_corrections_check_box,
    ui_->auto_astro_check_box,
    ui_->quick_call_check_box,
    ui_->decode_at_52s_check_box,
    ui_->kHz_without_k_check_box,
    ui_->disable_TX_on_73_check_box,
    ui_->single_decode_check_box,
    ui_->progress_bar_check_box,
    ui_->force_call_1st_check_box,
    ui_->CW_id_after_73_check_box,
    ui_->CW_id_interval_spin_box,
    ui_->alternate_bindings_check_box,
    ui_->tune_watchdog_check_box,
    ui_->tune_watchdog_spin_box,
    ui_->tx_watchdog_spin_box,
    ui_->Map_Grid_to_State,
    ui_->cbEraseBandActivity,
    ui_->alternate_erase_button_check_box,
    ui_->Map_All_Messages,
    ui_->cbRxToTxAfterQSO,
    ui_->enable_Wait_features_check_box,
    ui_->cbClearDXcall,
    ui_->cbClearDXgrid,
    ui_->disable_button_coloring_check_box,
    ui_->cb_showDistance,
    ui_->cb_showAzimuth,
    ui_->cb_Align,
    ui_->align_spin_box,
    ui_->align_spin_box2,
  });

  register_settings_focus_page (ui_->radio_tab, {
    ui_->rig_combo_box,
    ui_->CAT_poll_interval_spin_box,
    ui_->CAT_port_combo_box,
    ui_->CAT_serial_baud_combo_box,
    ui_->CAT_default_bit_radio_button,
    ui_->CAT_7_bit_radio_button,
    ui_->CAT_8_bit_radio_button,
    ui_->CAT_default_stop_bit_radio_button,
    ui_->CAT_one_stop_bit_radio_button,
    ui_->CAT_two_stop_bit_radio_button,
    ui_->CAT_handshake_default_radio_button,
    ui_->CAT_handshake_none_radio_button,
    ui_->CAT_handshake_xon_radio_button,
    ui_->CAT_handshake_hardware_radio_button,
    ui_->force_DTR_combo_box,
    ui_->force_RTS_combo_box,
    ui_->PTT_VOX_radio_button,
    ui_->PTT_DTR_radio_button,
    ui_->PTT_CAT_radio_button,
    ui_->PTT_RTS_radio_button,
    ui_->PTT_port_combo_box,
    ui_->TX_source_data_radio_button,
    ui_->TX_source_mic_radio_button,
    ui_->mode_none_radio_button,
    ui_->mode_USB_radio_button,
    ui_->mode_data_radio_button,
    ui_->split_none_radio_button,
    ui_->split_rig_radio_button,
    ui_->split_emulate_radio_button,
    ui_->test_CAT_push_button,
    ui_->test_PTT_push_button,
    ui_->rbHamlib64,
    ui_->rbHamlib32,
    ui_->hamlib_download_button,
    ui_->revert_update_button,
    ui_->PWR_and_SWR_check_box,
    ui_->check_SWR_check_box,
  });

  register_settings_focus_page (ui_->audio_tab, {
    ui_->sound_input_combo_box,
    ui_->sound_input_channel_combo_box,
    ui_->sound_output_combo_box,
    ui_->sound_output_channel_combo_box,
    ui_->refresh_push_button,
    ui_->tci_audio_check_box,
    ui_->TCI_spin_box,
    ui_->cbSortAlphabetically,
    ui_->cbHideCARD,
    ui_->save_path_select_push_button,
    ui_->azel_path_select_push_button,
    ui_->checkBoxAzElExtraLines,
    ui_->checkBoxPwrBandTxMemory,
    ui_->checkBoxPwrBandTuneMemory,
  });

  register_settings_focus_page (ui_->tx_macros_tab, {
    ui_->add_macro_line_edit,
    ui_->add_macro_push_button,
    ui_->delete_macro_push_button,
    ui_->move_macro_up_push_button,
    ui_->move_macro_down_push_button,
    ui_->macros_list_view,
  });

  register_settings_focus_page (ui_->reporting_tab, {
    ui_->prompt_to_log_check_box,
    ui_->opCallEntry,
    ui_->cbAutoLog,
    ui_->cbContestingOnly,
    ui_->cbZZ00,
    ui_->cbLog4digitGrids,
    ui_->log_as_RTTY_check_box,
    ui_->report_in_comments_check_box,
    ui_->specOp_in_comments_check_box,
    ui_->psk_reporter_check_box,
    ui_->psk_reporter_tcpip_check_box,
    ui_->udp_server_line_edit,
    ui_->udp_server_port_spin_box,
    ui_->udp_interfaces_combo_box,
    ui_->udp_TTL_spin_box,
    ui_->accept_udp_requests_check_box,
    ui_->udpWindowToFront,
    ui_->udpWindowRestore,
    ui_->enable_n1mm_broadcast_check_box,
    ui_->n1mm_server_name_line_edit,
    ui_->n1mm_server_port_spin_box,
  });

  register_settings_focus_page (ui_->frequencies_tab, {
    ui_->calibration_slope_ppm_spin_box,
    ui_->calibration_intercept_spin_box,
    suggestions_browse_button_,
    suggestions_dismiss_button_,
    ui_->frequencies_actions_tool_button,
    ui_->frequencies_table_view,
    ui_->stations_actions_tool_button,
    ui_->stations_table_view,
  });

  register_settings_focus_page (ui_->colors_tab, {
    ui_->highlighting_list_view,
    ui_->highlighting_actions_tool_button,
    ui_->move_highlighting_up_push_button,
    ui_->move_highlighting_down_push_button,
    ui_->color_presets_tool_button,
    ui_->reset_highlighting_tool_button,
    ui_->rescan_log_push_button,
    ui_->highlight_by_mode_check_box,
    ui_->highlight_orange_check_box,
    ui_->highlight_orange_callsigns,
    ui_->only_fields_check_box,
    ui_->include_WAE_check_box,
    ui_->highlight_blue_check_box,
    ui_->highlight_blue_callsigns,
    ui_->highlight_73_check_box,
    ui_->LotW_CSV_URL_line_edit,
    ui_->LotW_CSV_fetch_push_button,
    ui_->LotW_days_since_upload_spin_box,
    ui_->CTY_download_button,
    ui_->CALL3_download_button,
    ui_->CALL3_EME_download_button,
  });

  register_settings_focus_page (ui_->advanced_tab, {
    ui_->sbNtrials,
    ui_->sbAggressive,
    ui_->cbTwoPass,
    ui_->sbDegrade,
    ui_->sbBandwidth,
    ui_->sbTxDelay,
    ui_->cbx2ToneSpacing,
    ui_->cbx4ToneSpacing,
    ui_->rbLowSidelobes,
    ui_->rbMaxSensitivity,
    ui_->cbSpecialOpActivity,
    ui_->rbFox,
    ui_->cbSuperFox,
    ui_->rbHound,
    ui_->cbOTP,
    ui_->OTPSeed,
    ui_->sbOTPinterval,
    ui_->cbShowOTP,
    ui_->OTPUrl,
    ui_->rbNA_VHF_Contest,
    ui_->cb_NCCC_Sprint,
    ui_->rbField_Day,
    ui_->Field_Day_Exchange,
    ui_->rbEU_VHF_Contest,
    ui_->rbRTTY_Roundup,
    ui_->RTTY_Exchange,
    ui_->rbWW_DIGI,
    ui_->rbARRL_Digi,
    ui_->rbQ65pileup,
    ui_->cbContestName,
    ui_->Contest_Name,
    ui_->cbCloudlog,
    ui_->leCloudlogApiUrl,
    ui_->leCloudlogApiKey,
    ui_->cbCloudlogStationProfile,
    ui_->pbTestCloudlog,
    ui_->cbEQSL,
    ui_->eqsluser_edit,
    ui_->eqslpasswd_edit,
    ui_->eqslnick_edit,
  });

  register_settings_focus_page (ui_->alerts_tab, {
    ui_->voices_combo_box,
    ui_->pb_test_alerts,
    ui_->cbContinent,
    ui_->cbContinentOB,
    ui_->cbDXCC,
    ui_->cbDXCCOB,
    ui_->cbCQZ,
    ui_->cbCQZOB,
    ui_->cbITUZ,
    ui_->cbITUZOB,
    ui_->cbGrid,
    ui_->cbGridOB,
    ui_->cbMyCall,
    ui_->cbWanted,
    ui_->cbDXcall,
    ui_->cbQSYmessage,
    ui_->cbCQ,
    ui_->pbAlerts,
  });

  register_settings_focus_page (ui_->filters_tab, {
    ui_->Territory1,
    ui_->Territory2,
    ui_->Territory3,
    ui_->Territory4,
    ui_->cbBlacklist,
    ui_->Blacklist1,
    ui_->Blacklist2,
    ui_->Blacklist3,
    ui_->Blacklist4,
    ui_->Blacklist5,
    ui_->Blacklist6,
    ui_->Blacklist7,
    ui_->Blacklist8,
    ui_->Blacklist9,
    ui_->Blacklist10,
    ui_->Blacklist11,
    ui_->Blacklist12,
    ui_->cbWhitelist,
    ui_->Whitelist1,
    ui_->Whitelist2,
    ui_->Whitelist3,
    ui_->Whitelist4,
    ui_->Whitelist5,
    ui_->Whitelist6,
    ui_->Whitelist7,
    ui_->Whitelist8,
    ui_->Whitelist9,
    ui_->Whitelist10,
    ui_->Whitelist11,
    ui_->Whitelist12,
    ui_->cbPass,
    ui_->Pass1,
    ui_->Pass2,
    ui_->Pass3,
    ui_->Pass4,
    ui_->Pass5,
    ui_->Pass6,
    ui_->Pass7,
    ui_->Pass8,
    ui_->Pass9,
    ui_->Pass10,
    ui_->Pass11,
    ui_->Pass12,
    ui_->cb_filters_for_word2,
    ui_->cb_filters_for_Wait_and_Pounce_only,
    ui_->cb_twoDays,
  });

  auto update_visibility_when_toggled = [this] (QAbstractButton *button) {
    connect (button, &QAbstractButton::toggled, this, &Configuration::impl::check_visibility);
  };
  update_visibility_when_toggled (ui_->cbSpecialOpActivity);
  update_visibility_when_toggled (ui_->rbFox);
  update_visibility_when_toggled (ui_->rbHound);
  update_visibility_when_toggled (ui_->rbNA_VHF_Contest);
  update_visibility_when_toggled (ui_->rbEU_VHF_Contest);
  update_visibility_when_toggled (ui_->rbField_Day);
  update_visibility_when_toggled (ui_->rbRTTY_Roundup);
  update_visibility_when_toggled (ui_->rbWW_DIGI);
  update_visibility_when_toggled (ui_->rbARRL_Digi);
  update_visibility_when_toggled (ui_->rbQ65pileup);
  update_visibility_when_toggled (ui_->cbOTP);
  update_visibility_when_toggled (ui_->cbContestName);

  {
    PerformanceTrace::Phase data_directories {"configuration.data_directories"};
    // Make sure the default save directory exists
    QString save_dir {"save"};
    default_save_directory_ = writeable_data_dir_;
    default_azel_directory_ = writeable_data_dir_;
    if (!default_save_directory_.mkpath (save_dir) || !default_save_directory_.cd (save_dir))
      {
        MessageBox::critical_message (this, tr ("Failed to create save directory"),
                                      tr ("path: \"%1\%")
                                      .arg (default_save_directory_.absoluteFilePath (save_dir)));
        throw std::runtime_error {"Failed to create save directory"};
      }

    // we now have a deafult save path that exists

    // make sure samples directory exists
    QString samples_dir {"samples"};
    if (!default_save_directory_.mkpath (samples_dir))
      {
        MessageBox::critical_message (this, tr ("Failed to create samples directory"),
                                      tr ("path: \"%1\"")
                                      .arg (default_save_directory_.absoluteFilePath (samples_dir)));
        throw std::runtime_error {"Failed to create samples directory"};
      }

    // copy in any new sample files to the sample directory
    QDir dest_dir {default_save_directory_};
    dest_dir.cd (samples_dir);
    
    QDir source_dir {":/" + samples_dir};
    source_dir.cd (save_dir);
    source_dir.cd (samples_dir);
    auto list = source_dir.entryInfoList (QStringList {{"*.wav"}}, QDir::Files | QDir::Readable);
    Q_FOREACH (auto const& item, list)
      {
        if (!dest_dir.exists (item.fileName ()))
          {
            QFile file {item.absoluteFilePath ()};
            file.copy (dest_dir.absoluteFilePath (item.fileName ()));
          }
      }
  }

  // this must be done after the default paths above are set
  {
    PerformanceTrace::Phase settings_read {"configuration.settings_read"};
    read_settings ();
  }
  {
    SettingsGroup g {settings_, "Configuration"};
    suggestion_notice_state_ = FrequencySuggestions::NoticeState {
      settings_->value ("SeenSuggestedFrequencyKeys").toStringList (),
      settings_->contains ("SeenSuggestedFrequencyKeys")};
  }

  // set up dynamic loading of audio devices
  connect (ui_->sound_input_combo_box, &LazyFillComboBox::about_to_show_popup, [this] () {
      QGuiApplication::setOverrideCursor (QCursor {Qt::WaitCursor});
      load_audio_devices (QAudio::AudioInput, ui_->sound_input_combo_box, &next_audio_input_device_);
      update_audio_channels (ui_->sound_input_combo_box, ui_->sound_input_combo_box->currentIndex (), ui_->sound_input_channel_combo_box, false);
      ui_->sound_input_channel_combo_box->setCurrentIndex (next_audio_input_channel_);
      QGuiApplication::restoreOverrideCursor ();
    });
  connect (ui_->sound_output_combo_box, &LazyFillComboBox::about_to_show_popup, [this] () {
      QGuiApplication::setOverrideCursor (QCursor {Qt::WaitCursor});
      load_audio_devices (QAudio::AudioOutput, ui_->sound_output_combo_box, &next_audio_output_device_);
      update_audio_channels (ui_->sound_output_combo_box, ui_->sound_output_combo_box->currentIndex (), ui_->sound_output_channel_combo_box, true);
      ui_->sound_output_channel_combo_box->setCurrentIndex (next_audio_output_channel_);
      QGuiApplication::restoreOverrideCursor ();
    });

  // set up dynamic loading of network interfaces
  connect (ui_->udp_interfaces_combo_box, &LazyFillComboBox::about_to_show_popup, [this] () {
      QGuiApplication::setOverrideCursor (QCursor {Qt::WaitCursor});
      load_network_interfaces (ui_->udp_interfaces_combo_box, udp_interface_names_);
      QGuiApplication::restoreOverrideCursor ();
    });
  connect (ui_->udp_interfaces_combo_box, &QComboBox::currentTextChanged, this, &Configuration::impl::validate_network_interfaces);

  // set up LoTW users CSV file fetching
  connect (&lotw_users_, &LotWUsers::load_finished, [this] () {
    ui_->LotW_CSV_fetch_push_button->setEnabled (true);
  });

  connect(&lotw_users_, &LotWUsers::progress, [this] (QString const& msg) {
      ui_->LotW_CSV_status_label->setText(msg);
  });

  lotw_users_.set_local_file_path (writeable_data_dir_.absoluteFilePath ("lotw-user-activity.csv"));

  connect (&cloudlog_, &Cloudlog::connection_check_finished, this, &Configuration::impl::handle_cloudlog_connection_check_result);

  //
  // validation
  //
  ui_->callsign_line_edit->setValidator (new CallsignValidator {this});
  ui_->grid_line_edit->setValidator (new MaidenheadLocatorValidator {this});
  auto latitude_validator = new QDoubleValidator {-90.0, 90.0, 8, this};
  latitude_validator->setNotation (QDoubleValidator::StandardNotation);
  latitude_validator->setLocale (QLocale::c ());
  ui_->latitude_line_edit->setValidator (latitude_validator);
  auto longitude_validator = new QDoubleValidator {-180.0, 180.0, 8, this};
  longitude_validator->setNotation (QDoubleValidator::StandardNotation);
  longitude_validator->setLocale (QLocale::c ());
  ui_->longitude_line_edit->setValidator (longitude_validator);

  auto location_enter_filter = new LocationLineEditEnterFilter {this};
  ui_->grid_line_edit->installEventFilter (location_enter_filter);
  ui_->latitude_line_edit->installEventFilter (location_enter_filter);
  ui_->longitude_line_edit->installEventFilter (location_enter_filter);
  // My Grid is only checked once editing is finished (see
  // on_grid_line_edit_editingFinished), since a partly typed locator
  // would briefly make grid-derived coordinates look user-entered.
  for (auto edit : {ui_->latitude_line_edit, ui_->longitude_line_edit})
    {
      connect (edit, &QLineEdit::textChanged, this, &Configuration::impl::update_home_coordinates_style);
    }

  ui_->add_macro_line_edit->setValidator (new QRegularExpressionValidator {message_alphabet, this});
  ui_->Field_Day_Exchange->setValidator (new QRegularExpressionValidator {field_day_exchange_re, this});
  ui_->RTTY_Exchange->setValidator (new QRegularExpressionValidator {RTTY_roundup_exchange_re, this});
  QRegularExpression b32(QString("(^[") + QString(BASE32_CHARSET)+QString(BASE32_CHARSET).toLower() + QString("]{16}$)|(^$)"));
  ui_->OTPSeed->setValidator(new QRegularExpressionValidator(b32, this));

  //
  // assign ids to radio buttons
  //
  ui_->CAT_data_bits_button_group->setId (ui_->CAT_default_bit_radio_button, TransceiverFactory::default_data_bits);
  ui_->CAT_data_bits_button_group->setId (ui_->CAT_7_bit_radio_button, TransceiverFactory::seven_data_bits);
  ui_->CAT_data_bits_button_group->setId (ui_->CAT_8_bit_radio_button, TransceiverFactory::eight_data_bits);

  ui_->CAT_stop_bits_button_group->setId (ui_->CAT_default_stop_bit_radio_button, TransceiverFactory::default_stop_bits);
  ui_->CAT_stop_bits_button_group->setId (ui_->CAT_one_stop_bit_radio_button, TransceiverFactory::one_stop_bit);
  ui_->CAT_stop_bits_button_group->setId (ui_->CAT_two_stop_bit_radio_button, TransceiverFactory::two_stop_bits);

  ui_->CAT_handshake_button_group->setId (ui_->CAT_handshake_default_radio_button, TransceiverFactory::handshake_default);
  ui_->CAT_handshake_button_group->setId (ui_->CAT_handshake_none_radio_button, TransceiverFactory::handshake_none);
  ui_->CAT_handshake_button_group->setId (ui_->CAT_handshake_xon_radio_button, TransceiverFactory::handshake_XonXoff);
  ui_->CAT_handshake_button_group->setId (ui_->CAT_handshake_hardware_radio_button, TransceiverFactory::handshake_hardware);

  ui_->PTT_method_button_group->setId (ui_->PTT_VOX_radio_button, TransceiverFactory::PTT_method_VOX);
  ui_->PTT_method_button_group->setId (ui_->PTT_CAT_radio_button, TransceiverFactory::PTT_method_CAT);
  ui_->PTT_method_button_group->setId (ui_->PTT_DTR_radio_button, TransceiverFactory::PTT_method_DTR);
  ui_->PTT_method_button_group->setId (ui_->PTT_RTS_radio_button, TransceiverFactory::PTT_method_RTS);

  ui_->TX_audio_source_button_group->setId (ui_->TX_source_mic_radio_button, TransceiverFactory::TX_audio_source_front);
  ui_->TX_audio_source_button_group->setId (ui_->TX_source_data_radio_button, TransceiverFactory::TX_audio_source_rear);

  ui_->TX_mode_button_group->setId (ui_->mode_none_radio_button, data_mode_none);
  ui_->TX_mode_button_group->setId (ui_->mode_USB_radio_button, data_mode_USB);
  ui_->TX_mode_button_group->setId (ui_->mode_data_radio_button, data_mode_data);

  ui_->split_mode_button_group->setId (ui_->split_none_radio_button, TransceiverFactory::split_mode_none);
  ui_->split_mode_button_group->setId (ui_->split_rig_radio_button, TransceiverFactory::split_mode_rig);
  ui_->split_mode_button_group->setId (ui_->split_emulate_radio_button, TransceiverFactory::split_mode_emulate);

  ui_->special_op_activity_button_group->setId (ui_->rbNA_VHF_Contest, static_cast<int> (SpecialOperatingActivity::NA_VHF));
  ui_->special_op_activity_button_group->setId (ui_->rbEU_VHF_Contest, static_cast<int> (SpecialOperatingActivity::EU_VHF));
  ui_->special_op_activity_button_group->setId (ui_->rbField_Day, static_cast<int> (SpecialOperatingActivity::FIELD_DAY));
  ui_->special_op_activity_button_group->setId (ui_->rbRTTY_Roundup, static_cast<int> (SpecialOperatingActivity::RTTY));
  ui_->special_op_activity_button_group->setId (ui_->rbWW_DIGI, static_cast<int> (SpecialOperatingActivity::WW_DIGI));
  ui_->special_op_activity_button_group->setId (ui_->rbARRL_Digi, static_cast<int> (SpecialOperatingActivity::ARRL_DIGI));
  ui_->special_op_activity_button_group->setId (ui_->rbFox, static_cast<int> (SpecialOperatingActivity::FOX));
  ui_->special_op_activity_button_group->setId (ui_->rbHound, static_cast<int> (SpecialOperatingActivity::HOUND));
  ui_->special_op_activity_button_group->setId (ui_->rbQ65pileup, static_cast<int> (SpecialOperatingActivity::Q65_PILEUP));

  //
  // setup PTT port combo box drop down content
  //
  {
    PerformanceTrace::Phase serial_ports {"configuration.serial_ports"};
    fill_port_combo_box (ui_->PTT_port_combo_box);
  }
  ui_->PTT_port_combo_box->addItem ("CAT");
  ui_->PTT_port_combo_box->setItemData (ui_->PTT_port_combo_box->count () - 1, "Delegate to proxy CAT service", Qt::ToolTipRole);

  //
  // setup hooks to keep audio channels aligned with devices
  //
  {
    using namespace std;
    using namespace std::placeholders;

    function<void (int)> cb (bind (&Configuration::impl::update_audio_channels, this, ui_->sound_input_combo_box, _1, ui_->sound_input_channel_combo_box, false));
    connect (ui_->sound_input_combo_box, static_cast<void (QComboBox::*)(int)> (&QComboBox::currentIndexChanged), cb);
    cb = bind (&Configuration::impl::update_audio_channels, this, ui_->sound_output_combo_box, _1, ui_->sound_output_channel_combo_box, true);
    connect (ui_->sound_output_combo_box, static_cast<void (QComboBox::*)(int)> (&QComboBox::currentIndexChanged), cb);
  }

  //
  // setup macros list view
  //
  ui_->macros_list_view->setModel (&next_macros_);
  ui_->macros_list_view->setItemDelegate (new MessageItemDelegate {this});
  ui_->macros_list_view->setTabKeyNavigation (false);

  macro_delete_action_ = new QAction {tr ("&Delete"), ui_->macros_list_view};
  ui_->macros_list_view->insertAction (nullptr, macro_delete_action_);
  connect (macro_delete_action_, &QAction::triggered, this, &Configuration::impl::delete_macro);

  // setup IARU region combo box model
  ui_->region_combo_box->setModel (&regions_);

  //
  // setup working frequencies table model & view
  //
  frequencies_.sort (FrequencyList_v2_101::frequency_column);

  ui_->frequencies_table_view->setModel (&next_frequencies_);
  connect (&next_frequencies_, &QAbstractItemModel::dataChanged,
           this, [this] { refresh_suggestion_notice (); });
  connect (&next_frequencies_, &QAbstractItemModel::rowsInserted,
           this, [this] { refresh_suggestion_notice (); });
  connect (&next_frequencies_, &QAbstractItemModel::rowsRemoved,
           this, [this] { refresh_suggestion_notice (); });
  connect (&next_frequencies_, &QAbstractItemModel::modelReset,
           this, [this] { refresh_suggestion_notice (); });
  ui_->frequencies_table_view->setTabKeyNavigation (false);
  ui_->frequencies_table_view->horizontalHeader ()->setSectionResizeMode (QHeaderView::ResizeToContents);

  ui_->frequencies_table_view->horizontalHeader ()->setResizeContentsPrecision (0);
  ui_->frequencies_table_view->horizontalHeader ()->moveSection(8, 3); // swap preferred to be in front of description
  ui_->frequencies_table_view->verticalHeader ()->setSectionResizeMode (QHeaderView::ResizeToContents);
  ui_->frequencies_table_view->verticalHeader ()->setResizeContentsPrecision (0);
  ui_->frequencies_table_view->sortByColumn (FrequencyList_v2_101::frequency_column, Qt::AscendingOrder);
  ui_->frequencies_table_view->setColumnHidden (FrequencyList_v2_101::frequency_mhz_column, true);
  ui_->frequencies_table_view->setColumnHidden (FrequencyList_v2_101::source_column, true);

  // delegates
  ui_->frequencies_table_view->setItemDelegateForColumn (FrequencyList_v2_101::frequency_column, new FrequencyDelegate {this});
  ui_->frequencies_table_view->setItemDelegateForColumn (FrequencyList_v2_101::region_column, new ForeignKeyDelegate {&regions_, 0, this});
  ui_->frequencies_table_view->setItemDelegateForColumn (FrequencyList_v2_101::mode_column, new ForeignKeyDelegate {&modes_, 0, this});

  // actions
  frequency_delete_action_ = new QAction {tr ("&Delete"), ui_->frequencies_table_view};
  ui_->frequencies_table_view->insertAction (nullptr, frequency_delete_action_);
  connect (frequency_delete_action_, &QAction::triggered, this, &Configuration::impl::delete_frequencies);

  frequency_insert_action_ = new QAction {tr ("&Insert ..."), ui_->frequencies_table_view};
  ui_->frequencies_table_view->insertAction (nullptr, frequency_insert_action_);
  connect (frequency_insert_action_, &QAction::triggered, this, &Configuration::impl::insert_frequency);

  suggested_frequencies_action_ = new QAction {tr ("Add suggested frequencies ..."), ui_->frequencies_table_view};
  ui_->frequencies_table_view->insertAction (nullptr, suggested_frequencies_action_);
  connect (suggested_frequencies_action_, &QAction::triggered,
           this, &Configuration::impl::show_suggested_frequencies);

  load_frequencies_action_ = new QAction {tr ("&Load ..."), ui_->frequencies_table_view};
  ui_->frequencies_table_view->insertAction (nullptr, load_frequencies_action_);
  connect (load_frequencies_action_, &QAction::triggered, this, &Configuration::impl::load_frequencies);

  save_frequencies_action_ = new QAction {tr ("&Save as ..."), ui_->frequencies_table_view};
  ui_->frequencies_table_view->insertAction (nullptr, save_frequencies_action_);
  connect (save_frequencies_action_, &QAction::triggered, this, &Configuration::impl::save_frequencies);

  merge_frequencies_action_ = new QAction {tr ("&Merge ..."), ui_->frequencies_table_view};
  ui_->frequencies_table_view->insertAction (nullptr, merge_frequencies_action_);
  connect (merge_frequencies_action_, &QAction::triggered, this, &Configuration::impl::merge_frequencies);

  reset_frequencies_action_ = new QAction {tr ("&Reset"), ui_->frequencies_table_view};
  ui_->frequencies_table_view->insertAction (nullptr, reset_frequencies_action_);
  connect (reset_frequencies_action_, &QAction::triggered, this, &Configuration::impl::reset_frequencies);

  auto frequencies_actions_menu = new QMenu {ui_->frequencies_actions_tool_button};
  frequencies_actions_menu->addAction (frequency_insert_action_);
  frequencies_actions_menu->addAction (frequency_delete_action_);
  frequencies_actions_menu->addSeparator ();
  frequencies_actions_menu->addAction (suggested_frequencies_action_);
  frequencies_actions_menu->addAction (load_frequencies_action_);
  frequencies_actions_menu->addAction (save_frequencies_action_);
  frequencies_actions_menu->addAction (merge_frequencies_action_);
  frequencies_actions_menu->addSeparator ();
  frequencies_actions_menu->addAction (reset_frequencies_action_);
  ui_->frequencies_actions_tool_button->setMenu (frequencies_actions_menu);

  //
  // setup stations table model & view
  //
  stations_.sort (StationList::band_column);
  ui_->stations_table_view->setModel (&next_stations_);
  ui_->stations_table_view->setTabKeyNavigation (false);
  ui_->stations_table_view->horizontalHeader ()->setSectionResizeMode (QHeaderView::ResizeToContents);
  ui_->stations_table_view->horizontalHeader ()->setResizeContentsPrecision (0);
  ui_->stations_table_view->verticalHeader ()->setSectionResizeMode (QHeaderView::ResizeToContents);
  ui_->stations_table_view->verticalHeader ()->setResizeContentsPrecision (0);
  ui_->stations_table_view->sortByColumn (StationList::band_column, Qt::AscendingOrder);

  // stations delegates
  ui_->stations_table_view->setItemDelegateForColumn (StationList::offset_column, new FrequencyDeltaDelegate {this});
  ui_->stations_table_view->setItemDelegateForColumn (StationList::band_column, new ForeignKeyDelegate {&bands_, &next_stations_, 0, StationList::band_column, this});

  // stations actions
  ui_->stations_table_view->addAction (&station_delete_action_);
  connect (&station_delete_action_, &QAction::triggered, this, &Configuration::impl::delete_stations);

  ui_->stations_table_view->addAction (&station_insert_action_);
  connect (&station_insert_action_, &QAction::triggered, this, &Configuration::impl::insert_station);

  auto stations_actions_menu = new QMenu {ui_->stations_actions_tool_button};
  stations_actions_menu->addAction (&station_insert_action_);
  stations_actions_menu->addAction (&station_delete_action_);
  ui_->stations_actions_tool_button->setMenu (stations_actions_menu);

  //
  // colours and highlighting setup
  //
  ui_->highlighting_list_view->setModel (&next_decode_highlighing_model_);
  ui_->highlighting_list_view->setTabKeyNavigation (false);
  auto highlighting_actions_menu = new QMenu {ui_->highlighting_actions_tool_button};
  highlighting_actions_menu->addActions (ui_->highlighting_list_view->actions ());
  connect (highlighting_actions_menu, &QMenu::aboutToShow, this, [this, highlighting_actions_menu] {
      auto const has_current_rule = ui_->highlighting_list_view->currentIndex ().isValid ();
      for (auto action : highlighting_actions_menu->actions ())
        {
          action->setEnabled (has_current_rule);
        }
    });
  ui_->highlighting_actions_tool_button->setMenu (highlighting_actions_menu);

  auto color_presets_menu = new QMenu {ui_->color_presets_tool_button};
  auto default_colors_action = color_presets_menu->addAction (tr ("Default 1 colors (original)"));
  connect (default_colors_action, &QAction::triggered, this, [this] {
      apply_color_preset (DecodeHighlightingModel::default_color_preset ());
    });
  auto default2_colors_action = color_presets_menu->addAction (tr ("Default 2 colors (alternative)"));
  connect (default2_colors_action, &QAction::triggered, this, [this] {
      apply_color_preset (DecodeHighlightingModel::default2_color_preset ());
    });
  color_presets_menu->addSeparator ();
  auto red_green_colors_action = color_presets_menu->addAction (tr ("Red/green color-vision friendly"));
  connect (red_green_colors_action, &QAction::triggered, this, [this] {
      apply_color_preset (DecodeHighlightingModel::red_green_color_vision_preset ());
    });
  auto blue_yellow_colors_action = color_presets_menu->addAction (tr ("Blue/yellow color-vision friendly"));
  connect (blue_yellow_colors_action, &QAction::triggered, this, [this] {
      apply_color_preset (DecodeHighlightingModel::blue_yellow_color_vision_preset ());
    });
  auto high_contrast_colors_action = color_presets_menu->addAction (tr ("High contrast"));
  connect (high_contrast_colors_action, &QAction::triggered, this, [this] {
      apply_color_preset (DecodeHighlightingModel::high_contrast_color_preset ());
    });
  color_presets_menu->addSeparator ();
  auto dark_shack_colors_action = color_presets_menu->addAction (tr ("Dark shack"));
  connect (dark_shack_colors_action, &QAction::triggered, this, [this] {
      apply_color_preset (DecodeHighlightingModel::dark_shack_color_preset ());
    });
  auto solarized_colors_action = color_presets_menu->addAction (tr ("Solarized"));
  connect (solarized_colors_action, &QAction::triggered, this, [this] {
      apply_color_preset (DecodeHighlightingModel::solarized_color_preset ());
    });
  auto monochrome_colors_action = color_presets_menu->addAction (tr ("Monochrome"));
  connect (monochrome_colors_action, &QAction::triggered, this, [this] {
      apply_color_preset (DecodeHighlightingModel::monochrome_color_preset ());
    });
  ui_->color_presets_tool_button->setMenu (color_presets_menu);

  auto reset_highlighting_menu = new QMenu {ui_->reset_highlighting_tool_button};
  auto reset_default_action = reset_highlighting_menu->addAction (tr ("Default 1"));
  connect (reset_default_action, &QAction::triggered, this, [this] {
      reset_highlighting (tr ("Reset all decode highlighting and priorities to Default 1 values"),
                          DecodeHighlightingModel::default_items ());
    });
  auto reset_default2_action = reset_highlighting_menu->addAction (tr ("Default 2"));
  connect (reset_default2_action, &QAction::triggered, this, [this] {
      reset_highlighting (tr ("Reset all decode highlighting and priorities to Default 2 values"),
                          DecodeHighlightingModel::default_items2 ());
    });
  ui_->reset_highlighting_tool_button->setMenu (reset_highlighting_menu);

  {
    PerformanceTrace::Phase rig_models {"configuration.rig_models"};
    enumerate_rigs ();
  }
  {
    PerformanceTrace::Phase models {"configuration.models_initialize"};
    initialize_models ();
  }
  restart_tci_device_ = false;

  audio_input_device_ = next_audio_input_device_;
  audio_input_channel_ = next_audio_input_channel_;
  audio_output_device_ = next_audio_output_device_;
  audio_output_channel_ = next_audio_output_channel_;

  bool fetch_if_needed {false};
  for (auto const& item : decode_highlighing_model_.items ())
    {
      if (DecodeHighlightingModel::Highlight::LotW == item.type_)
        {
          fetch_if_needed = item.enabled_;
          break;
        }
    }
  // load the LoTW users dictionary if it exists, fetch and load if it
  // doesn't and we need it
  lotw_users_.load (ui_->LotW_CSV_URL_line_edit->text (), fetch_if_needed);

  transceiver_thread_ = new QThread {this};
  transceiver_thread_->start ();

  ui_->eqsluser_edit->setText (eqsl_username_);
  ui_->eqslpasswd_edit->setText (eqsl_passwd_);
  ui_->eqslnick_edit->setText (eqsl_nickname_);
  construction_trace_.finish ();
}

Configuration::impl::~impl ()
{
  {
    PerformanceTrace::Phase transceiver_thread {"transceiver_thread.shutdown"};
    transceiver_thread_->quit ();
    transceiver_thread_->wait ();
  }
  {
    PerformanceTrace::Phase settings_write {"configuration.settings_write"};
    write_settings ();
  }
}

void Configuration::impl::initialize_models ()
{
  QScopedValueRollback<bool> initializing_models {initializing_models_, true};

  next_audio_input_device_ = audio_input_device_;
  next_audio_input_channel_ = audio_input_channel_;
  next_audio_output_device_ = audio_output_device_;
  next_audio_output_channel_ = audio_output_channel_;
  restart_sound_input_device_ = false;
  restart_sound_output_device_ = false;
  restart_tci_device_ = false;

  {
    SettingsGroup g {settings_, "Configuration"};
    find_audio_devices ();
  }
  auto pal = ui_->callsign_line_edit->palette ();
  if (my_callsign_.isEmpty ())
    {
      pal.setColor (QPalette::Base, "#ffccff");
    }
  else
    {
      pal.setColor (QPalette::Base, Qt::white);
    }
  ui_->callsign_line_edit->setPalette (pal);
  ui_->grid_line_edit->setPalette (pal);
  ui_->callsign_line_edit->setText (my_callsign_);
  ui_->grid_line_edit->setText (my_grid_);
  ui_->latitude_line_edit->setText (have_home_coordinates_ ? QString::number (home_latitude_, 'f', 6) : QString {});
  ui_->longitude_line_edit->setText (have_home_coordinates_ ? QString::number (home_longitude_, 'f', 6) : QString {});
  if (!have_home_coordinates_) on_grid_line_edit_editingFinished ();
  update_home_coordinates_style ();
  ui_->use_dynamic_grid->setChecked(use_dynamic_grid_);
  ui_->CW_id_interval_spin_box->setValue (id_interval_);
  ui_->align_spin_box->setValue (align_steps_);
  ui_->align_spin_box2->setValue (align_steps2_);
  ui_->sbNtrials->setValue (ntrials_);
  ui_->TCI_spin_box->setValue (volume_);
  ui_->sbTxDelay->setValue (txDelay_);
  ui_->sbAggressive->setValue (aggressive_);
  ui_->sbDegrade->setValue (degrade_);
  ui_->sbBandwidth->setValue (RxBandwidth_);
  ui_->tci_audio_check_box->setChecked (tci_audio_);
  ui_->PTT_method_button_group->button (rig_params_.ptt_type)->setChecked (true);
  ui_->PWR_and_SWR_check_box->setChecked (PWR_and_SWR_);
  ui_->check_SWR_check_box->setChecked (check_SWR_);
  update_PWR_and_SWR_control_availability ();
  ui_->save_path_display_label->setText (save_directory_.absolutePath ());
  ui_->azel_path_display_label->setText (azel_directory_.absolutePath ());
  ui_->CW_id_after_73_check_box->setChecked (id_after_73_);
  ui_->tx_frequency_corrections_check_box->setChecked (tx_frequency_corrections_allowed_);
  ui_->progress_bar_check_box->setChecked (progressBar_red_);
  ui_->psk_reporter_check_box->setChecked (spot_to_psk_reporter_);
  ui_->psk_reporter_tcpip_check_box->setChecked (psk_reporter_tcpip_);
  ui_->monitor_off_check_box->setChecked (monitor_off_at_startup_);
  ui_->monitor_last_used_check_box->setChecked (monitor_last_used_);
  ui_->log_as_RTTY_check_box->setChecked (log_as_RTTY_);
  ui_->report_in_comments_check_box->setChecked (report_in_comments_);
  ui_->specOp_in_comments_check_box->setChecked (specOp_in_comments_);
  ui_->prompt_to_log_check_box->setChecked (prompt_to_log_);
  ui_->cbAutoLog->setChecked(autoLog_);
  ui_->cbContestingOnly->setChecked(contestingOnly_);
  update_logging_control_availability ();
  ui_->cbZZ00->setChecked(ZZ00_);
  ui_->cbLog4digitGrids->setChecked(log4digitGrids_);
  ui_->decodes_from_top_check_box->setChecked (decodes_from_top_);
  ui_->insert_blank_check_box->setChecked (insert_blank_);
  ui_->cb_detailed_blank_line->setChecked (detailed_blank_);
  ui_->DXCC_check_box->setChecked (DXCC_);
  ui_->ppfx_check_box->setChecked (ppfx_);
  ui_->show_country_names_check_box->setChecked (show_country_names_);
  update_DXCC_control_availability ();
  ui_->Map_Grid_to_State->setChecked(gridMap_);
  ui_->Map_All_Messages->setChecked(gridMapAll_);
  ui_->miles_check_box->setChecked (miles_);
  ui_->quick_call_check_box->setChecked (quick_call_);
  ui_->disable_TX_on_73_check_box->setChecked (disable_TX_on_73_);
  ui_->force_call_1st_check_box->setChecked (force_call_1st_);
  ui_->alternate_bindings_check_box->setChecked (alternate_bindings_);
  ui_->tx_watchdog_spin_box->setValue (watchdog_);
  ui_->tune_watchdog_check_box->setChecked(tune_watchdog_);
  ui_->tune_watchdog_spin_box->setValue (tune_watchdog_time_);
  ui_->TX_messages_check_box->setChecked (TX_messages_);
  ui_->enable_VHF_features_check_box->setChecked(enable_VHF_features_);
  ui_->decode_at_52s_check_box->setChecked(decode_at_52s_);
  ui_->kHz_without_k_check_box->setChecked(kHz_without_k_);
  ui_->disable_button_coloring_check_box->setChecked(button_coloring_disabled_);
  ui_->enable_Wait_features_check_box->setChecked(Wait_features_enabled_);
  ui_->cb_showDistance->setChecked(showDistance_);
  ui_->cb_showAzimuth->setChecked(showAzimuth_);
  ui_->cb_Align->setChecked(align_);
  ui_->repeat_Tx_check_box->setChecked(repeat_Tx_);
  ui_->auto_astro_check_box->setChecked(auto_astro_);
  ui_->single_decode_check_box->setChecked(single_decode_);
  ui_->cbTwoPass->setChecked(twoPass_);
  ui_->cbSuperFox->setChecked(bSuperFox_);
  ui_->cbContestName->setChecked(Individual_Contest_Name_);
  ui_->cb_NCCC_Sprint->setChecked(NCCC_Sprint_);
  ui_->cbBlacklist->setChecked(Blacklisted_);
  ui_->cbWhitelist->setChecked(Whitelisted_);
  ui_->cbPass->setChecked(AlwaysPass_);
  ui_->cb_filters_for_Wait_and_Pounce_only->setChecked(filters_for_Wait_and_Pounce_only_);
  ui_->cb_filters_for_word2->setChecked(filters_for_word2_);
  ui_->cb_twoDays->setChecked(twoDays_);
  ui_->cbSpecialOpActivity->setChecked(bSpecialOp_);
  ui_->cbCloudlog->setChecked(bCloudLog_);
  ui_->cbEQSL->setChecked(send_to_eqsl_);
  ui_->leCloudlogApiUrl->setText(cloudLogApiUrl_);
  ui_->leCloudlogApiKey->setText(cloudLogApiKey_);
  ui_->cbCloudlogStationProfile->clear ();
  if (cloudLogStationID_ > 0)
    {
      ui_->cbCloudlogStationProfile->addItem (QString::number (cloudLogStationID_), cloudLogStationID_);
    }
  on_cbCloudlog_toggled (ui_->cbCloudlog->isChecked ());
  on_cbEQSL_toggled (ui_->cbEQSL->isChecked ());
  ui_->special_op_activity_button_group->button (SelectedActivity_)->setChecked (true);
  ui_->cbx2ToneSpacing->setChecked(x2ToneSpacing_);
  ui_->cbx4ToneSpacing->setChecked(x4ToneSpacing_);
  ui_->type_2_msg_gen_combo_box->setCurrentIndex (type_2_msg_gen_);
  ui_->rig_combo_box->setCurrentText (rig_params_.rig_name);
  ui_->TX_mode_button_group->button (data_mode_)->setChecked (true);
  ui_->split_mode_button_group->button (rig_params_.split_mode)->setChecked (true);
  ui_->CAT_serial_baud_combo_box->setCurrentText (QString::number (rig_params_.baud));
  ui_->CAT_data_bits_button_group->button (rig_params_.data_bits)->setChecked (true);
  ui_->CAT_stop_bits_button_group->button (rig_params_.stop_bits)->setChecked (true);
  ui_->CAT_handshake_button_group->button (rig_params_.handshake)->setChecked (true);
  ui_->cbSortAlphabetically->setChecked(sortAlphabetically_);
  ui_->cbHideCARD->setChecked(hideCARD_);
  ui_->cbHideCARD->setEnabled(sortAlphabetically_);
  ui_->checkBoxAzElExtraLines->setChecked(AzElExtraLines_);
  ui_->checkBoxPwrBandTxMemory->setChecked(pwrBandTxMemory_);
  ui_->checkBoxPwrBandTuneMemory->setChecked(pwrBandTuneMemory_);
  if (rig_params_.force_dtr)
    {
      ui_->force_DTR_combo_box->setCurrentIndex (rig_params_.dtr_high ? 1 : 2);
    }
  else
    {
      ui_->force_DTR_combo_box->setCurrentIndex (0);
    }
  if (rig_params_.force_rts)
    {
      ui_->force_RTS_combo_box->setCurrentIndex (rig_params_.rts_high ? 1 : 2);
    }
  else
    {
      ui_->force_RTS_combo_box->setCurrentIndex (0);
    }
  ui_->TX_audio_source_button_group->button (rig_params_.audio_source)->setChecked (true);
  ui_->CAT_poll_interval_spin_box->setValue (rig_params_.poll_interval & 0x7fff);
  ui_->opCallEntry->setText (opCall_);
  ui_->udp_server_line_edit->setEnabled(false);
  ui_->udp_server_line_edit->setText (udp_server_name_);
  ui_->udp_server_line_edit->setEnabled(true);
  on_udp_server_line_edit_editingFinished ();
  ui_->udp_server_port_spin_box->setValue (udp_server_port_);
  load_network_interfaces (ui_->udp_interfaces_combo_box, udp_interface_names_);
  if (!udp_interface_names_.size ())
    {
      udp_interface_names_ = get_selected_network_interfaces (ui_->udp_interfaces_combo_box);
    }
  ui_->udp_TTL_spin_box->setValue (udp_TTL_);
  ui_->accept_udp_requests_check_box->setChecked (accept_udp_requests_);
  ui_->n1mm_server_name_line_edit->setText (n1mm_server_name_);
  ui_->n1mm_server_port_spin_box->setValue (n1mm_server_port_);
  ui_->enable_n1mm_broadcast_check_box->setChecked (broadcast_to_n1mm_);
  ui_->udpWindowToFront->setChecked(udpWindowToFront_);
  ui_->udpWindowRestore->setChecked(udpWindowRestore_);
  ui_->calibration_intercept_spin_box->setValue (calibration_.intercept);
  ui_->calibration_slope_ppm_spin_box->setValue (calibration_.slope_ppm);
  ui_->rbLowSidelobes->setChecked(bLowSidelobes_);
  if(!bLowSidelobes_) ui_->rbMaxSensitivity->setChecked(true);

  if (rig_params_.ptt_port.isEmpty ())
    {
      if (ui_->PTT_port_combo_box->count ())
        {
          ui_->PTT_port_combo_box->setCurrentText (ui_->PTT_port_combo_box->itemText (0));
        }
    }
  else
    {
      ui_->PTT_port_combo_box->setCurrentText (rig_params_.ptt_port);
    }

  ui_->region_combo_box->setCurrentIndex (region_);

  next_macros_.setStringList (macros_.stringList ());
  next_frequencies_.frequency_list (frequencies_.frequency_list ());
  if (suggestion_notice_state_.acknowledge_present_catalog (
        FrequencyList_v2_101::default_items (), frequencies_.frequency_list ()))
    persist_seen_suggestions ();
  refresh_suggestion_notice ();
  next_stations_.station_list (stations_.station_list ());

  next_decode_highlighing_model_.items (decode_highlighing_model_.items ());
  ui_->highlight_by_mode_check_box->setChecked (highlight_by_mode_);
  ui_->only_fields_check_box->setChecked (highlight_only_fields_);
  ui_->include_WAE_check_box->setChecked (include_WAE_entities_);
  ui_->highlight_73_check_box->setChecked (highlight_73_);
  ui_->highlight_orange_check_box->setChecked (highlight_orange_);
  ui_->highlight_blue_check_box->setChecked (highlight_blue_);
  ui_->alternate_erase_button_check_box->setChecked (alternate_erase_button_);
  ui_->LotW_days_since_upload_spin_box->setValue (LotW_days_since_upload_);
  ui_->cbHighlightDXcall->setChecked(highlight_DXcall_);
  ui_->cbClearDXcall->setChecked(clear_DXcall_);
  ui_->cbHighlightDXgrid->setChecked(highlight_DXgrid_);
  ui_->cbClearDXgrid->setChecked(clear_DXgrid_);
  ui_->cbEraseBandActivity->setChecked(erase_BandActivity_);
  ui_->cbRxToTxAfterQSO->setChecked(set_RXtoTX_);
  ui_->cbCQ->setChecked(alert_CQ_);
  ui_->cbMyCall->setChecked(alert_MyCall_);
  ui_->cbDXCC->setChecked(alert_DXCC_);
  ui_->cbDXCCOB->setChecked(alert_DXCCOB_);
  ui_->cbGrid->setChecked(alert_Grid_);
  ui_->cbGridOB->setChecked(alert_GridOB_);
  ui_->cbContinent->setChecked(alert_Continent_);
  ui_->cbContinentOB->setChecked(alert_ContinentOB_);
  ui_->cbCQZ->setChecked(alert_CQZ_);
  ui_->cbCQZOB->setChecked(alert_CQZOB_);
  ui_->cbITUZ->setChecked(alert_ITUZ_);
  ui_->cbITUZOB->setChecked(alert_ITUZOB_);
  ui_->cbDXcall->setChecked(alert_DXcall_);
  ui_->cbWanted->setChecked(alert_Wanted_);
  ui_->cbQSYmessage->setChecked(alert_QSYmessage_);
  ui_->pbAlerts->setChecked(alert_Enabled_);

  ui_->pbTestCloudlog->setStyleSheet ("QPushButton {background-color: none;}");

  check_visibility ();

  normalize_rig_selections (true);
  initializing_models_ = false;
  set_rig_invariants ();
}

void Configuration::impl::done (int r)
{
  // do this here since window is still on screen at this point
  SettingsGroup g {settings_, "Configuration"};
  settings_->setValue ("window/geometry", saveGeometry ());
  handle_leavingSettings();

  QDialog::done (r);
}

void Configuration::impl::read_settings ()
{
  SettingsGroup g {settings_, "Configuration"};
  LOG_INFO(QString{"Configuration Settings (%1)"}.arg(settings_->fileName()));
  QStringList keys = settings_->allKeys();

  use_default_geometry_ = !settings_->contains ("window/geometry");
  if (!use_default_geometry_)
    {
      restoreGeometry (settings_->value ("window/geometry").toByteArray ());
    }

  my_callsign_ = settings_->value ("MyCall", QString {}).toString ();
  my_grid_ = settings_->value ("MyGrid", QString {}).toString ();
  have_home_coordinates_ = settings_->contains ("HomeLatitude") && settings_->contains ("HomeLongitude");
  if (have_home_coordinates_)
    {
      home_latitude_ = settings_->value ("HomeLatitude").toDouble ();
      home_longitude_ = settings_->value ("HomeLongitude").toDouble ();
      have_home_coordinates_ = home_latitude_ >= -90. && home_latitude_ <= 90.
        && home_longitude_ >= -180. && home_longitude_ <= 180.;
    }
  FD_exchange_ = settings_->value ("Field_Day_Exchange",QString {}).toString ();
  RTTY_exchange_ = settings_->value ("RTTY_Exchange",QString {}).toString ();
  Contest_Name_ = settings_->value ("Contest_Name",QString {}).toString ();
  ui_->Field_Day_Exchange->setText(FD_exchange_);
  ui_->RTTY_Exchange->setText(RTTY_exchange_);
  ui_->Contest_Name->setText(Contest_Name_);

  Blacklist1_ = settings_->value ("Blacklist1",QString {}).toString ();
  Blacklist2_ = settings_->value ("Blacklist2",QString {}).toString ();
  Blacklist3_ = settings_->value ("Blacklist3",QString {}).toString ();
  Blacklist4_ = settings_->value ("Blacklist4",QString {}).toString ();
  Blacklist5_ = settings_->value ("Blacklist5",QString {}).toString ();
  Blacklist6_ = settings_->value ("Blacklist6",QString {}).toString ();
  Blacklist7_ = settings_->value ("Blacklist7",QString {}).toString ();
  Blacklist8_ = settings_->value ("Blacklist8",QString {}).toString ();
  Blacklist9_ = settings_->value ("Blacklist9",QString {}).toString ();
  Blacklist10_ = settings_->value ("Blacklist10",QString {}).toString ();
  Blacklist11_ = settings_->value ("Blacklist11",QString {}).toString ();
  Blacklist12_ = settings_->value ("Blacklist12",QString {}).toString ();
  Whitelist1_ = settings_->value ("Whitelist1",QString {}).toString ();
  Whitelist2_ = settings_->value ("Whitelist2",QString {}).toString ();
  Whitelist3_ = settings_->value ("Whitelist3",QString {}).toString ();
  Whitelist4_ = settings_->value ("Whitelist4",QString {}).toString ();
  Whitelist5_ = settings_->value ("Whitelist5",QString {}).toString ();
  Whitelist6_ = settings_->value ("Whitelist6",QString {}).toString ();
  Whitelist7_ = settings_->value ("Whitelist7",QString {}).toString ();
  Whitelist8_ = settings_->value ("Whitelist8",QString {}).toString ();
  Whitelist9_ = settings_->value ("Whitelist9",QString {}).toString ();
  Whitelist10_ = settings_->value ("Whitelist10",QString {}).toString ();
  Whitelist11_ = settings_->value ("Whitelist11",QString {}).toString ();
  Whitelist12_ = settings_->value ("Whitelist12",QString {}).toString ();
  Pass1_ = settings_->value ("Pass1",QString {}).toString ();
  Pass2_ = settings_->value ("Pass2",QString {}).toString ();
  Pass3_ = settings_->value ("Pass3",QString {}).toString ();
  Pass4_ = settings_->value ("Pass4",QString {}).toString ();
  Pass5_ = settings_->value ("Pass5",QString {}).toString ();
  Pass6_ = settings_->value ("Pass6",QString {}).toString ();
  Pass7_ = settings_->value ("Pass7",QString {}).toString ();
  Pass8_ = settings_->value ("Pass8",QString {}).toString ();
  Pass9_ = settings_->value ("Pass9",QString {}).toString ();
  Pass10_ = settings_->value ("Pass10",QString {}).toString ();
  Pass11_ = settings_->value ("Pass11",QString {}).toString ();
  Pass12_ = settings_->value ("Pass12",QString {}).toString ();
  Territory1_ = settings_->value ("Territory1",QString {}).toString ();
  Territory2_ = settings_->value ("Territory2",QString {}).toString ();
  Territory3_ = settings_->value ("Territory3",QString {}).toString ();
  Territory4_ = settings_->value ("Territory4",QString {}).toString ();
  highlight_orange_callsigns_ = settings_->value ("HighlightOrangeCallsigns",QString {}).toString ();
  highlight_blue_callsigns_ = settings_->value ("HighlightBlueCallsigns",QString {}).toString ();
  hamlib_backed_up_ = settings_->value ("HamlibBackedUp",QString {}).toString ();
  ui_->Blacklist1->setText(Blacklist1_);
  ui_->Blacklist2->setText(Blacklist2_);
  ui_->Blacklist3->setText(Blacklist3_);
  ui_->Blacklist4->setText(Blacklist4_);
  ui_->Blacklist5->setText(Blacklist5_);
  ui_->Blacklist6->setText(Blacklist6_);
  ui_->Blacklist7->setText(Blacklist7_);
  ui_->Blacklist8->setText(Blacklist8_);
  ui_->Blacklist9->setText(Blacklist9_);
  ui_->Blacklist10->setText(Blacklist10_);
  ui_->Blacklist11->setText(Blacklist11_);
  ui_->Blacklist12->setText(Blacklist12_);
  ui_->Whitelist1->setText(Whitelist1_);
  ui_->Whitelist2->setText(Whitelist2_);
  ui_->Whitelist3->setText(Whitelist3_);
  ui_->Whitelist4->setText(Whitelist4_);
  ui_->Whitelist5->setText(Whitelist5_);
  ui_->Whitelist6->setText(Whitelist6_);
  ui_->Whitelist7->setText(Whitelist7_);
  ui_->Whitelist8->setText(Whitelist8_);
  ui_->Whitelist9->setText(Whitelist9_);
  ui_->Whitelist10->setText(Whitelist10_);
  ui_->Whitelist11->setText(Whitelist11_);
  ui_->Whitelist12->setText(Whitelist12_);
  ui_->Pass1->setText(Pass1_);
  ui_->Pass2->setText(Pass2_);
  ui_->Pass3->setText(Pass3_);
  ui_->Pass4->setText(Pass4_);
  ui_->Pass5->setText(Pass5_);
  ui_->Pass6->setText(Pass6_);
  ui_->Pass7->setText(Pass7_);
  ui_->Pass8->setText(Pass8_);
  ui_->Pass9->setText(Pass9_);
  ui_->Pass10->setText(Pass10_);
  ui_->Pass11->setText(Pass11_);
  ui_->Pass12->setText(Pass12_);
  ui_->Territory1->setText(Territory1_);
  ui_->Territory2->setText(Territory2_);
  ui_->Territory3->setText(Territory3_);
  ui_->Territory4->setText(Territory4_);
  ui_->highlight_orange_callsigns->setText(highlight_orange_callsigns_);
  ui_->highlight_blue_callsigns->setText(highlight_blue_callsigns_);
  PWR_and_SWR_ = settings_->value ("PWRandSWR", false).toBool ();
  check_SWR_ = settings_->value ("CheckSWR", false).toBool ();

  OTPinterval_ = settings_->value ("OTPinterval", 1).toUInt ();
  OTPUrl_ = settings_->value ("OTPUrl", FoxVerifier::default_url()).toString ();
  OTPSeed_ = settings_->value ("OTPSeed", QString {}).toString ();
  OTPEnabled_ = settings_->value ("OTPEnabled", false).toBool ();
  ShowOTP_ = settings_->value ("ShowOTP", false).toBool ();

  ui_->sbOTPinterval->setValue(OTPinterval_);
  ui_->OTPUrl->setText(OTPUrl_);
  ui_->OTPSeed->setText(OTPSeed_);
  ui_->cbOTP->setChecked(OTPEnabled_);
  ui_->cbShowOTP->setChecked(ShowOTP_);

  if (next_font_.fromString (settings_->value ("Font", QGuiApplication::font ().toString ()).toString ())
      && next_font_ != font_)
    {
      font_ = next_font_;
      Q_EMIT self_->text_font_changed (font_);
    }
  else
    {
      next_font_ = font_;
    }
  if (next_decoded_text_font_.fromString (settings_->value ("DecodedTextFont", "Courier, 10").toString ())
      && next_decoded_text_font_ != decoded_text_font_)
    {
      decoded_text_font_ = next_decoded_text_font_;
      next_decode_highlighing_model_.set_font (decoded_text_font_);
      ui_->highlighting_list_view->reset ();
      Q_EMIT self_->decoded_text_font_changed (decoded_text_font_);
    }
  else
    {
      next_decoded_text_font_ = decoded_text_font_;
    }

  id_interval_ = settings_->value ("IDint", 0).toInt ();
  align_steps_ = settings_->value ("AlignSteps", 2).toInt ();
  align_steps2_ = settings_->value ("AlignSteps2", 0).toInt ();
  ntrials_ = settings_->value ("nTrials", 6).toInt ();
  volume_ = settings_->value ("volume", 0).toInt ();
  txDelay_ = settings_->value ("TxDelay",0.2).toDouble();
  aggressive_ = settings_->value ("Aggressive", 4).toInt ();
  RxBandwidth_ = settings_->value ("RxBandwidth", 2500).toInt ();
  save_directory_.setPath (settings_->value ("SaveDir", default_save_directory_.absolutePath ()).toString ());
  azel_directory_.setPath (settings_->value ("AzElDir", default_azel_directory_.absolutePath ()).toString ());

  tci_audio_ = settings_->value ("TCIAudio", false).toBool ();

  type_2_msg_gen_ = settings_->value ("Type2MsgGen", QVariant::fromValue (Configuration::type_2_msg_3_full)).value<Configuration::Type2MsgGen> ();

  monitor_off_at_startup_ = settings_->value ("MonitorOFF", false).toBool ();
  monitor_last_used_ = settings_->value ("MonitorLastUsed", false).toBool ();
  spot_to_psk_reporter_ = settings_->value ("PSKReporter", false).toBool ();
  psk_reporter_tcpip_ = settings_->value ("PSKReporterTCPIP", false).toBool ();
  eqsl_username_ = settings_->value ("EQSLUser", "").toString ();
  eqsl_passwd_ = settings_->value ("EQSLPasswd", "").toString ();
  eqsl_nickname_ = settings_->value ("EQSLNick", "").toString ();
  send_to_eqsl_ = settings_->value ("EQSLSend", false).toBool ();
  id_after_73_ = settings_->value ("After73", false).toBool ();
  tx_frequency_corrections_allowed_ = settings_->value ("TxQSYAllowed", false).toBool ();
  progressBar_red_ = settings_->value ("ProgressBarRed", true).toBool ();
  use_dynamic_grid_ = settings_->value ("AutoGrid", false).toBool ();

  macros_.setStringList (settings_->value ("Macros", QStringList {"TNX 73 GL"}).toStringList ());

  region_ = settings_->value ("Region", QVariant::fromValue (IARURegions::ALL)).value<IARURegions::Region> ();

  LOG_INFO(QString{"Reading frequencies"});

  if (settings_->contains ("FrequenciesForRegionModes_v2"))
    {
      LOG_INFO(QString{"read_settings found FrequenciesForRegionModes_v2"});
      if (settings_->contains ("FrequenciesForRegionModes"))
        {
          LOG_INFO(QString{"read_settings ALSO found FrequenciesForRegionModes"});
        }

      auto const& v = settings_->value ("FrequenciesForRegionModes_v2");
      if (v.isValid ())
        {
          frequencies_.frequency_list (v.value<FrequencyList_v2_101::FrequencyItems> ());
        }
      else
        {
          frequencies_.reset_to_defaults ();
        }
    }
  else
    {
      LOG_INFO(QString{"read_settings looking for FrequenciesForRegionModes"});
      if (settings_->contains ("FrequenciesForRegionModes")) // has the old ones.
        {
          LOG_INFO(QString{"found FrequenciesForRegionModes"});
          auto const& v = settings_->value("FrequenciesForRegionModes");
          LOG_INFO(QString{"v is %1"}.arg(v.typeName()));
          if (v.isValid())
            {
              LOG_INFO(QString{"read_settings found VALID FrequenciesForRegionModes"});
              FrequencyList_v2_101::FrequencyItems list;
              FrequencyList_v2::FrequencyItems v100 = v.value<FrequencyList_v2::FrequencyItems>();
              LOG_INFO(QString{"read_settings read %1 old_format items from FrequenciesForRegionModes"}.arg(v100.size()));

              Q_FOREACH (auto const& item, v100)
              {
                list << FrequencyList_v2_101::Item{item.frequency_, item.mode_, item.region_, QString(), QString(), QDateTime(),
                                               QDateTime(), false};
              }
              LOG_INFO(QString{"converted %1 items to FrequenciesForRegionModes_v2"}.arg(list.size()));

              frequencies_.frequency_list(list);
            }
            else
            {
              LOG_INFO(QString{"read_settings INVALID FrequenciesForRegionModes"});
              frequencies_.reset_to_defaults();
            }
        }
      else
        {
          frequencies_.reset_to_defaults();
        }
    }

  stations_.station_list (settings_->value ("stations").value<StationList::Stations> ());

  auto highlight_items = settings_->value ("DecodeHighlighting", QVariant::fromValue (DecodeHighlightingModel::default_items ())).value<DecodeHighlightingModel::HighlightItems> ();
  if (!highlight_items.size ()) highlight_items = DecodeHighlightingModel::default_items ();
  decode_highlighing_model_.items (highlight_items);
  highlight_by_mode_ = settings_->value("HighlightByMode", false).toBool ();
  highlight_only_fields_ = settings_->value("OnlyFieldsSought", false).toBool ();
  include_WAE_entities_ = settings_->value("IncludeWAEEntities", false).toBool ();
  highlight_73_ = settings_->value("Highlight73", true).toBool ();
  highlight_orange_ = settings_->value("HighlightOrange", false).toBool ();
  highlight_blue_ = settings_->value("HighlightBlue", false).toBool ();
  alternate_erase_button_ = settings_->value("AlternateEraseButtonBehavior", true).toBool ();
  show_country_names_ = settings_->value("AlwaysShowCountryNames", false).toBool ();
  LotW_days_since_upload_ = settings_->value ("LotWDaysSinceLastUpload", 365).toInt ();
  lotw_users_.set_age_constraint (LotW_days_since_upload_);

  log_as_RTTY_ = settings_->value ("toRTTY", false).toBool ();
  report_in_comments_ = settings_->value("dBtoComments", false).toBool ();
  specOp_in_comments_ = settings_->value("specOptoComments", false).toBool ();
  rig_params_.rig_name = settings_->value ("Rig", TransceiverFactory::basic_transceiver_name_).toString ();
  rig_is_dummy_ = TransceiverFactory::basic_transceiver_name_ == rig_params_.rig_name;
  is_tci_ = rig_params_.rig_name.startsWith("TCI Cli");
  rig_params_.tci_port = settings_->value ("CATTCIPort","").toString ();
  rig_params_.network_port = settings_->value ("CATNetworkPort").toString ();
  rig_params_.usb_port = settings_->value ("CATUSBPort").toString ();
  rig_params_.serial_port = settings_->value ("CATSerialPort").toString ();
  rig_params_.baud = settings_->value ("CATSerialRate", 4800).toInt ();
  rig_params_.data_bits = settings_->value ("CATDataBits", QVariant::fromValue (TransceiverFactory::default_data_bits)).value<TransceiverFactory::DataBits> ();
  rig_params_.stop_bits = settings_->value ("CATStopBits", QVariant::fromValue (TransceiverFactory::default_stop_bits)).value<TransceiverFactory::StopBits> ();
  rig_params_.handshake = settings_->value ("CATHandshake", QVariant::fromValue (TransceiverFactory::handshake_default)).value<TransceiverFactory::Handshake> ();
  rig_params_.force_dtr = settings_->value ("CATForceDTR", false).toBool ();
  rig_params_.dtr_high = settings_->value ("DTR", false).toBool ();
  rig_params_.force_rts = settings_->value ("CATForceRTS", false).toBool ();
  rig_params_.rts_high = settings_->value ("RTS", false).toBool ();
  rig_params_.ptt_type = settings_->value ("PTTMethod", QVariant::fromValue (TransceiverFactory::PTT_method_VOX)).value<TransceiverFactory::PTTMethod> ();
  rig_params_.audio_source = settings_->value ("TXAudioSource", QVariant::fromValue (TransceiverFactory::TX_audio_source_front)).value<TransceiverFactory::TXAudioSource> ();
  rig_params_.ptt_port = settings_->value ("PTTport").toString ();
  data_mode_ = settings_->value ("DataMode", QVariant::fromValue (data_mode_none)).value<Configuration::DataMode> ();
  bLowSidelobes_ = settings_->value("LowSidelobes",true).toBool();
  prompt_to_log_ = settings_->value ("PromptToLog", false).toBool ();
  autoLog_ = settings_->value ("AutoLog", true).toBool ();
  if (prompt_to_log_ && autoLog_) prompt_to_log_ = false;
  contestingOnly_ = settings_->value ("ContestingOnly", true).toBool ();
  ZZ00_ = settings_->value("ZZ00",false).toBool ();
  log4digitGrids_ = settings_->value ("Log4digitGrids", false).toBool ();
  decodes_from_top_ = settings_->value ("DecodesFromTop", false).toBool ();
  insert_blank_ = settings_->value ("InsertBlank", true).toBool ();
  detailed_blank_ = settings_->value ("DetailedBlank", true).toBool ();
  DXCC_ = settings_->value ("DXCCEntity", true).toBool ();
  gridMap_ = settings_->value("MapGridEntity", true).toBool();
  gridMapAll_ = settings_->value("MapGridAllEntity", true).toBool();
  ppfx_ = settings_->value ("PrincipalPrefix", false).toBool ();
  miles_ = settings_->value ("Miles", false).toBool ();
  quick_call_ = settings_->value ("QuickCall", true).toBool ();
  disable_TX_on_73_ = settings_->value ("73TxDisable", true).toBool ();
  force_call_1st_ = settings_->value ("ForceCallFirst", false).toBool ();
  alternate_bindings_ = settings_->value ("AlternateBindings", false).toBool ();
  watchdog_ = settings_->value ("TxWatchdog", 6).toInt ();
  tune_watchdog_ = settings_->value("TuneWatchdog",true).toBool ();
  tune_watchdog_time_ = settings_->value ("TuneWatchdogTime", 90).toInt ();
  TX_messages_ = settings_->value ("Tx2QSO", true).toBool ();
  enable_VHF_features_ = settings_->value("VHFUHF",false).toBool ();
  decode_at_52s_ = settings_->value("Decode52",false).toBool ();
  kHz_without_k_ = settings_->value("kHzWithoutK",false).toBool ();
  button_coloring_disabled_ = settings_->value("TxWarningDisabled",false).toBool ();
  Wait_features_enabled_ = settings_->value("WaitFeaturesEnabled",true).toBool ();
  showDistance_ = settings_->value("showDistance", false).toBool();
  showAzimuth_ = settings_->value("showAzimuth", false).toBool();
  align_ = settings_->value("AlignDistanceAzimuth", true).toBool();
  repeat_Tx_ = settings_->value("RepeatTx",false).toBool ();
  auto_astro_ = settings_->value("AutoAstroWindow",false).toBool ();
  single_decode_ = settings_->value("SingleDecode",false).toBool ();
  twoPass_ = settings_->value("TwoPass",true).toBool ();
  bSuperFox_ = settings_->value("SuperFox",true).toBool ();
  Individual_Contest_Name_ = settings_->value("Individual_Contest_Name",false).toBool ();
  NCCC_Sprint_ = settings_->value("NCCC_Sprint",false).toBool ();
  Blacklisted_ = settings_->value("Blacklisted",false).toBool ();
  Whitelisted_ = settings_->value("Whitelisted",false).toBool ();
  AlwaysPass_ = settings_->value("AlwaysPass",false).toBool ();
  filters_for_Wait_and_Pounce_only_ = settings_->value("FiltersForWaitAndPounceOnly",false).toBool ();
  filters_for_word2_ = settings_->value("FiltersForWord2",false).toBool ();
  twoDays_ = settings_->value("TwoDays",false).toBool ();
  bSpecialOp_ = settings_->value("SpecialOpActivity",false).toBool ();
  bCloudLog_ = settings_->value("CloudLog",false).toBool ();
  cloudLogApiUrl_ = settings_->value ("CloudLogApiUrl", QString {}).toString ();
  cloudLogApiKey_ = settings_->value ("CloudLogApiKey", QString {}).toString ();
  cloudLogStationID_ = settings_->value("CloudLogStationID",1).toInt ();
  SelectedActivity_ = settings_->value("SelectedActivity",1).toInt ();
  x2ToneSpacing_ = settings_->value("x2ToneSpacing",false).toBool ();
  x4ToneSpacing_ = settings_->value("x4ToneSpacing",false).toBool ();
  if (x4ToneSpacing_) x2ToneSpacing_ = false;
  rig_params_.poll_interval = settings_->value ("Polling", 0).toInt ();
  rig_params_.split_mode = settings_->value ("SplitMode", QVariant::fromValue (TransceiverFactory::split_mode_none)).value<TransceiverFactory::SplitMode> ();
  opCall_ = settings_->value ("OpCall", "").toString ();
  udp_server_name_ = settings_->value ("UDPServer", "127.0.0.1").toString ();
  udp_interface_names_ = settings_->value ("UDPInterface").toStringList ();
  udp_TTL_ = settings_->value ("UDPTTL", 1).toInt ();
  udp_server_port_ = settings_->value ("UDPServerPort", 2237).toUInt ();
  n1mm_server_name_ = settings_->value ("N1MMServer", "127.0.0.1").toString ();
  n1mm_server_port_ = settings_->value ("N1MMServerPort", 2333).toUInt ();
  broadcast_to_n1mm_ = settings_->value ("BroadcastToN1MM", false).toBool ();
  accept_udp_requests_ = settings_->value ("AcceptUDPRequests", false).toBool ();
  udpWindowToFront_ = settings_->value ("udpWindowToFront",false).toBool ();
  udpWindowRestore_ = settings_->value ("udpWindowRestore",false).toBool ();
  calibration_.intercept = settings_->value ("CalibrationIntercept", 0.).toDouble ();
  calibration_.slope_ppm = settings_->value ("CalibrationSlopePPM", 0.).toDouble ();
  sortAlphabetically_ = settings_->value("SortAlphabetically",true).toBool ();
  hideCARD_ = settings_->value("HideCARD",true).toBool ();
  AzElExtraLines_ = settings_->value("AzElExtraLines",false).toBool ();
  pwrBandTxMemory_ = settings_->value("pwrBandTxMemory",false).toBool ();
  pwrBandTuneMemory_ = settings_->value("pwrBandTuneMemory",false).toBool ();
  highlight_DXcall_ = settings_->value("highlight_DXcall",true).toBool ();
  clear_DXcall_ = settings_->value("clear_DXcall",false).toBool ();
  highlight_DXgrid_ = settings_->value("highlight_DXgrid",true).toBool ();
  clear_DXgrid_ = settings_->value("clear_DXgrid",false).toBool ();
  erase_BandActivity_ = settings_->value("erase_BandActivity",false).toBool ();
  set_RXtoTX_ = settings_->value("set_RXtoTX",false).toBool ();
  alert_CQ_ = settings_->value("alert_CQ",false).toBool ();
  alert_MyCall_ = settings_->value("alert_MyCall",false).toBool ();
  alert_DXCC_ = settings_->value("alert_DXCC",false).toBool ();
  alert_DXCCOB_ = settings_->value("alert_DXCCOB",false).toBool ();
  alert_Grid_ = settings_->value("alert_Grid",false).toBool ();
  alert_GridOB_ = settings_->value("alert_GridOB",false).toBool ();
  alert_Continent_ = settings_->value("alert_Continent",false).toBool ();
  alert_ContinentOB_ = settings_->value("alert_ContinentOB",false).toBool ();
  alert_CQZ_ = settings_->value("alert_CQZ",false).toBool ();
  alert_CQZOB_ = settings_->value("alert_CQZOB",false).toBool ();
  alert_ITUZ_ = settings_->value("alert_ITUZ",false).toBool ();
  alert_ITUZOB_ = settings_->value("alert_ITUZOB",false).toBool ();
  alert_DXcall_ = settings_->value("alert_DXcall",false).toBool ();
  alert_Wanted_ = settings_->value("alert_Wanted",false).toBool ();
  alert_QSYmessage_ = settings_->value("alert_QSYmessage",false).toBool ();
  alert_Enabled_ = settings_->value("alert_Enabled",false).toBool ();
  voice_ = settings_->value ("Voice", 0).toInt ();
  read_voices();
  // Reset Rig to None if TCI was selected but no IP address was specified
  if (is_tci_ && settings_->value("CATTCIPort")=="") {
    rig_params_.rig_name = "None";
    if (rig_params_.ptt_type == TransceiverFactory::PTT_method_CAT) rig_params_.ptt_type = TransceiverFactory::PTT_method_VOX;
  }
#ifdef WIN32
  QTimer::singleShot (2500, this, &Configuration::impl::display_file_information);
#else
  ui_->hamlib_groupBox->setTitle("Hamlib Version");
  ui_->rbHamlib64->setVisible(false);
  ui_->rbHamlib32->setVisible(false);
  ui_->hamlib_download_button->setVisible(false);
  ui_->revert_update_button->setVisible(false);
  ui_->backed_up_text->setVisible(false);
  ui_->backed_up->setVisible(false);
  QTimer::singleShot (2500, this, &Configuration::impl::display_file_information);
#endif
}

void Configuration::impl::find_audio_devices ()
{
  //
  // retrieve audio input device
  //
  auto saved_name = settings_->value ("SoundInName").toString ();
  if (is_tci_ && tci_audio_) saved_name = "TCI audio";  // TCI
  if (next_audio_input_device_.deviceName () != saved_name || next_audio_input_device_.isNull ())
    {
      next_audio_input_device_ = find_audio_device (QAudio::AudioInput, ui_->sound_input_combo_box, saved_name);
      next_audio_input_channel_ = AudioDevice::fromString (settings_->value ("AudioInputChannel", "Mono").toString ());
      update_audio_channels (ui_->sound_input_combo_box, ui_->sound_input_combo_box->currentIndex (), ui_->sound_input_channel_combo_box, false);
      ui_->sound_input_channel_combo_box->setCurrentIndex (next_audio_input_channel_);
    }
  //
  // retrieve audio output device
  //
  saved_name = settings_->value("SoundOutName").toString();
  if (is_tci_ && tci_audio_) saved_name = "TCI audio";  // TCI
  if (next_audio_output_device_.deviceName () != saved_name || next_audio_output_device_.isNull ())
    {
      next_audio_output_device_ = find_audio_device (QAudio::AudioOutput, ui_->sound_output_combo_box, saved_name);
      next_audio_output_channel_ = AudioDevice::fromString (settings_->value ("AudioOutputChannel", "Mono").toString ());
      update_audio_channels (ui_->sound_output_combo_box, ui_->sound_output_combo_box->currentIndex (), ui_->sound_output_channel_combo_box, true);
      ui_->sound_output_channel_combo_box->setCurrentIndex (next_audio_output_channel_);
    }
}

void Configuration::impl::write_settings ()
{
  SettingsGroup g {settings_, "Configuration"};

  settings_->setValue ("MyCall", my_callsign_);
  settings_->setValue ("MyGrid", my_grid_);
  if (have_home_coordinates_)
    {
      settings_->setValue ("HomeLatitude", home_latitude_);
      settings_->setValue ("HomeLongitude", home_longitude_);
    }
  else
    {
      settings_->remove ("HomeLatitude");
      settings_->remove ("HomeLongitude");
    }
  settings_->setValue ("Field_Day_Exchange", FD_exchange_);
  settings_->setValue ("RTTY_Exchange", RTTY_exchange_);
  settings_->setValue ("Contest_Name", Contest_Name_);
  settings_->setValue ("Blacklist1", Blacklist1_);
  settings_->setValue ("Blacklist2", Blacklist2_);
  settings_->setValue ("Blacklist3", Blacklist3_);
  settings_->setValue ("Blacklist4", Blacklist4_);
  settings_->setValue ("Blacklist5", Blacklist5_);
  settings_->setValue ("Blacklist6", Blacklist6_);
  settings_->setValue ("Blacklist7", Blacklist7_);
  settings_->setValue ("Blacklist8", Blacklist8_);
  settings_->setValue ("Blacklist9", Blacklist9_);
  settings_->setValue ("Blacklist10", Blacklist10_);
  settings_->setValue ("Blacklist11", Blacklist11_);
  settings_->setValue ("Blacklist12", Blacklist12_);
  settings_->setValue ("Whitelist1", Whitelist1_);
  settings_->setValue ("Whitelist2", Whitelist2_);
  settings_->setValue ("Whitelist3", Whitelist3_);
  settings_->setValue ("Whitelist4", Whitelist4_);
  settings_->setValue ("Whitelist5", Whitelist5_);
  settings_->setValue ("Whitelist6", Whitelist6_);
  settings_->setValue ("Whitelist7", Whitelist7_);
  settings_->setValue ("Whitelist8", Whitelist8_);
  settings_->setValue ("Whitelist9", Whitelist9_);
  settings_->setValue ("Whitelist10", Whitelist10_);
  settings_->setValue ("Whitelist11", Whitelist11_);
  settings_->setValue ("Whitelist12", Whitelist12_);
  settings_->setValue ("Pass1", Pass1_);
  settings_->setValue ("Pass2", Pass2_);
  settings_->setValue ("Pass3", Pass3_);
  settings_->setValue ("Pass4", Pass4_);
  settings_->setValue ("Pass5", Pass5_);
  settings_->setValue ("Pass6", Pass6_);
  settings_->setValue ("Pass7", Pass7_);
  settings_->setValue ("Pass8", Pass8_);
  settings_->setValue ("Pass9", Pass9_);
  settings_->setValue ("Pass10", Pass10_);
  settings_->setValue ("Pass11", Pass11_);
  settings_->setValue ("Pass12", Pass12_);
  settings_->setValue ("Territory1", Territory1_);
  settings_->setValue ("Territory2", Territory2_);
  settings_->setValue ("Territory3", Territory3_);
  settings_->setValue ("Territory4", Territory4_);
  settings_->setValue ("HighlightOrangeCallsigns", highlight_orange_callsigns_);
  settings_->setValue ("HighlightBlueCallsigns", highlight_blue_callsigns_);
  settings_->setValue ("PWRandSWR", PWR_and_SWR_);
  settings_->setValue ("CheckSWR", check_SWR_);

  settings_->setValue ("Font", font_.toString ());
  settings_->setValue ("DecodedTextFont", decoded_text_font_.toString ());
  settings_->setValue ("IDint", id_interval_);
  settings_->setValue ("AlignSteps", align_steps_);
  settings_->setValue ("AlignSteps2", align_steps2_);
  settings_->setValue ("nTrials", ntrials_);
  settings_->setValue ("volume", volume_);
  settings_->setValue ("TxDelay", txDelay_);
  settings_->setValue ("Aggressive", aggressive_);
  settings_->setValue ("RxBandwidth", RxBandwidth_);
  settings_->setValue ("TCIAudio", tci_audio_);
  settings_->setValue ("CATTCIPort", rig_params_.tci_port);
  settings_->setValue ("PTTMethod", QVariant::fromValue (rig_params_.ptt_type));
  settings_->setValue ("PTTport", rig_params_.ptt_port);
  settings_->setValue ("SaveDir", save_directory_.absolutePath ());
  settings_->setValue ("AzElDir", azel_directory_.absolutePath ());
  if (!audio_input_device_.isNull ()) {
      settings_->setValue ("SoundInName", audio_input_device_.deviceName ());
      settings_->setValue ("AudioInputChannel", AudioDevice::toString (audio_input_channel_));
  } else if (is_tci_ && tci_audio_) {
    settings_->setValue ("SoundInName", "TCI audio");
    settings_->setValue ("AudioInputChannel", "TCI audio");
  }
  if (!audio_output_device_.isNull ()) {
    settings_->setValue ("SoundOutName", audio_output_device_.deviceName ());
    settings_->setValue ("AudioOutputChannel", AudioDevice::toString (audio_output_channel_));
  } else if (is_tci_ && tci_audio_) {
    settings_->setValue ("SoundOutName", "TCI audio");
    settings_->setValue ("AudioOutputChannel", "TCI audio");
  }
  settings_->setValue ("Type2MsgGen", QVariant::fromValue (type_2_msg_gen_));
  settings_->setValue ("MonitorOFF", monitor_off_at_startup_);
  settings_->setValue ("MonitorLastUsed", monitor_last_used_);
  settings_->setValue ("PSKReporter", spot_to_psk_reporter_);
  settings_->setValue ("PSKReporterTCPIP", psk_reporter_tcpip_);
  settings_->setValue ("EQSLSend", send_to_eqsl_);
  settings_->setValue ("EQSLUser", eqsl_username_);
  settings_->setValue ("EQSLPasswd", eqsl_passwd_);
  settings_->setValue ("EQSLNick", eqsl_nickname_);
  settings_->setValue ("After73", id_after_73_);
  settings_->setValue ("TxQSYAllowed", tx_frequency_corrections_allowed_);
  settings_->setValue ("ProgressBarRed", progressBar_red_);
  settings_->setValue ("Macros", macros_.stringList ());
  settings_->setValue ("stations", QVariant::fromValue (stations_.station_list ()));
  settings_->setValue ("FrequenciesForRegionModes_v2", QVariant::fromValue (frequencies_.frequency_list ()));
  settings_->setValue ("DecodeHighlighting", QVariant::fromValue (decode_highlighing_model_.items ()));
  settings_->setValue ("HighlightByMode", highlight_by_mode_);
  settings_->setValue ("OnlyFieldsSought", highlight_only_fields_);
  settings_->setValue ("IncludeWAEEntities", include_WAE_entities_);
  settings_->setValue ("Highlight73", highlight_73_);
  settings_->setValue ("HighlightOrange", highlight_orange_);
  settings_->setValue ("HighlightBlue", highlight_blue_);
  settings_->setValue ("AlternateEraseButtonBehavior", alternate_erase_button_);
  settings_->setValue ("AlwaysShowCountryNames", show_country_names_);
  settings_->setValue ("LotWDaysSinceLastUpload", LotW_days_since_upload_);
  settings_->setValue ("toRTTY", log_as_RTTY_);
  settings_->setValue ("dBtoComments", report_in_comments_);
  settings_->setValue ("specOptoComments", specOp_in_comments_);
  settings_->setValue ("Rig", rig_params_.rig_name);
  settings_->setValue ("CATNetworkPort", rig_params_.network_port);
  settings_->setValue ("CATUSBPort", rig_params_.usb_port);
  settings_->setValue ("CATSerialPort", rig_params_.serial_port);
  settings_->setValue ("CATSerialRate", rig_params_.baud);
  settings_->setValue ("CATDataBits", QVariant::fromValue (rig_params_.data_bits));
  settings_->setValue ("CATStopBits", QVariant::fromValue (rig_params_.stop_bits));
  settings_->setValue ("CATHandshake", QVariant::fromValue (rig_params_.handshake));
  settings_->setValue ("DataMode", QVariant::fromValue (data_mode_));
  settings_->setValue ("LowSidelobes",bLowSidelobes_);
  settings_->setValue ("PromptToLog", prompt_to_log_);
  settings_->setValue ("AutoLog", autoLog_);
  settings_->setValue ("ContestingOnly", contestingOnly_);
  settings_->setValue ("ZZ00", ZZ00_);
  settings_->setValue ("Log4digitGrids", log4digitGrids_);
  settings_->setValue ("DecodesFromTop", decodes_from_top_);
  settings_->setValue ("InsertBlank", insert_blank_);
  settings_->setValue ("DetailedBlank", detailed_blank_);
  settings_->setValue ("DXCCEntity", DXCC_);
  settings_->setValue ("MapGridEntity", gridMap_);
  settings_->setValue ("MapGridAllEntity", gridMapAll_);
  settings_->setValue ("PrincipalPrefix", ppfx_);
  settings_->setValue ("Miles", miles_);
  settings_->setValue ("QuickCall", quick_call_);
  settings_->setValue ("73TxDisable", disable_TX_on_73_);
  settings_->setValue ("ForceCallFirst", force_call_1st_);
  settings_->setValue ("AlternateBindings", alternate_bindings_);
  settings_->setValue ("TxWatchdog", watchdog_);
  settings_->setValue ("TuneWatchdog", tune_watchdog_);
  settings_->setValue ("TuneWatchdogTime", tune_watchdog_time_);
  settings_->setValue ("Tx2QSO", TX_messages_);
  settings_->setValue ("CATForceDTR", rig_params_.force_dtr);
  settings_->setValue ("DTR", rig_params_.dtr_high);
  settings_->setValue ("CATForceRTS", rig_params_.force_rts);
  settings_->setValue ("RTS", rig_params_.rts_high);
  settings_->setValue ("TXAudioSource", QVariant::fromValue (rig_params_.audio_source));
  settings_->setValue ("Polling", rig_params_.poll_interval);
  settings_->setValue ("SplitMode", QVariant::fromValue (rig_params_.split_mode));
  settings_->setValue ("VHFUHF", enable_VHF_features_);
  settings_->setValue ("Decode52", decode_at_52s_);
  settings_->setValue ("kHzWithoutK", kHz_without_k_);
  settings_->setValue ("TxWarningDisabled", button_coloring_disabled_);
  settings_->setValue ("WaitFeaturesEnabled", Wait_features_enabled_);
  settings_->setValue ("showDistance", showDistance_);
  settings_->setValue ("showAzimuth", showAzimuth_);
  settings_->setValue ("AlignDistanceAzimuth", align_);
  settings_->setValue ("RepeatTx", repeat_Tx_);
  settings_->setValue ("AutoAstroWindow", auto_astro_);
  settings_->setValue ("SingleDecode", single_decode_);
  settings_->setValue ("TwoPass", twoPass_);
  settings_->setValue ("SuperFox", bSuperFox_);
  settings_->setValue ("Individual_Contest_Name", Individual_Contest_Name_);
  settings_->setValue ("NCCC_Sprint", NCCC_Sprint_);
  settings_->setValue ("Blacklisted", Blacklisted_);
  settings_->setValue ("Whitelisted", Whitelisted_);
  settings_->setValue ("AlwaysPass", AlwaysPass_);
  settings_->setValue ("FiltersForWaitAndPounceOnly", filters_for_Wait_and_Pounce_only_);
  settings_->setValue ("FiltersForWord2", filters_for_word2_);
  settings_->setValue ("TwoDays", twoDays_);
  settings_->setValue ("SelectedActivity", SelectedActivity_);
  settings_->setValue ("SpecialOpActivity", bSpecialOp_);
  settings_->setValue ("CloudLog", bCloudLog_);
  settings_->setValue ("CloudLogApiUrl", cloudLogApiUrl_);
  settings_->setValue ("CloudLogApiKey", cloudLogApiKey_);
  settings_->setValue ("CloudLogStationID", cloudLogStationID_);
  settings_->setValue ("x2ToneSpacing", x2ToneSpacing_);
  settings_->setValue ("x4ToneSpacing", x4ToneSpacing_);
  settings_->setValue ("OpCall", opCall_);
  settings_->setValue ("UDPServer", udp_server_name_);
  settings_->setValue ("UDPServerPort", udp_server_port_);
  settings_->setValue ("UDPInterface", QVariant::fromValue (udp_interface_names_));
  settings_->setValue ("UDPTTL", udp_TTL_);
  settings_->setValue ("N1MMServer", n1mm_server_name_);
  settings_->setValue ("N1MMServerPort", n1mm_server_port_);
  settings_->setValue ("BroadcastToN1MM", broadcast_to_n1mm_);
  settings_->setValue ("AcceptUDPRequests", accept_udp_requests_);
  settings_->setValue ("udpWindowToFront", udpWindowToFront_);
  settings_->setValue ("udpWindowRestore", udpWindowRestore_);
  settings_->setValue ("CalibrationIntercept", calibration_.intercept);
  settings_->setValue ("CalibrationSlopePPM", calibration_.slope_ppm);
  settings_->setValue ("SortAlphabetically", sortAlphabetically_);
  settings_->setValue ("HideCARD", hideCARD_);
  settings_->setValue ("AzElExtraLines", AzElExtraLines_);
  settings_->setValue ("pwrBandTxMemory", pwrBandTxMemory_);
  settings_->setValue ("pwrBandTuneMemory", pwrBandTuneMemory_);
  settings_->setValue ("Region", QVariant::fromValue (region_));
  settings_->setValue ("AutoGrid", use_dynamic_grid_);
  settings_->setValue ("highlight_DXcall", highlight_DXcall_);
  settings_->setValue ("clear_DXcall", clear_DXcall_);
  settings_->setValue ("highlight_DXgrid", highlight_DXgrid_);
  settings_->setValue ("OTPinterval", OTPinterval_);
  settings_->setValue ("OTPUrl", OTPUrl_);
  settings_->setValue ("OTPSeed", OTPSeed_);
  settings_->setValue ("OTPEnabled", OTPEnabled_);
  settings_->setValue ("ShowOTP", ShowOTP_);
  settings_->setValue ("clear_DXgrid", clear_DXgrid_);
  settings_->setValue ("erase_BandActivity", erase_BandActivity_);
  settings_->setValue ("set_RXtoTX", set_RXtoTX_);
  settings_->setValue ("alert_CQ", alert_CQ_);
  settings_->setValue ("alert_MyCall", alert_MyCall_);
  settings_->setValue ("alert_DXCC", alert_DXCC_);
  settings_->setValue ("alert_DXCCOB", alert_DXCCOB_);
  settings_->setValue ("alert_Grid", alert_Grid_);
  settings_->setValue ("alert_GridOB", alert_GridOB_);
  settings_->setValue ("alert_Continent", alert_Continent_);
  settings_->setValue ("alert_ContinentOB", alert_ContinentOB_);
  settings_->setValue ("alert_CQZ", alert_CQZ_);
  settings_->setValue ("alert_CQZOB", alert_CQZOB_);
  settings_->setValue ("alert_ITUZ", alert_ITUZ_);
  settings_->setValue ("alert_ITUZOB", alert_ITUZOB_);
  settings_->setValue ("alert_DXcall", alert_DXcall_);
  settings_->setValue ("alert_Wanted", alert_Wanted_);
  settings_->setValue ("alert_QSYmessage", alert_QSYmessage_);
  settings_->setValue ("alert_Enabled", alert_Enabled_);
  settings_->setValue ("Voice", voice_);
  settings_->sync ();
}

void Configuration::impl::normalize_rig_selections (bool restore)
{
  QSignalBlocker cat_signals {ui_->CAT_port_combo_box};
  QSignalBlocker ptt_signals {ui_->PTT_port_combo_box};
  auto const rig = ui_->rig_combo_box->currentText ();
  auto const port_type = transceiver_factory_.CAT_port_type (rig);
  if (TransceiverFactory::basic_transceiver_name_ != rig
      && (restore || port_type != last_port_type_))
    {
      last_port_type_ = port_type;
      switch (port_type)
        {
        case TransceiverFactory::Capabilities::serial:
          fill_port_combo_box (ui_->CAT_port_combo_box);
          ui_->CAT_port_combo_box->addItem ("USB");
          ui_->CAT_port_combo_box->setItemData (ui_->CAT_port_combo_box->count () - 1, "Custom USB device", Qt::ToolTipRole);
          ui_->CAT_port_combo_box->setCurrentText (rig_params_.serial_port);
          if (ui_->CAT_port_combo_box->currentText ().isEmpty () && ui_->CAT_port_combo_box->count ())
            {
              ui_->CAT_port_combo_box->setCurrentText (ui_->CAT_port_combo_box->itemText (0));
            }
          ui_->CAT_port_label->setText (tr ("Serial Port:"));
          ui_->CAT_port_combo_box->setToolTip (tr ("Serial port used for CAT control"));
          ui_->CAT_port_combo_box->setEnabled (true);
          break;

        case TransceiverFactory::Capabilities::tci:
          ui_->CAT_port_combo_box->clear ();
          ui_->CAT_port_combo_box->setCurrentText (rig_params_.tci_port);
          ui_->CAT_port_label->setText (tr ("TCI Server:"));
          ui_->CAT_port_combo_box->setToolTip (tr ("Optional hostname and port of TCI service.\n"
                                                 "Leave blank for a sensible default on this machine.\n"
                                                 "Formats:\n"
                                                 "\thostname:port\n"
                                                 "\tIPv4-address:port\n"
                                                 "\t[IPv6-address]:port"));
          ui_->CAT_port_combo_box->setEnabled (true);
          break;

        case TransceiverFactory::Capabilities::network:
          ui_->CAT_port_combo_box->clear ();
          ui_->CAT_port_combo_box->setCurrentText (rig_params_.network_port);
          ui_->CAT_port_label->setText (tr ("Network Server:"));
          ui_->CAT_port_combo_box->setToolTip (tr ("Optional hostname and port of network service.\n"
                                                   "Leave blank for a sensible default on this machine.\n"
                                                   "Formats:\n"
                                                   "\thostname:port\n"
                                                   "\tIPv4-address:port\n"
                                                   "\t[IPv6-address]:port"));
          ui_->CAT_port_combo_box->setEnabled (true);
          break;

        case TransceiverFactory::Capabilities::usb:
          ui_->CAT_port_combo_box->clear ();
          ui_->CAT_port_combo_box->setCurrentText (rig_params_.usb_port);
          ui_->CAT_port_label->setText (tr ("USB Device:"));
          ui_->CAT_port_combo_box->setToolTip (tr ("Optional device identification.\n"
                                                   "Leave blank for a sensible default for the rig.\n"
                                                   "Format:\n"
                                                   "\t[VID[:PID[:VENDOR[:PRODUCT]]]]"));
          ui_->CAT_port_combo_box->setEnabled (true);
          break;

        default:
          ui_->CAT_port_combo_box->clear ();
          ui_->CAT_port_combo_box->setEnabled (false);
          break;
        }
    }
  auto const indirect_ptt = transceiver_factory_.has_CAT_indirect_serial_PTT (rig);
  ui_->PTT_port_combo_box->setItemData (ui_->PTT_port_combo_box->findText ("CAT")
                                     , indirect_ptt ? combo_box_item_enabled : combo_box_item_disabled
                                     , Qt::UserRole - 1);
  auto const ptt_port = ui_->PTT_port_combo_box->currentText ();
  if (("CAT" == ptt_port && !indirect_ptt) || "USB" == ptt_port)
    {
      ui_->PTT_port_combo_box->setCurrentIndex (-1);
      ui_->PTT_port_combo_box->clearEditText ();
    }
}

void Configuration::impl::set_rig_invariants ()
{
  if (initializing_models_) return;

  normalize_rig_selections ();
  auto const& rig = ui_->rig_combo_box->currentText ();
  auto const& ptt_port = ui_->PTT_port_combo_box->currentText ();
  auto ptt_method = static_cast<TransceiverFactory::PTTMethod> (ui_->PTT_method_button_group->checkedId ());

  auto CAT_PTT_enabled = transceiver_factory_.has_CAT_PTT (rig);
  auto asynchronous_CAT = transceiver_factory_.has_asynchronous_CAT (rig);
  is_tci_ = ui_->rig_combo_box->currentText().startsWith("TCI Cli");
  ui_->tci_audio_check_box->setVisible(is_tci_);
  ui_->TCI_spin_box->setVisible(is_tci_);
//  ui_->refresh_push_button->setVisible(is_tci_);
  if (is_tci_ && tci_audio_) {
    find_audio_devices ();
    ui_->sound_input_channel_combo_box->setCurrentIndex (0);
    ui_->sound_output_channel_combo_box->setCurrentIndex (0);
  }
  ui_->test_CAT_push_button->setStyleSheet ({});
  ui_->CAT_poll_interval_label->setEnabled (!asynchronous_CAT);
  ui_->CAT_poll_interval_spin_box->setEnabled (!asynchronous_CAT);

  auto port_type = transceiver_factory_.CAT_port_type (rig);

  bool is_serial_CAT (TransceiverFactory::Capabilities::serial == port_type);
  auto const is_hw_handshake = is_serial_CAT
    && TransceiverFactory::handshake_hardware == static_cast<TransceiverFactory::Handshake> (ui_->CAT_handshake_button_group->checkedId ());
  auto const& cat_port = ui_->CAT_port_combo_box->currentText ();

  // only enable CAT option if transceiver has CAT PTT
  ui_->PTT_CAT_radio_button->setEnabled (CAT_PTT_enabled);
  ui_->PTT_VOX_radio_button->setEnabled (!is_tci_);
  ui_->PTT_DTR_radio_button->setEnabled (!is_tci_);

  auto enable_ptt_port = TransceiverFactory::PTT_method_CAT != ptt_method && TransceiverFactory::PTT_method_VOX != ptt_method;
  ui_->PTT_port_combo_box->setEnabled (enable_ptt_port);
  ui_->PTT_port_label->setEnabled (enable_ptt_port);

  ui_->PTT_RTS_radio_button->setEnabled (!((is_serial_CAT && ptt_port == cat_port && is_hw_handshake) || is_tci_));

  if (TransceiverFactory::basic_transceiver_name_ == rig)
    {
      // makes no sense with rig as "None"
      ui_->monitor_last_used_check_box->setEnabled (false);

      ui_->CAT_control_group_box->setEnabled (false);
      ui_->test_CAT_push_button->setEnabled (false);
      ui_->test_PTT_push_button->setEnabled (TransceiverFactory::PTT_method_DTR == ptt_method
                                             || TransceiverFactory::PTT_method_RTS == ptt_method);
      ui_->TX_audio_source_group_box->setEnabled (false);
      ui_->PWR_and_SWR_check_box->setChecked (false);
      ui_->PWR_and_SWR_check_box->setEnabled (false);
      ui_->check_SWR_check_box->setChecked (false);
      ui_->check_SWR_check_box->setEnabled (false);
    }
  else
    {
      ui_->monitor_last_used_check_box->setEnabled (true);
      ui_->CAT_control_group_box->setEnabled (true);
      if(!ui_->rig_combo_box->currentText().startsWith("OmniRig") && !ui_->rig_combo_box->currentText().startsWith("DX Lab") &&
         !ui_->rig_combo_box->currentText().startsWith("Ham Radio") && !ui_->rig_combo_box->currentText().startsWith("Kenwood TS-480") &&
         !ui_->rig_combo_box->currentText().startsWith("Kenwood TS-850") &&
         !ui_->rig_combo_box->currentText().startsWith("Kenwood TS-870")) {
         ui_->PWR_and_SWR_check_box->setEnabled (true);
      }
      ui_->test_CAT_push_button->setEnabled (true);
      ui_->test_PTT_push_button->setEnabled (false);
      ui_->TX_audio_source_group_box->setEnabled (transceiver_factory_.has_CAT_PTT_mic_data (rig) && TransceiverFactory::PTT_method_CAT == ptt_method);
      ui_->CAT_serial_port_parameters_group_box->setEnabled (is_serial_CAT);
      ui_->force_DTR_combo_box->setEnabled (is_serial_CAT
                                            && (cat_port != ptt_port
                                                || !ui_->PTT_DTR_radio_button->isEnabled ()
                                                || !ui_->PTT_DTR_radio_button->isChecked ()));
      ui_->force_RTS_combo_box->setEnabled (is_serial_CAT
                                            && !is_hw_handshake
                                            && (cat_port != ptt_port
                                                || !ui_->PTT_RTS_radio_button->isEnabled ()
                                                || !ui_->PTT_RTS_radio_button->isChecked ()));
    }
  ui_->mode_group_box->setEnabled (WSJT_RIG_NONE_CAN_SPLIT
                                   || TransceiverFactory::basic_transceiver_name_ != rig);
  ui_->split_operation_group_box->setEnabled (WSJT_RIG_NONE_CAN_SPLIT
                                              || TransceiverFactory::basic_transceiver_name_ != rig);
}

auto Configuration::impl::validate_radio_settings () -> RadioValidationError
{
  set_rig_invariants ();

  if (!ui_->PTT_method_button_group->checkedButton ()->isEnabled ())
    {
      return RadioValidationError::invalid_ptt_method;
    }

  auto ptt_method = static_cast<TransceiverFactory::PTTMethod> (ui_->PTT_method_button_group->checkedId ());
  auto ptt_port = ui_->PTT_port_combo_box->currentText ();
  auto const ptt_port_index = ui_->PTT_port_combo_box->findText (ptt_port);
  if ((TransceiverFactory::PTT_method_DTR == ptt_method || TransceiverFactory::PTT_method_RTS == ptt_method)
      && (ptt_port.trimmed ().isEmpty ()
          || (ptt_port_index >= 0
              && combo_box_item_disabled == ui_->PTT_port_combo_box->itemData (ptt_port_index, Qt::UserRole - 1))))
    {
      return RadioValidationError::invalid_ptt_port;
    }

  return RadioValidationError::none;
}

bool Configuration::impl::validate ()
{
  auto const radio_error = validate_radio_settings ();

  // Latitude/longitude are conventional signed decimal degrees.  Allow both
  // fields to be empty (legacy/grid-only configuration), but if either is
  // supplied require a complete, in-range pair before accepting Settings.
  auto const latitude_text = ui_->latitude_line_edit->text ().trimmed ();
  auto const longitude_text = ui_->longitude_line_edit->text ().trimmed ();
  if (!latitude_text.isEmpty () || !longitude_text.isEmpty ())
    {
      if (!ui_->latitude_line_edit->hasAcceptableInput ()
          || !ui_->longitude_line_edit->hasAcceptableInput ())
        {
          find_tab (ui_->latitude_line_edit);
          MessageBox::critical_message (this, tr ("Invalid station coordinates"),
                                        tr ("Latitude must be between -90 and +90 degrees, "
                                            "and longitude between -180 and +180 degrees."));
          return false;
        }
    }

  // Do not rely on editingFinished having synchronized My Grid with the
  // coordinate fields before OK is clicked.  A valid coordinate pair must
  // lie inside the displayed six-character locator.
  if (!latitude_text.isEmpty () && !longitude_text.isEmpty ())
    {
      bool lat_ok {false};
      bool lon_ok {false};
      auto lat = latitude_text.toDouble (&lat_ok);
      auto lon = longitude_text.toDouble (&lon_ok);
      QString coordinate_grid;
      auto grid = ui_->grid_line_edit->text ().trimmed ().left (6);
      if (grid.size () < 6) grid += "mm";
      if (lat_ok && lon_ok && coordinates_to_grid (lat, lon, coordinate_grid)
          && coordinate_grid.compare (grid, Qt::CaseInsensitive) != 0)
        {
          find_tab (ui_->grid_line_edit);
          MessageBox::critical_message (this, tr ("Inconsistent station location"),
                                        tr ("Latitude and longitude must lie within the My Grid locator."));
          return false;
        }
    }

  if (ui_->sound_input_combo_box->currentIndex () < 0
      && next_audio_input_device_.isNull ())
    {
      find_tab (ui_->sound_input_combo_box);
      MessageBox::critical_message (this, tr ("Invalid audio input device"));
      return false;
    }

  if (ui_->sound_input_channel_combo_box->currentIndex () < 0
      && next_audio_input_device_.isNull ())
    {
      find_tab (ui_->sound_input_combo_box);
      MessageBox::critical_message (this, tr ("Invalid audio input device"));
      return false;
    }

  if (ui_->sound_output_combo_box->currentIndex () < 0
      && next_audio_output_device_.isNull ())
    {
      find_tab (ui_->sound_output_combo_box);
      MessageBox::information_message (this, tr ("Invalid audio output device"));
      // don't reject as we can work without an audio output
    }

  if (RadioValidationError::invalid_ptt_method == radio_error)
    {
      find_tab (ui_->PTT_method_button_group->checkedButton ());
      MessageBox::critical_message (this, tr ("Invalid PTT method"));
      return false;
    }

  if (RadioValidationError::invalid_ptt_port == radio_error)
    {
      find_tab (ui_->PTT_port_combo_box);
      MessageBox::critical_message (this, tr ("Invalid PTT port"));
      return false;
    }

  if (ui_->rbField_Day->isEnabled () && ui_->rbField_Day->isChecked () &&
      !ui_->Field_Day_Exchange->hasAcceptableInput ())
    {
      find_tab (ui_->Field_Day_Exchange);
      MessageBox::critical_message (this, tr ("Invalid Contest Exchange")
                                    , tr ("You must input a valid ARRL Field Day exchange"));
      return false;
    }

  if (ui_->rbRTTY_Roundup->isEnabled () && ui_->rbRTTY_Roundup->isChecked () &&
      !ui_->RTTY_Exchange->hasAcceptableInput ())
    {
      find_tab (ui_->RTTY_Exchange);
      MessageBox::critical_message (this, tr ("Invalid Contest Exchange")
                                    , tr ("You must input a valid ARRL RTTY Roundup exchange"));
      return false;
    }

  if (dns_lookup_id_ > -1)
    {
      find_tab (ui_->udp_server_line_edit);
      MessageBox::information_message (this, tr ("Pending DNS lookup, please try again later"));
      return false;
    }

  return true;
}

int Configuration::impl::exec ()
{
  // macros can be modified in the main window
  next_macros_.setStringList (macros_.stringList ());

  have_rig_ = rig_active_;	// record that we started with a rig open
  saved_rig_params_ = rig_params_; // used to detect changes that
                                   // require the Transceiver to be
                                   // re-opened
  rig_changed_ = false;

  initialize_models ();

  return QDialog::exec();
}

TransceiverFactory::ParameterPack Configuration::impl::gather_rig_data ()
{
  TransceiverFactory::ParameterPack result;
  result.rig_name = ui_->rig_combo_box->currentText ();

  switch (transceiver_factory_.CAT_port_type (result.rig_name))
    {
    case TransceiverFactory::Capabilities::tci:
      result.tci_port = ui_->CAT_port_combo_box->currentText ();
      result.network_port = rig_params_.network_port;
      result.usb_port = rig_params_.usb_port;
      result.serial_port = rig_params_.serial_port;
      break;

    case TransceiverFactory::Capabilities::network:
      result.network_port = ui_->CAT_port_combo_box->currentText ();
      result.tci_port = rig_params_.tci_port;
      result.usb_port = rig_params_.usb_port;
      result.serial_port = rig_params_.serial_port;
      break;

    case TransceiverFactory::Capabilities::usb:
      result.usb_port = ui_->CAT_port_combo_box->currentText ();
      result.tci_port = rig_params_.tci_port;
      result.network_port = rig_params_.network_port;
      result.serial_port = rig_params_.serial_port;
      break;

    default:
      result.serial_port = ui_->CAT_port_combo_box->currentText ();
      result.tci_port = rig_params_.tci_port;
      result.network_port = rig_params_.network_port;
      result.usb_port = rig_params_.usb_port;
      break;
    }

  result.baud = ui_->CAT_serial_baud_combo_box->currentText ().toInt ();
  result.data_bits = static_cast<TransceiverFactory::DataBits> (ui_->CAT_data_bits_button_group->checkedId ());
  result.stop_bits = static_cast<TransceiverFactory::StopBits> (ui_->CAT_stop_bits_button_group->checkedId ());
  result.handshake = static_cast<TransceiverFactory::Handshake> (ui_->CAT_handshake_button_group->checkedId ());
  result.force_dtr = ui_->force_DTR_combo_box->isEnabled () && ui_->force_DTR_combo_box->currentIndex () > 0;
  result.dtr_high = ui_->force_DTR_combo_box->isEnabled () && 1 == ui_->force_DTR_combo_box->currentIndex ();
  result.force_rts = ui_->force_RTS_combo_box->isEnabled () && ui_->force_RTS_combo_box->currentIndex () > 0;
  result.rts_high = ui_->force_RTS_combo_box->isEnabled () && 1 == ui_->force_RTS_combo_box->currentIndex ();
  result.poll_interval = ui_->CAT_poll_interval_spin_box->value ();
  if (ui_->PWR_and_SWR_check_box->isChecked ()) result.poll_interval |= do__pwr;
  if (is_tci_ && ui_->tci_audio_check_box->isChecked ()) result.poll_interval |= tci__audio;
  result.ptt_type = static_cast<TransceiverFactory::PTTMethod> (ui_->PTT_method_button_group->checkedId ());
  result.ptt_port = ui_->PTT_port_combo_box->currentText ();
  result.audio_source = static_cast<TransceiverFactory::TXAudioSource> (ui_->TX_audio_source_button_group->checkedId ());
  result.split_mode = static_cast<TransceiverFactory::SplitMode> (ui_->split_mode_button_group->checkedId ());
  return result;
}

void Configuration::impl::accept ()
{
  // Called when OK button is clicked.
  if (!validate ())
    {
      return;			// not accepting
    }

  // extract all rig related configuration parameters into temporary
  // structure for checking if the rig needs re-opening without
  // actually updating our live state
  auto temp_rig_params = gather_rig_data ();

  // open_rig() uses values from models so we use it to validate the
  // Transceiver settings before agreeing to accept the configuration
  if (temp_rig_params != rig_params_
      && tx_inhibit_blocks_rig_restart (temp_rig_params, false))
    {
      warn_tx_inhibit_restart_blocked ();
      return;
    }
  if (temp_rig_params != rig_params_ && !open_rig ())
    {
      return;			// not accepting
    }

  QDialog::accept();            // do this before accessing custom
                                // models so that any changes in
                                // delegates in views get flushed to
                                // the underlying models before we
                                // access them

  sync_transceiver (true);	// force an update

  //
  // from here on we are bound to accept the new configuration
  // parameters so extract values from models and make them live
  //

  if (next_font_ != font_)
    {
      font_ = next_font_;
      Q_EMIT self_->text_font_changed (font_);
    }

  if (next_decoded_text_font_ != decoded_text_font_)
    {
      decoded_text_font_ = next_decoded_text_font_;
      next_decode_highlighing_model_.set_font (decoded_text_font_);
      ui_->highlighting_list_view->reset ();
      Q_EMIT self_->decoded_text_font_changed (decoded_text_font_);
    }

  rig_params_ = temp_rig_params; // now we can go live with the rig
                                 // related configuration parameters
  rig_is_dummy_ = TransceiverFactory::basic_transceiver_name_ == rig_params_.rig_name;
  is_tci_ = rig_params_.rig_name.startsWith("TCI Cli");
  // Check to see whether SoundInThread must be restarted,
  // and save user parameters.
  {
    auto const& selected_device = ui_->sound_input_combo_box->currentData ().value<audio_info_type> ().first;
    if (selected_device != next_audio_input_device_)
      {
        next_audio_input_device_ = selected_device;
      }
  }

  {
    auto const& selected_device = ui_->sound_output_combo_box->currentData ().value<audio_info_type> ().first;
    if (selected_device != next_audio_output_device_)
      {
        next_audio_output_device_ = selected_device;
      }
  }

  if (next_audio_input_channel_ != static_cast<AudioDevice::Channel> (ui_->sound_input_channel_combo_box->currentIndex ()))
    {
      next_audio_input_channel_ = static_cast<AudioDevice::Channel> (ui_->sound_input_channel_combo_box->currentIndex ());
    }
  Q_ASSERT (next_audio_input_channel_ <= AudioDevice::Right);

  if (next_audio_output_channel_ != static_cast<AudioDevice::Channel> (ui_->sound_output_channel_combo_box->currentIndex ()))
    {
      next_audio_output_channel_ = static_cast<AudioDevice::Channel> (ui_->sound_output_channel_combo_box->currentIndex ());
    }
  Q_ASSERT (next_audio_output_channel_ <= AudioDevice::Both);

  if (audio_input_device_ != next_audio_input_device_ || next_audio_input_device_.isNull ())
    {
      audio_input_device_ = next_audio_input_device_;
      restart_sound_input_device_ = true;
    }
  if (audio_input_channel_ != next_audio_input_channel_)
    {
      audio_input_channel_ = next_audio_input_channel_;
      restart_sound_input_device_ = true;
    }
  if (audio_output_device_ != next_audio_output_device_ || next_audio_output_device_.isNull ())
    {
      audio_output_device_ = next_audio_output_device_;
      restart_sound_output_device_ = true;
    }
  if (audio_output_channel_ != next_audio_output_channel_)
    {
      audio_output_channel_ = next_audio_output_channel_;
      restart_sound_output_device_ = true;
    }
  // qDebug () << "Configure::accept: audio i/p:" << audio_input_device_.deviceName ()
  //           << "chan:" << audio_input_channel_
  //           << "o/p:" << audio_output_device_.deviceName ()
  //           << "chan:" << audio_output_channel_
  //           << "reset i/p:" << restart_sound_input_device_
  //           << "reset o/p:" << restart_sound_output_device_;

  my_callsign_ = ui_->callsign_line_edit->text ();
  my_grid_ = ui_->grid_line_edit->text ();
  bool lat_ok {false};
  bool lon_ok {false};
  auto lat = ui_->latitude_line_edit->text ().toDouble (&lat_ok);
  auto lon = ui_->longitude_line_edit->text ().toDouble (&lon_ok);
  have_home_coordinates_ = lat_ok && lon_ok && lat >= -90. && lat <= 90. && lon >= -180. && lon <= 180.;
  if (have_home_coordinates_)
    {
      home_latitude_ = lat;
      home_longitude_ = lon;
    }
  FD_exchange_= ui_->Field_Day_Exchange->text ().toUpper ();
  RTTY_exchange_= ui_->RTTY_Exchange->text ().toUpper ();
  Contest_Name_= ui_->Contest_Name->text ().toUpper ();
  Blacklist1_= ui_->Blacklist1->text ().toUpper ();
  Blacklist2_= ui_->Blacklist2->text ().toUpper ();
  Blacklist3_= ui_->Blacklist3->text ().toUpper ();
  Blacklist4_= ui_->Blacklist4->text ().toUpper ();
  Blacklist5_= ui_->Blacklist5->text ().toUpper ();
  Blacklist6_= ui_->Blacklist6->text ().toUpper ();
  Blacklist7_= ui_->Blacklist7->text ().toUpper ();
  Blacklist8_= ui_->Blacklist8->text ().toUpper ();
  Blacklist9_= ui_->Blacklist9->text ().toUpper ();
  Blacklist10_= ui_->Blacklist10->text ().toUpper ();
  Blacklist11_= ui_->Blacklist11->text ().toUpper ();
  Blacklist12_= ui_->Blacklist12->text ().toUpper ();
  Whitelist1_= ui_->Whitelist1->text ().toUpper ();
  Whitelist2_= ui_->Whitelist2->text ().toUpper ();
  Whitelist3_= ui_->Whitelist3->text ().toUpper ();
  Whitelist4_= ui_->Whitelist4->text ().toUpper ();
  Whitelist5_= ui_->Whitelist5->text ().toUpper ();
  Whitelist6_= ui_->Whitelist6->text ().toUpper ();
  Whitelist7_= ui_->Whitelist7->text ().toUpper ();
  Whitelist8_= ui_->Whitelist8->text ().toUpper ();
  Whitelist9_= ui_->Whitelist9->text ().toUpper ();
  Whitelist10_= ui_->Whitelist10->text ().toUpper ();
  Whitelist11_= ui_->Whitelist11->text ().toUpper ();
  Whitelist12_= ui_->Whitelist12->text ().toUpper ();
  Pass1_= ui_->Pass1->text ().toUpper ();
  Pass2_= ui_->Pass2->text ().toUpper ();
  Pass3_= ui_->Pass3->text ().toUpper ();
  Pass4_= ui_->Pass4->text ().toUpper ();
  Pass5_= ui_->Pass5->text ().toUpper ();
  Pass6_= ui_->Pass6->text ().toUpper ();
  Pass7_= ui_->Pass7->text ().toUpper ();
  Pass8_= ui_->Pass8->text ().toUpper ();
  Pass9_= ui_->Pass9->text ().toUpper ();
  Pass10_= ui_->Pass10->text ().toUpper ();
  Pass11_= ui_->Pass11->text ().toUpper ();
  Pass12_= ui_->Pass12->text ().toUpper ();
  Territory1_= ui_->Territory1->text ();
  Territory2_= ui_->Territory2->text ();
  Territory3_= ui_->Territory3->text ();
  Territory4_= ui_->Territory4->text ();
  highlight_orange_callsigns_= ui_-> highlight_orange_callsigns->text ().toUpper ();
  highlight_blue_callsigns_= ui_-> highlight_blue_callsigns->text ().toUpper ();
  PWR_and_SWR_ = ui_->PWR_and_SWR_check_box->isChecked ();
  check_SWR_ = ui_->check_SWR_check_box->isChecked ();

  read_voice_directory ();

  spot_to_psk_reporter_ = ui_->psk_reporter_check_box->isChecked ();
  psk_reporter_tcpip_ = ui_->psk_reporter_tcpip_check_box->isChecked ();
  eqsl_username_ = ui_->eqsluser_edit->text ();
  eqsl_passwd_ = ui_->eqslpasswd_edit->text ();
  eqsl_nickname_ = ui_->eqslnick_edit->text ();
  id_interval_ = ui_->CW_id_interval_spin_box->value ();
  align_steps_ = ui_->align_spin_box->value ();
  align_steps2_ = ui_->align_spin_box2->value ();
  ntrials_ = ui_->sbNtrials->value ();
  volume_ = ui_->TCI_spin_box->value ();
  txDelay_ = ui_->sbTxDelay->value ();
  aggressive_ = ui_->sbAggressive->value ();
  degrade_ = ui_->sbDegrade->value ();
  RxBandwidth_ = ui_->sbBandwidth->value ();
  tci_audio_ = ui_->tci_audio_check_box->isChecked ();
  id_after_73_ = ui_->CW_id_after_73_check_box->isChecked ();
  tx_frequency_corrections_allowed_ = ui_->tx_frequency_corrections_check_box->isChecked ();
  progressBar_red_ = ui_->progress_bar_check_box->isChecked ();
  monitor_off_at_startup_ = ui_->monitor_off_check_box->isChecked ();
  monitor_last_used_ = ui_->monitor_last_used_check_box->isChecked ();
  type_2_msg_gen_ = static_cast<Type2MsgGen> (ui_->type_2_msg_gen_combo_box->currentIndex ());
  log_as_RTTY_ = ui_->log_as_RTTY_check_box->isChecked ();
  report_in_comments_ = ui_->report_in_comments_check_box->isChecked ();
  specOp_in_comments_ = ui_->specOp_in_comments_check_box->isChecked ();
  prompt_to_log_ = ui_->prompt_to_log_check_box->isChecked ();
  autoLog_ = ui_->cbAutoLog->isChecked();
  contestingOnly_ = ui_->cbContestingOnly->isChecked();
  ZZ00_ = ui_->cbZZ00->isChecked ();
  log4digitGrids_ = ui_->cbLog4digitGrids->isChecked();
  decodes_from_top_ = ui_->decodes_from_top_check_box->isChecked ();
  insert_blank_ = ui_->insert_blank_check_box->isChecked ();
  detailed_blank_ = ui_->cb_detailed_blank_line->isChecked ();
  DXCC_ = ui_->DXCC_check_box->isChecked ();
  gridMap_= ui_->Map_Grid_to_State->isChecked ();
  gridMapAll_ = ui_->Map_All_Messages->isChecked();
  ppfx_ = ui_->ppfx_check_box->isChecked ();
  miles_ = ui_->miles_check_box->isChecked ();
  quick_call_ = ui_->quick_call_check_box->isChecked ();
  disable_TX_on_73_ = ui_->disable_TX_on_73_check_box->isChecked ();
  force_call_1st_ = ui_->force_call_1st_check_box->isChecked ();
  alternate_bindings_ = ui_->alternate_bindings_check_box->isChecked ();
  watchdog_ = ui_->tx_watchdog_spin_box->value ();
  tune_watchdog_ = ui_->tune_watchdog_check_box->isChecked ();
  tune_watchdog_time_ = ui_->tune_watchdog_spin_box->value ();
  TX_messages_ = ui_->TX_messages_check_box->isChecked ();
  data_mode_ = static_cast<DataMode> (ui_->TX_mode_button_group->checkedId ());
  bLowSidelobes_ = ui_->rbLowSidelobes->isChecked();
  save_directory_.setPath (ui_->save_path_display_label->text ());
  azel_directory_.setPath (ui_->azel_path_display_label->text ());
  enable_VHF_features_ = ui_->enable_VHF_features_check_box->isChecked ();
  decode_at_52s_ = ui_->decode_at_52s_check_box->isChecked ();
  kHz_without_k_ = ui_->kHz_without_k_check_box->isChecked ();
  button_coloring_disabled_ = ui_->disable_button_coloring_check_box->isChecked ();
  Wait_features_enabled_ = ui_->enable_Wait_features_check_box->isChecked ();
  showDistance_ = ui_->cb_showDistance->isChecked();
  showAzimuth_ = ui_->cb_showAzimuth->isChecked();
  align_ = ui_->cb_Align->isChecked();
  repeat_Tx_ = ui_->repeat_Tx_check_box->isChecked ();
  auto_astro_ = ui_->auto_astro_check_box->isChecked ();
  single_decode_ = ui_->single_decode_check_box->isChecked ();
  twoPass_ = ui_->cbTwoPass->isChecked ();
  bSuperFox_ = ui_->cbSuperFox->isChecked ();
  Individual_Contest_Name_ = ui_->cbContestName->isChecked ();
  NCCC_Sprint_ = ui_->cb_NCCC_Sprint->isChecked ();
  Blacklisted_ = ui_->cbBlacklist->isChecked ();
  Whitelisted_ = ui_->cbWhitelist->isChecked ();
  AlwaysPass_ = ui_->cbPass->isChecked ();
  filters_for_Wait_and_Pounce_only_ = ui_->cb_filters_for_Wait_and_Pounce_only->isChecked ();
  filters_for_word2_ = ui_->cb_filters_for_word2->isChecked ();
  twoDays_ = ui_->cb_twoDays->isChecked ();
  bSpecialOp_ = ui_->cbSpecialOpActivity->isChecked ();
  bCloudLog_ = ui_->cbCloudlog->isChecked ();
  send_to_eqsl_ = ui_->cbEQSL->isChecked ();
  cloudLogApiUrl_ = ui_->leCloudlogApiUrl->text ();
  cloudLogApiKey_ = ui_->leCloudlogApiKey->text ();
  cloudLogStationID_ = cloudlog_station_profile_id ();
  SelectedActivity_ = ui_->special_op_activity_button_group->checkedId();
  x2ToneSpacing_ = ui_->cbx2ToneSpacing->isChecked ();
  x4ToneSpacing_ = ui_->cbx4ToneSpacing->isChecked ();
  calibration_.intercept = ui_->calibration_intercept_spin_box->value ();
  calibration_.slope_ppm = ui_->calibration_slope_ppm_spin_box->value ();
  sortAlphabetically_ = ui_->cbSortAlphabetically->isChecked ();
  hideCARD_ = ui_->cbHideCARD->isChecked ();
  AzElExtraLines_ = ui_->checkBoxAzElExtraLines->isChecked ();
  pwrBandTxMemory_ = ui_->checkBoxPwrBandTxMemory->isChecked ();
  pwrBandTuneMemory_ = ui_->checkBoxPwrBandTuneMemory->isChecked ();
  opCall_=ui_->opCallEntry->text();
  OTPinterval_=ui_->sbOTPinterval->value();
  OTPSeed_=ui_->OTPSeed->text();
  OTPUrl_=ui_->OTPUrl->text();
  OTPEnabled_=ui_->cbOTP->isChecked();
  ShowOTP_=ui_->cbShowOTP->isChecked();

  auto new_server = ui_->udp_server_line_edit->text ().trimmed ();
  auto new_interfaces = get_selected_network_interfaces (ui_->udp_interfaces_combo_box);
  if (new_server != udp_server_name_ || new_interfaces != udp_interface_names_)
    {
      udp_server_name_ = new_server;
      udp_interface_names_ = new_interfaces;
      Q_EMIT self_->udp_server_changed (udp_server_name_, udp_interface_names_);
    }

  auto new_port = ui_->udp_server_port_spin_box->value ();
  if (new_port != udp_server_port_)
    {
      udp_server_port_ = new_port;
      Q_EMIT self_->udp_server_port_changed (udp_server_port_);
    }

  auto new_TTL = ui_->udp_TTL_spin_box->value ();
  if (new_TTL != udp_TTL_)
    {
      udp_TTL_ = new_TTL;
      Q_EMIT self_->udp_TTL_changed (udp_TTL_);
    }

  if (ui_->accept_udp_requests_check_box->isChecked () != accept_udp_requests_)
    {
      accept_udp_requests_ = ui_->accept_udp_requests_check_box->isChecked ();
      Q_EMIT self_->accept_udp_requests_changed (accept_udp_requests_);
    }

  n1mm_server_name_ = ui_->n1mm_server_name_line_edit->text ();
  n1mm_server_port_ = ui_->n1mm_server_port_spin_box->value ();
  broadcast_to_n1mm_ = ui_->enable_n1mm_broadcast_check_box->isChecked ();

  udpWindowToFront_ = ui_->udpWindowToFront->isChecked ();
  udpWindowRestore_ = ui_->udpWindowRestore->isChecked ();

  if (macros_.stringList () != next_macros_.stringList ())
    {
      macros_.setStringList (next_macros_.stringList ());
    }

  region_ = IARURegions::value (ui_->region_combo_box->currentText ());

  if (frequencies_.frequency_list () != next_frequencies_.frequency_list ())
    {
      frequencies_.frequency_list (next_frequencies_.frequency_list ());
      frequencies_.sort (FrequencyList_v2_101::frequency_column);
    }

  if (stations_.station_list () != next_stations_.station_list ())
    {
      stations_.station_list (next_stations_.station_list ());
      stations_.sort (StationList::band_column);
    }

  if (decode_highlighing_model_.items () != next_decode_highlighing_model_.items ())
    {
      decode_highlighing_model_.items (next_decode_highlighing_model_.items ());
      Q_EMIT self_->decode_highlighting_changed (decode_highlighing_model_);
    }
  highlight_by_mode_ = ui_->highlight_by_mode_check_box->isChecked ();
  highlight_only_fields_ = ui_->only_fields_check_box->isChecked ();
  include_WAE_entities_ = ui_->include_WAE_check_box->isChecked ();
  highlight_73_ = ui_->highlight_73_check_box->isChecked ();
  highlight_orange_ = ui_->highlight_orange_check_box->isChecked ();
  highlight_blue_ = ui_->highlight_blue_check_box->isChecked ();
  alternate_erase_button_ = ui_->alternate_erase_button_check_box->isChecked ();
  show_country_names_ = ui_->show_country_names_check_box->isChecked ();
  LotW_days_since_upload_ = ui_->LotW_days_since_upload_spin_box->value ();
  lotw_users_.set_age_constraint (LotW_days_since_upload_);

  if (ui_->use_dynamic_grid->isChecked() && !use_dynamic_grid_ )
  {
    // turning on so clear it so only the next location update gets used
    dynamic_grid_.clear ();
  }
  use_dynamic_grid_ = ui_->use_dynamic_grid->isChecked();
  highlight_DXcall_ = ui_->cbHighlightDXcall->isChecked();
  clear_DXcall_ = ui_->cbClearDXcall->isChecked();
  highlight_DXgrid_ = ui_->cbHighlightDXgrid->isChecked();
  clear_DXgrid_ = ui_->cbClearDXgrid->isChecked();
  erase_BandActivity_ = ui_->cbEraseBandActivity->isChecked();
  set_RXtoTX_ = ui_->cbRxToTxAfterQSO->isChecked();
  ZZ00_ = ui_->cbZZ00->isChecked();
  NCCC_Sprint_ = ui_->cb_NCCC_Sprint->isChecked();
  Blacklisted_ = ui_->cbBlacklist->isChecked();
  Whitelisted_ = ui_->cbWhitelist->isChecked();
  AlwaysPass_ = ui_->cbPass->isChecked();
  filters_for_Wait_and_Pounce_only_ = ui_->cb_filters_for_Wait_and_Pounce_only->isChecked();
  filters_for_word2_ = ui_->cb_filters_for_word2->isChecked();
  twoDays_ = ui_->cb_twoDays->isChecked();
  alert_CQ_ = ui_->cbCQ->isChecked();
  alert_MyCall_ = ui_->cbMyCall->isChecked();
  alert_DXCC_ = ui_->cbDXCC->isChecked();
  alert_DXCCOB_ = ui_->cbDXCCOB->isChecked();
  alert_Grid_ = ui_->cbGrid->isChecked();
  alert_GridOB_ = ui_->cbGridOB->isChecked();
  alert_Continent_ = ui_->cbContinent->isChecked();
  alert_ContinentOB_ = ui_->cbContinentOB->isChecked();
  alert_CQZ_ = ui_->cbCQZ->isChecked();
  alert_CQZOB_ = ui_->cbCQZOB->isChecked();
  alert_ITUZ_ = ui_->cbITUZ->isChecked();
  alert_ITUZOB_ = ui_->cbITUZOB->isChecked();
  alert_DXcall_ = ui_->cbDXcall->isChecked();
  alert_Wanted_ = ui_->cbWanted->isChecked();
  alert_QSYmessage_ = ui_->cbQSYmessage->isChecked();
  alert_Enabled_ = ui_->pbAlerts->isChecked();

  write_settings ();		// make visible to all
  if (suggestion_notice_state_.commit (FrequencyList_v2_101::default_items (),
                                       frequencies_.frequency_list ()))
    persist_seen_suggestions ();
}

void Configuration::impl::reject ()
{
  suggestion_notice_state_.cancel ();
  if (dns_lookup_id_ > -1)
    {
      QHostInfo::abortHostLookup (dns_lookup_id_);
      dns_lookup_id_ = -1;
    }

  initialize_models ();		// reverts to settings as at exec ()

  // check if the Transceiver instance changed, in which case we need
  // to re open any prior Transceiver type
  if (rig_changed_)
    {
      if (have_rig_)
        {
          // we have to do this since the rig has been opened since we
          // were exec'ed even though it might fail
          open_rig ();
        }
      else
        {
          close_rig ();
        }
    }

  // qDebug () << "Configure::reject: audio i/p:" << audio_input_device_.deviceName ()
  //           << "chan:" << audio_input_channel_
  //           << "o/p:" << audio_output_device_.deviceName ()
  //           << "chan:" << audio_output_channel_
  //           << "reset i/p:" << restart_sound_input_device_
  //           << "reset o/p:" << restart_sound_output_device_;

  QDialog::reject ();
}

void Configuration::impl::on_font_push_button_clicked ()
{
  next_font_ = QFontDialog::getFont (0, next_font_, this);
}

void Configuration::impl::apply_color_preset (DecodeHighlightingModel::ColorPreset const& preset)
{
  if (!next_decode_highlighing_model_.apply_color_preset (preset))
    {
      MessageBox::warning_message (
        this,
        tr ("Color Preset Error"),
        tr ("The selected color preset could not be applied. "
            "Reset decode highlighting to a default configuration and try again."));
    }
}

void Configuration::impl::reset_highlighting (QString const& confirmation, DecodeHighlightingModel::HighlightItems const& items)
{
  if (MessageBox::Yes == MessageBox::query_message (this
                                                    , tr ("Reset Decode Highlighting")
                                                    , confirmation))
    {
      next_decode_highlighing_model_.items (items);
    }
}

void Configuration::impl::on_rescan_log_push_button_clicked (bool /*clicked*/)
{
  if (logbook_) {
    logbook_->rescan ();
  }
}

void Configuration::impl::on_CTY_download_button_clicked (bool /*clicked*/)
{
  ui_->CTY_download_button->setEnabled (false); // disable button until download is complete
  QDir dataPath {QStandardPaths::writableLocation (QStandardPaths::DataLocation)};
  cty_download_.configure(network_manager_,
                          "http://www.country-files.com/bigcty/cty.dat",
                          dataPath.absoluteFilePath("cty.dat"),
                          "WSJT-X CTY Downloader");

  connect (&cty_download_, &FileDownload::complete, this, &Configuration::impl::after_CTY_downloaded, Qt::UniqueConnection);
  connect (&cty_download_, &FileDownload::error, this, &Configuration::impl::error_during_CTY_download, Qt::UniqueConnection);
  cty_download_.start_download();
}

void Configuration::impl::set_CTY_DAT_version(QString const& version)
{
  ui_->CTY_file_label->setText(QString{"CTY File Version: %1"}.arg(version));
}

void Configuration::impl::error_during_CTY_download (QString const& reason)
{
  MessageBox::warning_message (this, tr ("Error Loading CTY.DAT"), reason);
  after_CTY_downloaded();
}

void Configuration::impl::after_CTY_downloaded ()
{
  ui_->CTY_download_button->setEnabled (true);
  if (logbook_) {
    logbook_->rescan ();
    ui_->CTY_file_label->setText(QString{"CTY File Version: %1"}.arg(logbook_->cty_version()));
  }
}

void Configuration::impl::on_CALL3_download_button_clicked (bool /*clicked*/)
{
  ui_->CALL3_download_button->setEnabled (false); // disable button until download is complete
  QDir dataPath {QStandardPaths::writableLocation (QStandardPaths::DataLocation)};
  QFile g {dataPath.absolutePath() + "/" + "CALL3_backup.TXT"};
  if (g.exists()) QFile::rename(dataPath.absolutePath() + "/" + "CALL3_backup.TXT", dataPath.absolutePath() + "/" + "CALL3_backup.tmp");
  QFile f {dataPath.absolutePath() + "/" + "CALL3.TXT"};
  if (f.exists()) QFile::rename(dataPath.absolutePath() + "/" + "CALL3.TXT", dataPath.absolutePath() + "/" + "CALL3_backup.TXT");
  call3_download_.configure(network_manager_,
                            "https://wsjt-x-improved.sourceforge.io/CALL3.TXT",
                            dataPath.absoluteFilePath("CALL3.TXT"),
                            "Downloading latest CALL3.TXT file");

  connect (&call3_download_, &FileDownload::complete, this, &Configuration::impl::after_CALL3_downloaded, Qt::UniqueConnection);
  connect (&call3_download_, &FileDownload::error, this, &Configuration::impl::error_during_CALL3_download, Qt::UniqueConnection);
  call3_download_.start_download();
  ui_->CALL3_file_label->setText("Downloading ...");
}

void Configuration::impl::on_CALL3_EME_download_button_clicked (bool /*clicked*/)
{
  ui_->CALL3_EME_download_button->setEnabled (false); // disable button until download is complete
  QDir dataPath {QStandardPaths::writableLocation (QStandardPaths::DataLocation)};
  QFile g {dataPath.absolutePath() + "/" + "CALL3_backup.TXT"};
  if (g.exists()) QFile::rename(dataPath.absolutePath() + "/" + "CALL3_backup.TXT", dataPath.absolutePath() + "/" + "CALL3_backup.tmp");
  QFile f {dataPath.absolutePath() + "/" + "CALL3.TXT"};
  if (f.exists()) QFile::rename(dataPath.absolutePath() + "/" + "CALL3.TXT", dataPath.absolutePath() + "/" + "CALL3_backup.TXT");
  call3_download_.configure(network_manager_,
                            "https://wsjt-x-improved.sourceforge.io/CALL3_EME.TXT",
                            dataPath.absoluteFilePath("CALL3.TXT"),
                            "Downloading latest CALL3.TXT file");

  connect (&call3_download_, &FileDownload::complete, this, &Configuration::impl::after_CALL3_downloaded, Qt::UniqueConnection);
  connect (&call3_download_, &FileDownload::error, this, &Configuration::impl::error_during_CALL3_download, Qt::UniqueConnection);
  call3_download_.start_download();
  ui_->CALL3_file_label->setText("Downloading ...");
}

void Configuration::impl::error_during_CALL3_download (QString const& reason)
{
  MessageBox::warning_message (this, tr ("Error Loading CALL3.TXT file"), reason);
  ui_->CALL3_download_button->setEnabled (true);
  ui_->CALL3_EME_download_button->setEnabled (true);
  QDir dataPath {QStandardPaths::writableLocation (QStandardPaths::DataLocation)};
  QFile f {dataPath.absolutePath() + "/" + "CALL3.TXT"};
  if (!f.exists()) QFile::copy(dataPath.absolutePath() + "/" + "CALL3_backup.TXT", dataPath.absolutePath() + "/" + "CALL3.TXT");
  QFile g {dataPath.absolutePath() + "/" + "CALL3_backup.TXT"};
  QFile h {dataPath.absolutePath() + "/" + "CALL3_backup.tmp"};
  if (!g.exists() and h.exists()) {
    QFile::rename(dataPath.absolutePath() + "/" + "CALL3_backup.tmp", dataPath.absolutePath() + "/" + "CALL3_backup.TXT");
  } else {
    if (h.exists()) QFile::remove(dataPath.absolutePath() + "/" + "CALL3_backup.tmp");
  }
  read_CALL3_version ();
}

void Configuration::impl::after_CALL3_downloaded ()
{
  ui_->CALL3_download_button->setEnabled (true);
  ui_->CALL3_EME_download_button->setEnabled (true);
  QDir dataPath {QStandardPaths::writableLocation (QStandardPaths::DataLocation)};
  QFile g {dataPath.absolutePath() + "/" + "CALL3_backup.TXT"};
  QFile h {dataPath.absolutePath() + "/" + "CALL3_backup.tmp"};
  if (!g.exists() and h.exists()) {
    QFile::rename(dataPath.absolutePath() + "/" + "CALL3_backup.tmp", dataPath.absolutePath() + "/" + "CALL3_backup.TXT");
  } else {
    if (h.exists()) QFile::remove(dataPath.absolutePath() + "/" + "CALL3_backup.tmp");
  }
  read_CALL3_version ();
}

void Configuration::impl::read_CALL3_version ()
{
  QString text;
  QDir dataPath {QStandardPaths::writableLocation (QStandardPaths::DataLocation)};
  QFile call3file {dataPath.absolutePath() + "/" + "CALL3.TXT"};
    QTextStream call3stream(&call3file);
    if(call3file.open (QIODevice::ReadOnly | QIODevice::Text)) {
        while (!call3stream.atEnd()) {
            text = call3stream.readLine();
            if (text.contains("// Version:")) break;
        }
        call3stream.flush();
        call3file.close();
    }
  if (text.contains("// Version:")) {
    ui_->CALL3_file_label->setText("CALL3 File Version:" + text.mid(11,30));
  } else {
    ui_->CALL3_file_label->setText("CALL3 File Version: not available");
  }
}

void Configuration::impl::on_LotW_CSV_fetch_push_button_clicked (bool /*checked*/)
{
  lotw_users_.load (ui_->LotW_CSV_URL_line_edit->text (), true, true);
  ui_->LotW_CSV_fetch_push_button->setEnabled (false);
}

void Configuration::impl::on_decoded_text_font_push_button_clicked ()
{
  next_decoded_text_font_ = QFontDialog::getFont (0, decoded_text_font_ , this
                                                  , tr ("WSJT-X Decoded Text Font Chooser")
                                                  , QFontDialog::MonospacedFonts
                                                  );
}

void Configuration::impl::on_hamlib_download_button_clicked (bool /*clicked*/)
{
#ifdef WIN32
  extern char* hamlib_version2;
  QString hamlib = QString(QLatin1String(hamlib_version2));
  SettingsGroup g {settings_, "Configuration"};
  settings_->setValue ("HamlibBackedUp", hamlib);
  settings_->sync ();
  QDir dataPath = QCoreApplication::applicationDirPath();
  QFile f1 {dataPath.absolutePath() + "/" + "libhamlib-4_old.dll"};
  QFile f2 {dataPath.absolutePath() + "/" + "libhamlib-4_new.dll"};
  if (f1.exists()) f1.remove();
  if (f2.exists()) f2.remove();
  ui_->hamlib_download_button->setEnabled (false);
  ui_->revert_update_button->setEnabled (false);
  if (ui_->rbHamlib32->isChecked()) {
    hamlib_download_.configure(network_manager_,
                               "https://hamlib.sourceforge.net/snapshots-4.7/dll32/libhamlib-4.dll",
                               dataPath.absoluteFilePath("libhamlib-4_new.dll"),
                               "Downloading latest libhamlib-4.dll");
  } else {
    hamlib_download_.configure(network_manager_,
                               "https://hamlib.sourceforge.net/snapshots-4.7/dll64/libhamlib-4.dll",
                               dataPath.absoluteFilePath("libhamlib-4_new.dll"),
                               "Downloading latest libhamlib-4.dll");
  }
  connect (&hamlib_download_, &FileDownload::complete, this, &Configuration::impl::after_hamlib_downloaded, Qt::UniqueConnection);
  connect (&hamlib_download_, &FileDownload::error, this, &Configuration::impl::error_during_hamlib_download, Qt::UniqueConnection);
  ui_->in_use->setText("Downloading ...");

  hamlib_download_.start_download();
#else
  MessageBox::warning_message (this, tr ("Hamlib update only available on Windows."));
#endif
}

void Configuration::impl::error_during_hamlib_download (QString const& reason)
{
  QDir dataPath = QCoreApplication::applicationDirPath();
  MessageBox::warning_message (this, tr ("Error Loading libhamlib-4.dll"), reason);
  ui_->hamlib_download_button->setEnabled (true);
  ui_->revert_update_button->setEnabled (true);
#ifdef WIN32
  extern char* hamlib_version2;
  QString hamlib = QString(QLatin1String(hamlib_version2));
  ui_->in_use->setText(hamlib);
#else
  extern char* hamlib_version2;
  QString hamlib = QString(QLatin1String(hamlib_version2));
  ui_->in_use->setText(hamlib);
#endif
}

void Configuration::impl::after_hamlib_downloaded ()
{
  QDir dataPath = QCoreApplication::applicationDirPath();
  QFile::rename(dataPath.absolutePath() + "/" + "libhamlib-4.dll", dataPath.absolutePath() + "/" + "libhamlib-4_old.dll");
  QTimer::singleShot (1000, this, [=] {
    QFile::rename(dataPath.absolutePath() + "/" + "libhamlib-4_new.dll", dataPath.absolutePath() + "/" + "libhamlib-4.dll");
    ui_->in_use->setText("Download completed. Restart the program.");
  });
  QTimer::singleShot (1500, this, [=] {
    MessageBox::information_message (this, tr ("Hamlib Update successful \n\nNew Hamlib will be used after restart"));
    ui_->revert_update_button->setEnabled (true);
    ui_->hamlib_download_button->setEnabled (true);
  });
}

void Configuration::impl::on_revert_update_button_clicked (bool /*clicked*/)
{
#ifdef WIN32
  QDir dataPath = QCoreApplication::applicationDirPath();
  QFile f {dataPath.absolutePath() + "/" + "libhamlib-4_old.dll"};
  if (f.exists()) {
    ui_->revert_update_button->setEnabled (false);
    ui_->hamlib_download_button->setEnabled (false);
    QFile::rename(dataPath.absolutePath() + "/" + "libhamlib-4.dll", dataPath.absolutePath() + "/" + "libhamlib-4_new.dll");
    QTimer::singleShot (1000, this, [=] {
      QFile::copy(dataPath.absolutePath() + "/" + "libhamlib-4_old.dll", dataPath.absolutePath() + "/" + "libhamlib-4.dll");
    });
    QTimer::singleShot (2000, this, [=] {
      MessageBox::information_message (this, tr ("Hamlib successfully reverted \n\nReverted Hamlib will be used after restart"));
      ui_->revert_update_button->setEnabled (true);
      ui_->hamlib_download_button->setEnabled (true);
    });
  } else {
    MessageBox::warning_message (this, tr ("No Hamlib update found that could be reverted"));
  }
#else
  MessageBox::warning_message (this, tr ("Hamlib update only available on Windows."));
#endif
}

void Configuration::impl::display_file_information ()
{
#ifdef WIN32
  QDir dataPath = QCoreApplication::applicationDirPath();
  extern char* hamlib_version2;
  QString hamlib = QString(QLatin1String(hamlib_version2));
  ui_->in_use->setText(hamlib);
  QFileInfo fi2(dataPath.absolutePath() + "/" + "libhamlib-4_old.dll");
  QString birthTime2 = fi2.birthTime().toString("yyyy-MM-dd hh:mm");
  QFile f {dataPath.absolutePath() + "/" + "libhamlib-4_old.dll"};
  if (f.exists()) {
    if (hamlib_backed_up_=="") {
      ui_->backed_up->setText(QString{"no hamlib data available, file saved %1"}.arg(birthTime2));
    } else {
      ui_->backed_up->setText(hamlib_backed_up_);
    }
  } else {
      ui_->backed_up->setText("");
  }
#else
  extern char* hamlib_version2;
  QString hamlib = QString(QLatin1String(hamlib_version2));
  ui_->in_use->setText(hamlib);
#endif
}

void Configuration::impl::on_DXCC_check_box_toggled (bool)
{
  update_DXCC_control_availability ();
}

void Configuration::impl::update_DXCC_control_availability ()
{
  auto const enabled = ui_->DXCC_check_box->isChecked ();
  ui_->ppfx_check_box->setEnabled (enabled);
  ui_->show_country_names_check_box->setEnabled (enabled);
}

void Configuration::impl::on_PTT_port_combo_box_currentTextChanged (QString const& /* text */)
{
  set_rig_invariants ();
}

void Configuration::impl::on_CAT_port_combo_box_currentTextChanged (QString const& /* text */)
{
  set_rig_invariants ();
}

void Configuration::impl::on_CAT_serial_baud_combo_box_currentIndexChanged (int /* index */)
{
  set_rig_invariants ();
}

void Configuration::impl::on_rig_combo_box_currentIndexChanged (int /* index */)
{
  set_rig_invariants ();
  if(ui_->rig_combo_box->currentText().startsWith("OmniRig") || ui_->rig_combo_box->currentText().startsWith("DX Lab") ||
     ui_->rig_combo_box->currentText().startsWith("Ham Radio") || ui_->rig_combo_box->currentText().startsWith("Kenwood TS-480") ||
     ui_->rig_combo_box->currentText().startsWith("Kenwood TS-850") ||
     ui_->rig_combo_box->currentText().startsWith("Kenwood TS-870")) {
     ui_->PWR_and_SWR_check_box->setChecked (false);
     ui_->PWR_and_SWR_check_box->setEnabled (false);
     ui_->check_SWR_check_box->setChecked (false);
     ui_->check_SWR_check_box->setEnabled (false);
  }
}

void Configuration::impl::on_PWR_and_SWR_check_box_toggled (bool)
{
  update_PWR_and_SWR_control_availability ();
}

void Configuration::impl::update_PWR_and_SWR_control_availability ()
{
  ui_->check_SWR_check_box->setEnabled (ui_->PWR_and_SWR_check_box->isChecked ());
}

void Configuration::impl::on_CAT_poll_interval_spin_box_valueChanged (int /* value */)
{
  set_rig_invariants ();
}

void Configuration::impl::on_test_CAT_push_button_clicked ()
{
  if (!validate ())
    {
      return;
    }

  ui_->test_CAT_push_button->setStyleSheet ({});
  if (open_rig (true))
    {
       // Q_EMIT sync (true);
    }

  set_rig_invariants ();
}

void Configuration::impl::on_pbTestCloudlog_clicked ()
{
  cloudlog_.checkConnection ({ui_->leCloudlogApiUrl->text (),
                              ui_->leCloudlogApiKey->text (),
                              cloudlog_station_profile_id ()});
}

void Configuration::impl::handle_cloudlog_connection_check_result (Cloudlog::ConnectionCheckResult const& result)
{
  if (!result.stationProfiles.isEmpty ())
    {
      set_cloudlog_station_profiles (result.stationProfiles);
    }

  ui_->pbTestCloudlog->setStyleSheet (cloudlog_connection_check_style (result.status));

  auto tooltip = result.message;
  if (!result.detail.isEmpty ())
    {
      tooltip += QStringLiteral ("\n") + result.detail;
    }
  ui_->pbTestCloudlog->setToolTip (tooltip);
}

void Configuration::impl::set_cloudlog_station_profiles (QList<Cloudlog::StationProfile> const& profiles)
{
  auto const current_id = cloudlog_station_profile_id ();
  ui_->cbCloudlogStationProfile->clear ();
  for (auto const& profile : profiles)
    {
      ui_->cbCloudlogStationProfile->addItem (Cloudlog::stationProfileDisplayText (profile), profile.id);
    }

  if (current_id > 0)
    {
      auto const index = ui_->cbCloudlogStationProfile->findData (current_id);
      if (index >= 0)
        {
          ui_->cbCloudlogStationProfile->setCurrentIndex (index);
        }
      else
        {
          ui_->cbCloudlogStationProfile->insertItem (0, QString::number (current_id), current_id);
          ui_->cbCloudlogStationProfile->setCurrentIndex (0);
        }
    }
  else if (ui_->cbCloudlogStationProfile->count () > 0)
    {
      ui_->cbCloudlogStationProfile->setCurrentIndex (0);
    }
}

qint32 Configuration::impl::cloudlog_station_profile_id () const
{
  bool ok {false};
  auto const current_text = ui_->cbCloudlogStationProfile->currentText ().trimmed ();
  auto const current_index = ui_->cbCloudlogStationProfile->currentIndex ();
  if (current_index >= 0 && ui_->cbCloudlogStationProfile->itemText (current_index).trimmed () == current_text)
    {
      auto const data = ui_->cbCloudlogStationProfile->itemData (current_index);
      auto const id = data.toInt (&ok);
      if (ok && id > 0)
        {
          return id;
        }
    }

  auto const prefix = current_text.section (QStringLiteral (" - "), 0, 0).trimmed ();
  auto const text_id = prefix.toInt (&ok);
  return ok && text_id > 0 ? text_id : 0;
}

void Configuration::impl::on_cbCloudlog_toggled (bool checked)
{
  ui_->api_url_label->setEnabled (checked);
  ui_->api_key_label->setEnabled (checked);
  ui_->station_profile_label->setEnabled (checked);
  ui_->leCloudlogApiUrl->setEnabled (checked);
  ui_->leCloudlogApiKey->setEnabled (checked);
  ui_->cbCloudlogStationProfile->setEnabled (checked);
  ui_->pbTestCloudlog->setEnabled (checked);
  ui_->pbTestCloudlog->setStyleSheet ("QPushButton {background-color: none;}");
}

void Configuration::impl::on_cbEQSL_toggled (bool checked)
{
  ui_->eqsluser_label->setEnabled (checked);
  ui_->eqslpasswd_label->setEnabled (checked);
  ui_->eqslnick_label->setEnabled (checked);
  ui_->eqsluser_edit->setEnabled (checked);
  ui_->eqslpasswd_edit->setEnabled (checked);
  ui_->eqslnick_edit->setEnabled (checked);
}

void Configuration::impl::on_test_PTT_push_button_clicked (bool checked)
{
  auto const showing_requested_ptt = tx_inhibit_active_;
  if (!showing_requested_ptt)
    {
      ui_->test_PTT_push_button->setChecked (!checked);
    }
  if (!validate ())
    {
      if (showing_requested_ptt) ui_->test_PTT_push_button->setChecked (!checked);
      return;
    }

  auto const rig_data = gather_rig_data ();
  if (tx_inhibit_blocks_rig_restart (rig_data, false))
    {
      ui_->test_PTT_push_button->setChecked (cached_rig_state_.ptt ());
      if (!showing_requested_ptt)
        {
          ui_->test_PTT_push_button->setChecked (!checked);
        }
      MessageBox::warning_message (
        this, tr ("Cannot test PTT while TX inhibit is active"),
        tr ("Wait for the current inhibit hold to clear before testing "
            "changed radio settings or changing PTT state."));
      return;
    }

  if (open_rig ())
    {
      Q_EMIT self_->transceiver_ptt (checked);
    }
  else if (showing_requested_ptt)
    {
      ui_->test_PTT_push_button->setChecked (!checked);
    }
}

void Configuration::impl::on_force_DTR_combo_box_currentIndexChanged (int /* index */)
{
  set_rig_invariants ();
}

void Configuration::impl::on_force_RTS_combo_box_currentIndexChanged (int /* index */)
{
  set_rig_invariants ();
}

void Configuration::impl::on_refresh_push_button_clicked ()
{
  //
  // load combo boxes with audio setup choices
  //
//  default_audio_input_device_selected_ = load_audio_devices (QAudio::AudioInput, ui_->sound_input_combo_box, &audio_input_device_);
//  default_audio_output_device_selected_ = load_audio_devices (QAudio::AudioOutput, ui_->sound_output_combo_box, &audio_output_device_);

  update_audio_channels (ui_->sound_input_combo_box, ui_->sound_input_combo_box->currentIndex (), ui_->sound_input_channel_combo_box, false);
  update_audio_channels (ui_->sound_output_combo_box, ui_->sound_output_combo_box->currentIndex (), ui_->sound_output_channel_combo_box, true);

  ui_->sound_input_channel_combo_box->setCurrentIndex (audio_input_channel_);
  ui_->sound_output_channel_combo_box->setCurrentIndex (audio_output_channel_);

  restart_sound_input_device_ = false;
  restart_sound_output_device_ = false;
  restart_tci_device_ = false;
}

void Configuration::impl::on_tci_audio_check_box_clicked(bool checked)
{
  tci_audio_ = checked;
  if (is_tci_ && checked) {
    find_audio_devices ();
    ui_->sound_input_channel_combo_box->setCurrentIndex (0);
    ui_->sound_output_channel_combo_box->setCurrentIndex (0);
  }
}

void Configuration::impl::on_TCI_spin_box_valueChanged(double a)
{
  volume_ = a;
}


void Configuration::impl::on_grid_line_edit_editingFinished ()
{
  double centre_lat, centre_lon;
  if (!grid_centre (ui_->grid_line_edit->text (), centre_lat, centre_lon))
    {
      update_home_coordinates_style ();
      return;
    }
  auto grid = ui_->grid_line_edit->text ().trimmed ().left (6);
  if (grid.size () < 6) grid += "mm";

  // If the currently displayed precise coordinates already lie in this
  // six-character square, re-entering the same locator must not discard
  // their extra precision.
  bool lat_ok {false};
  bool lon_ok {false};
  auto current_lat = ui_->latitude_line_edit->text ().toDouble (&lat_ok);
  auto current_lon = ui_->longitude_line_edit->text ().toDouble (&lon_ok);
  if (lat_ok && lon_ok && current_lat >= -90. && current_lat <= 90.
      && current_lon >= -180. && current_lon <= 180.)
    {
      QString coordinate_grid;
      coordinates_to_grid (current_lat, current_lon, coordinate_grid);
      if (coordinate_grid.compare (grid, Qt::CaseInsensitive) == 0)
        {
          update_home_coordinates_style ();
          return;
        }
    }

  ui_->latitude_line_edit->setText (QString::number (centre_lat, 'f', 6));
  ui_->longitude_line_edit->setText (QString::number (centre_lon, 'f', 6));
  update_home_coordinates_style ();
}

void Configuration::impl::update_home_coordinates_style ()
{
  // Highlight coordinates entered by the user; those derived from the
  // centre of My Grid keep the normal appearance.
  bool lat_ok {false};
  bool lon_ok {false};
  auto lat = ui_->latitude_line_edit->text ().toDouble (&lat_ok);
  auto lon = ui_->longitude_line_edit->text ().toDouble (&lon_ok);
  bool user_entered = lat_ok && lon_ok
    && !coordinates_are_grid_centre (ui_->grid_line_edit->text (), lat, lon);
  for (auto edit : {ui_->latitude_line_edit, ui_->longitude_line_edit})
    {
      QPalette pal;
      if (user_entered)
        {
          pal = edit->palette ();
          pal.setColor (QPalette::Base, "#ffffcc");
          pal.setColor (QPalette::Text, Qt::black);
        }
      edit->setPalette (pal);
    }
  auto tip = user_entered ? tr ("Precise coordinates entered by user; used for astronomical calculations.")
                          : tr ("Centre of the My Grid locator; enter precise coordinates for more accurate astronomical calculations.");
  ui_->latitude_line_edit->setToolTip (tr ("Home-station latitude in decimal degrees. North is positive; south is negative.") + '\n' + tip);
  ui_->longitude_line_edit->setToolTip (tr ("Home-station longitude in decimal degrees. East is positive; west is negative.") + '\n' + tip);
}

void Configuration::impl::on_latitude_line_edit_editingFinished ()
{
  on_longitude_line_edit_editingFinished ();
}

void Configuration::impl::on_longitude_line_edit_editingFinished ()
{
  // Clearing both fields reverts to the My Grid position, so show it.
  if (ui_->latitude_line_edit->text ().trimmed ().isEmpty ()
      && ui_->longitude_line_edit->text ().trimmed ().isEmpty ())
    {
      on_grid_line_edit_editingFinished ();
      return;
    }

  bool lat_ok {false};
  bool lon_ok {false};
  auto lat = ui_->latitude_line_edit->text ().toDouble (&lat_ok);
  auto lon = ui_->longitude_line_edit->text ().toDouble (&lon_ok);
  if (!lat_ok || !lon_ok || lat < -90. || lat > 90. || lon < -180. || lon > 180.) return;

  QString grid;
  if (!coordinates_to_grid (lat, lon, grid)) return;
  ui_->grid_line_edit->setText (grid);
  update_home_coordinates_style ();
}

void Configuration::impl::on_add_macro_line_edit_editingFinished ()
{
  ui_->add_macro_line_edit->setText (ui_->add_macro_line_edit->text ().toUpper ());
}

void Configuration::impl::on_delete_macro_push_button_clicked (bool /* checked */)
{
  delete_macro ();
}

void Configuration::impl::delete_macro ()
{
  auto selection_model = ui_->macros_list_view->selectionModel ();
  if (!selection_model->hasSelection ())
    {
      // delete item under cursor if any
      auto index = selection_model->currentIndex ();
      if (index.isValid ())
        {
          next_macros_.removeRow (index.row ());
        }
    }
  else
    {
      // delete the whole selection
      delete_selected_macros (selection_model->selectedRows ());
    }
}

void Configuration::impl::delete_selected_macros (QModelIndexList selected_rows)
{
  // sort in reverse row order so that we can delete without changing
  // indices underneath us
  std::sort (selected_rows.begin (), selected_rows.end (), [] (QModelIndex const& lhs, QModelIndex const& rhs)
             {
               return rhs.row () < lhs.row (); // reverse row ordering
             });

  // now delete them
  Q_FOREACH (auto index, selected_rows)
    {
      next_macros_.removeRow (index.row ());
    }
}

void Configuration::impl::move_selected_macros (int delta)
{
  auto selection_model = ui_->macros_list_view->selectionModel ();
  QModelIndexList selected_rows = selection_model->selectedRows ();
  if (!selection_model->hasSelection () && selection_model->currentIndex ().isValid ())
    {
      selected_rows.append (selection_model->currentIndex ());
    }

  QList<int> rows;
  Q_FOREACH (auto const& index, selected_rows)
    {
      if (index.isValid ())
        {
          rows.append (index.row ());
        }
    }

  std::sort (rows.begin (), rows.end ());
  rows.erase (std::unique (rows.begin (), rows.end ()), rows.end ());
  if (rows.isEmpty ())
    {
      return;
    }

  auto const row_count = next_macros_.rowCount ();
  if ((delta < 0 && rows.first () == 0)
      || (delta > 0 && rows.last () >= row_count - 1))
    {
      return;
    }

  auto messages = next_macros_.stringList ();
  QList<int> moved_rows;
  if (delta < 0)
    {
      Q_FOREACH (auto row, rows)
        {
          qSwap (messages[row], messages[row - 1]);
          moved_rows.append (row - 1);
        }
    }
  else if (delta > 0)
    {
      for (auto row = rows.crbegin (); row != rows.crend (); ++row)
        {
          qSwap (messages[*row], messages[*row + 1]);
          moved_rows.append (*row + 1);
        }
      std::sort (moved_rows.begin (), moved_rows.end ());
    }
  else
    {
      return;
    }

  next_macros_.setStringList (messages);

  selection_model = ui_->macros_list_view->selectionModel ();
  selection_model->clearSelection ();
  Q_FOREACH (auto row, moved_rows)
    {
      auto index = next_macros_.index (row);
      selection_model->select (index, QItemSelectionModel::Select | QItemSelectionModel::Rows);
    }
  ui_->macros_list_view->setCurrentIndex (next_macros_.index (moved_rows.first ()));
}

void Configuration::impl::on_move_macro_up_push_button_clicked (bool /* checked */)
{
  move_selected_macros (-1);
}

void Configuration::impl::on_move_macro_down_push_button_clicked (bool /* checked */)
{
  move_selected_macros (1);
}

void Configuration::impl::move_selected_highlighting_rule (int delta)
{
  auto const current_index = ui_->highlighting_list_view->currentIndex ();
  if (!current_index.isValid () || 0 == delta)
    {
      return;
    }

  auto items = next_decode_highlighing_model_.items ();
  auto const row = current_index.row ();
  auto const target_row = row + delta;
  if (row < 0 || row >= items.size () || target_row < 0 || target_row >= items.size ())
    {
      return;
    }

  qSwap (items[row], items[target_row]);
  next_decode_highlighing_model_.items (items);

  auto const moved_index = next_decode_highlighing_model_.index (target_row, 0);
  ui_->highlighting_list_view->setCurrentIndex (moved_index);
  if (auto selection_model = ui_->highlighting_list_view->selectionModel ())
    {
      selection_model->clearSelection ();
      selection_model->select (moved_index, QItemSelectionModel::Select | QItemSelectionModel::Rows);
    }
}

void Configuration::impl::on_move_highlighting_up_push_button_clicked (bool /* checked */)
{
  move_selected_highlighting_rule (-1);
}

void Configuration::impl::on_move_highlighting_down_push_button_clicked (bool /* checked */)
{
  move_selected_highlighting_rule (1);
}

void Configuration::impl::on_add_macro_push_button_clicked (bool /* checked */)
{
  if (next_macros_.insertRow (next_macros_.rowCount ()))
    {
      auto index = next_macros_.index (next_macros_.rowCount () - 1);
      ui_->macros_list_view->setCurrentIndex (index);
      next_macros_.setData (index, ui_->add_macro_line_edit->text ());
      ui_->add_macro_line_edit->clear ();
    }
}

void Configuration::impl::on_udp_server_line_edit_textChanged (QString const&)
{
  udp_server_name_edited_ = true;
}

void Configuration::impl::on_udp_server_line_edit_editingFinished ()
{
  if (this->isVisible())
  {
    int q1,q2,q3,q4;
    char tmpbuf[2];
    int n = sscanf(ui_->udp_server_line_edit->text ().trimmed ().toLatin1(), "%d.%d.%d.%d.%1s", &q1, &q2, &q3, &q4, tmpbuf);
    const char *iperr;
    switch(n)
    {
      case 0: iperr = "Error before first number";break;
      case 1: iperr = "Error between first and second number";break;
      case 2: iperr = "Error between second and third number";break;
      case 3: iperr = "Error between third and fourth number";break;
      case 4: iperr = ""; break;
      case 5: iperr = "Invalid characters after IP address"; break;
      default: iperr = "Unknown error parsing network address";
    }
    if (n != 4)
    {
       MessageBox::warning_message (this, tr ("Error in network address"), tr (iperr));
       return;
    }

  if (udp_server_name_edited_)
    {
      auto const& server = ui_->udp_server_line_edit->text ().trimmed ();
      QHostAddress ha {server};
      if (server.size () && ha.isNull ())
        {
          // queue a host address lookup
          // qDebug () << "server host DNS lookup:" << server;
#if QT_VERSION >= QT_VERSION_CHECK(5, 9, 0)
          dns_lookup_id_ = QHostInfo::lookupHost (server, this, &Configuration::impl::host_info_results);
#else
          dns_lookup_id_ = QHostInfo::lookupHost (server, this, SLOT (host_info_results (QHostInfo)));
#endif
        }
      else
        {
          check_multicast (ha);
        }
    }
  }
}

void Configuration::impl::host_info_results (QHostInfo host_info)
{
  if (host_info.lookupId () != dns_lookup_id_) return;
  dns_lookup_id_ = -1;
  if (QHostInfo::NoError != host_info.error ())
    {
      MessageBox::critical_message (this, tr ("UDP server DNS lookup failed"), host_info.errorString ());
    }
  else
    {
      auto const& server_addresses = host_info.addresses ();
      // qDebug () << "message server addresses:" << server_addresses;
      if (server_addresses.size ())
        {
          check_multicast (server_addresses[0]);
        }
    }
}

void Configuration::impl::check_multicast (QHostAddress const& ha)
{
  auto is_multicast = is_multicast_address (ha);
  ui_->udp_interfaces_label->setVisible (is_multicast);
  ui_->udp_interfaces_combo_box->setVisible (is_multicast);
  ui_->udp_TTL_label->setVisible (is_multicast);
  ui_->udp_TTL_spin_box->setVisible (is_multicast);
  if (isVisible ())
    {
      if (is_MAC_ambiguous_multicast_address (ha))
        {
          MessageBox::warning_message (this, tr ("MAC-ambiguous multicast groups addresses not supported"));
          find_tab (ui_->udp_server_line_edit);
          ui_->udp_server_line_edit->clear ();
        }
    }
  udp_server_name_edited_ = false;
}

void Configuration::impl::size_frequency_table_columns()
{
  ui_->frequencies_table_view->setVisible(false);
  ui_->frequencies_table_view->resizeColumnsToContents();
  ui_->frequencies_table_view->setVisible(true);
}

void Configuration::impl::delete_frequencies ()
{
  auto selection_model = ui_->frequencies_table_view->selectionModel ();
  selection_model->select (selection_model->selection (), QItemSelectionModel::SelectCurrent | QItemSelectionModel::Rows);
  next_frequencies_.removeDisjointRows (selection_model->selectedRows ());
  ui_->frequencies_table_view->resizeColumnToContents (FrequencyList_v2_101::mode_column);
  size_frequency_table_columns ();
}

void Configuration::impl::load_frequencies ()
{
  auto file_name = QFileDialog::getOpenFileName (this, tr ("Load Working Frequencies"), writeable_data_dir_.absolutePath (), tr ("Frequency files (*.qrg *.qrg.json);;All files (*.*)"));
  if (!file_name.isNull ())
    {
      auto const list = read_frequencies_file (file_name);
      if (list.size ()
          && (!next_frequencies_.frequency_list ().size ()
              || MessageBox::Yes == MessageBox::query_message (this
                                                               , tr ("Replace Working Frequencies")
                                                               , tr ("Are you sure you want to discard your current "
                                                                     "working frequencies and replace them with the "
                                                                     "loaded ones?"))))
        {
          next_frequencies_.frequency_list (list); // update the model
        }
      size_frequency_table_columns();
    }
}

void Configuration::impl::merge_frequencies ()
{
  auto file_name = QFileDialog::getOpenFileName (this, tr ("Merge Working Frequencies"), writeable_data_dir_.absolutePath (), tr ("Frequency files (*.qrg *.qrg.json);;All files (*.*)"));
  if (!file_name.isNull ())
    {
      next_frequencies_.frequency_list_merge (read_frequencies_file (file_name)); // update the model
      size_frequency_table_columns();
    }
}

FrequencyList_v2_101::FrequencyItems Configuration::impl::read_frequencies_file (QString const& file_name)
{
  QFile frequencies_file {file_name};
  frequencies_file.open (QFile::ReadOnly);
  QDataStream ids {&frequencies_file};
  FrequencyList_v2_101::FrequencyItems list;
  FrequencyList_v2::FrequencyItems list_v100;

  // read file as json if ends with qrg.json.
  if (file_name.endsWith(".qrg.json", Qt::CaseInsensitive))
    {
      try
        {
          FrequencyList_v2_101::ImportReport report;
          list = FrequencyList_v2_101::from_json_file (&frequencies_file, &report);
          if (report.skipped ())
            {
              QStringList reasons;
              if (report.invalid_frequency)
                reasons << tr ("Invalid frequency: %1").arg (report.invalid_frequency);
              if (report.invalid_region)
                reasons << tr ("Unknown region: %1").arg (report.invalid_region);
              if (!report.unknown_modes.isEmpty ())
                {
                  QStringList examples;
                  int unknown_count = 0;
                  for (auto it = report.unknown_modes.cbegin (); it != report.unknown_modes.cend (); ++it)
                    {
                      unknown_count += it.value ();
                      if (examples.size () < 3)
                        examples << tr ("%1 (%2)").arg (it.key ()).arg (it.value ());
                    }
                  reasons << tr ("Unknown mode: %1 (%2)").arg (unknown_count).arg (examples.join (", "));
                }
              if (report.invalid_item)
                reasons << tr ("Invalid dates: %1").arg (report.invalid_item);
              MessageBox::warning_message (this, tr ("Some working frequencies were skipped"),
                                           tr ("Imported %1 of %2 entries. Skipped %3:\n%4")
                                             .arg (report.imported).arg (report.entries).arg (report.skipped ())
                                             .arg (reasons.join ("\n")));
            }
        }
      catch (ReadFileException const &e)
        {
          MessageBox::critical_message(this, tr("Error reading frequency file"), e.message_);
        }
      return list;
    }

  quint32 magic;
  ids >> magic;
  if (qrg_magic != magic)
    {
      MessageBox::warning_message (this, tr ("Not a valid frequencies file"), tr ("Incorrect file magic"));
      return list;
    }
  quint32 version;
  ids >> version;
  // handle version checks and QDataStream version here if
  // necessary
  if (version > qrg_version)
    {
      MessageBox::warning_message (this, tr ("Not a valid frequencies file"), tr ("Version is too new"));
      return list;
    }

  // de-serialize the data using version if necessary to
  // handle old schema
  if (version == qrg_version_100)
    {
      ids >> list_v100;
      Q_FOREACH (auto const& item, list_v100)
        {
          list << FrequencyList_v2_101::Item{item.frequency_, item.mode_, item.region_, QString(), QString(), QDateTime(),
                                         QDateTime(), false};
        }
    }
    else
    {
      ids >> list;
    }

  if (ids.status () != QDataStream::Ok || !ids.atEnd ())
    {
      MessageBox::warning_message (this, tr ("Not a valid frequencies file"), tr ("Contents corrupt"));
      list.clear ();
      return list;
    }
  return list;
}

void Configuration::impl::save_frequencies ()
{
  auto file_name = QFileDialog::getSaveFileName (this, tr ("Save Working Frequencies"), writeable_data_dir_.absolutePath (), tr ("Frequency files (*.qrg *.qrg.json);;All files (*.*)"));
  if (!file_name.isNull ())
    {
      bool b_write_json = file_name.endsWith(".qrg.json", Qt::CaseInsensitive);

      QFile frequencies_file {file_name};
      frequencies_file.open (QFile::WriteOnly);

      QDataStream ods {&frequencies_file};

      auto selection_model = ui_->frequencies_table_view->selectionModel ();
      if (selection_model->hasSelection ()
          && MessageBox::Yes == MessageBox::query_message (this
                                                           , tr ("Only Save Selected  Working Frequencies")
                                                           , tr ("Are you sure you want to save only the "
                                                                 "working frequencies that are currently selected? "
                                                                 "Click No to save all.")))
        {
          selection_model->select (selection_model->selection (), QItemSelectionModel::SelectCurrent | QItemSelectionModel::Rows);
          if (b_write_json)
            {
              next_frequencies_.to_json_file(&frequencies_file, "0x" + QString::number(qrg_magic, 16).toUpper(),
                                               "0x" + QString::number(qrg_version, 16).toUpper(),
                                               next_frequencies_.frequency_list(selection_model->selectedRows()));
            } else
            {
              ods << qrg_magic << qrg_version << next_frequencies_.frequency_list(selection_model->selectedRows());
            }
        }
      else
        {
          if (b_write_json)
            {
              next_frequencies_.to_json_file(&frequencies_file,
                                               "0x" + QString::number(qrg_magic, 16).toUpper(),
                                               "0x" + QString::number(qrg_version, 16).toUpper(),
                                                             next_frequencies_.frequency_list());
            } else
            {
              ods << qrg_magic << qrg_version << next_frequencies_.frequency_list();
            }
        }
    }
}

void Configuration::impl::reset_frequencies ()
{
  if (MessageBox::Yes == MessageBox::query_message (this, tr ("Reset Working Frequencies")
                                                    , tr ("Are you sure you want to discard your current "
                                                          "working frequencies and replace them with default "
                                                          "ones?")))
    {
      next_frequencies_.reset_to_defaults ();
    }
    size_frequency_table_columns ();
    refresh_suggestion_notice ();
}

void Configuration::impl::persist_seen_suggestions ()
{
  SettingsGroup g {settings_, "Configuration"};
  settings_->setValue ("SeenSuggestedFrequencyKeys", suggestion_notice_state_.seen_keys ());
}

void Configuration::impl::dismiss_suggestions ()
{
  suggestion_notice_state_.dismiss (FrequencyList_v2_101::default_items ());
  persist_seen_suggestions ();
  suggestions_notice_->hide ();
}

void Configuration::impl::refresh_suggestion_notice ()
{
  auto const visibility = suggestion_notice_state_.visibility (
    FrequencyList_v2_101::default_items (), next_frequencies_.frequency_list ());
  suggestions_notice_label_->setText (
    visibility == FrequencySuggestions::NoticeState::Visibility::New
      ? tr ("New suggested frequencies are available. Choose any you want to add without resetting your list.")
      : tr ("Suggested frequencies are available. Choose any you want to add without resetting your list."));
  suggestions_notice_->setVisible (visibility != FrequencySuggestions::NoticeState::Visibility::Hidden);
}

void Configuration::impl::show_suggested_frequencies ()
{
  QSet<QString> new_keys;
  {
    SettingsGroup g {settings_, "Configuration"};
    if (settings_->contains ("SeenSuggestedFrequencyKeys"))
      {
        auto const seen = settings_->value ("SeenSuggestedFrequencyKeys").toStringList ();
        for (auto const& item : FrequencyList_v2_101::default_items ())
          {
            auto const key = FrequencySuggestions::key (item);
            if (!seen.contains (key)) new_keys.insert (key);
          }
      }
  }

  SuggestedFrequenciesDialog dialog {FrequencyList_v2_101::default_items (),
                                     next_frequencies_.frequency_list (), bands_,
                                     new_keys, this};
  if (dialog.exec () == QDialog::Accepted)
    {
      auto additions = FrequencySuggestions::prepare_additions (
        dialog.selected_items (), next_frequencies_.frequency_list (), bands_);
      suggestion_notice_state_.selected_additions (additions);
      next_frequencies_.frequency_list_merge (additions);
      size_frequency_table_columns ();
    }
  refresh_suggestion_notice ();
}

void Configuration::impl::insert_frequency ()
{
  if (QDialog::Accepted == frequency_dialog_->exec ())
    {
      auto const index = next_frequencies_.add (frequency_dialog_->item ());
      ui_->frequencies_table_view->setCurrentIndex (index);
      ui_->frequencies_table_view->selectionModel ()->select (index, QItemSelectionModel::ClearAndSelect | QItemSelectionModel::Rows);
      ui_->frequencies_table_view->resizeColumnToContents (FrequencyList_v2_101::mode_column);
      size_frequency_table_columns();
    }
}

void Configuration::impl::delete_stations ()
{
  auto selection_model = ui_->stations_table_view->selectionModel ();
  selection_model->select (selection_model->selection (), QItemSelectionModel::SelectCurrent | QItemSelectionModel::Rows);
  next_stations_.removeDisjointRows (selection_model->selectedRows ());
  ui_->stations_table_view->resizeColumnToContents (StationList::band_column);
  ui_->stations_table_view->resizeColumnToContents (StationList::offset_column);
}

void Configuration::impl::insert_station ()
{
  if (QDialog::Accepted == station_dialog_->exec ())
    {
      auto const index = next_stations_.add (station_dialog_->station ());
      ui_->stations_table_view->setCurrentIndex (index);
      ui_->stations_table_view->selectionModel ()->select (index, QItemSelectionModel::ClearAndSelect | QItemSelectionModel::Rows);
      ui_->stations_table_view->resizeColumnToContents (StationList::band_column);
      ui_->stations_table_view->resizeColumnToContents (StationList::offset_column);
    }
}

void Configuration::impl::on_save_path_select_push_button_clicked (bool /* checked */)
{
  QFileDialog fd {this, tr ("Save Directory"), ui_->save_path_display_label->text ()};
  fd.setFileMode (QFileDialog::Directory);
  fd.setOption (QFileDialog::ShowDirsOnly);
  if (fd.exec ())
    {
      if (fd.selectedFiles ().size ())
        {
          ui_->save_path_display_label->setText (fd.selectedFiles ().at (0));
        }
    }
}

void Configuration::impl::on_azel_path_select_push_button_clicked (bool /* checked */)
{
  QFileDialog fd {this, tr ("AzEl Directory"), ui_->azel_path_display_label->text ()};
  fd.setFileMode (QFileDialog::Directory);
  fd.setOption (QFileDialog::ShowDirsOnly);
  if (fd.exec ()) {
    if (fd.selectedFiles ().size ()) {
      ui_->azel_path_display_label->setText(fd.selectedFiles().at(0));
    }
  }
}

void Configuration::impl::on_calibration_intercept_spin_box_valueChanged (double)
{
  rig_active_ = false;          // force reset
}

void Configuration::impl::on_calibration_slope_ppm_spin_box_valueChanged (double)
{
  rig_active_ = false;          // force reset
}

void Configuration::impl::on_prompt_to_log_check_box_toggled (bool checked)
{
  if (checked) ui_->cbAutoLog->setChecked (false);
  update_logging_control_availability ();
}

void Configuration::impl::on_cbAutoLog_toggled (bool checked)
{
  if (checked) ui_->prompt_to_log_check_box->setChecked (false);
  update_logging_control_availability ();
}

void Configuration::impl::update_logging_control_availability ()
{
  ui_->cbContestingOnly->setEnabled (!ui_->prompt_to_log_check_box->isChecked ());
}

void Configuration::impl::on_cbx2ToneSpacing_toggled (bool checked)
{
  if (checked) ui_->cbx4ToneSpacing->setChecked (false);
}

void Configuration::impl::on_cbx4ToneSpacing_toggled (bool checked)
{
  if (checked) ui_->cbx2ToneSpacing->setChecked (false);
}

void Configuration::impl::check_visibility ()
{
  auto const special_op_enabled = ui_->cbSpecialOpActivity->isChecked ();
  QWidget *activity_controls[] {
    ui_->rbFox,
    ui_->cbSuperFox,
    ui_->rbHound,
    ui_->cbOTP,
    ui_->lblOTPSeed,
    ui_->OTPSeed,
    ui_->lblOTPEvery,
    ui_->sbOTPinterval,
    ui_->cbShowOTP,
    ui_->lblOTPUrl,
    ui_->OTPUrl,
    ui_->rbNA_VHF_Contest,
    ui_->cb_NCCC_Sprint,
    ui_->rbField_Day,
    ui_->labFD,
    ui_->Field_Day_Exchange,
    ui_->rbEU_VHF_Contest,
    ui_->rbRTTY_Roundup,
    ui_->labRTTY,
    ui_->RTTY_Exchange,
    ui_->rbWW_DIGI,
    ui_->rbARRL_Digi,
    ui_->rbQ65pileup,
    ui_->cbContestName,
    ui_->labCN,
    ui_->Contest_Name,
  };
  for (auto control : activity_controls)
    {
      control->setEnabled (special_op_enabled);
    }

  if (ui_->rbField_Day->isChecked() and special_op_enabled) {
    ui_->labFD->setEnabled (true);
    ui_->Field_Day_Exchange->setEnabled (true);
  } else {
    ui_->labFD->setEnabled (false);
    ui_->Field_Day_Exchange->setEnabled (false);
  }
  if (ui_->rbRTTY_Roundup->isChecked() and special_op_enabled) {
    ui_->labRTTY->setEnabled (true);
    ui_->RTTY_Exchange->setEnabled (true);
  } else {
    ui_->labRTTY->setEnabled (false);
    ui_->RTTY_Exchange->setEnabled (false);
  }
  if (ui_->cbContestName->isChecked() and !ui_->rbFox->isChecked() and !ui_->rbHound->isChecked()
      and  !ui_->rbQ65pileup->isChecked() and special_op_enabled) {
    ui_->labCN->setEnabled (true);
    ui_->Contest_Name->setEnabled (true);
  } else {
    ui_->labCN->setEnabled (false);
    ui_->Contest_Name->setEnabled (false);
  }
  if ((ui_->rbFox->isChecked() or ui_->rbHound->isChecked()) and special_op_enabled) {
    ui_->cbSuperFox->setEnabled (true);
    ui_->cbOTP->setEnabled (true);
  } else {
    ui_->cbSuperFox->setEnabled (false);
    ui_->cbOTP->setEnabled (false);
    ui_->cbShowOTP->setEnabled(false);
  }
  if (!ui_->rbFox->isChecked() and !ui_->rbHound->isChecked() and !ui_->rbQ65pileup->isChecked()
      and special_op_enabled) {
    ui_->cbContestName->setEnabled (true);
  } else {
    ui_->cbContestName->setEnabled (false);
  }
  if (ui_->rbNA_VHF_Contest->isChecked() and special_op_enabled) {
    ui_->cb_NCCC_Sprint->setEnabled (true);
  } else {
    ui_->cb_NCCC_Sprint->setEnabled (false);
  }
  if (!ui_->cbOTP->isChecked() or !special_op_enabled) {
    ui_->OTPSeed->setEnabled(false);
    ui_->OTPUrl->setEnabled(false);
    ui_->sbOTPinterval->setEnabled(false);
    ui_->lblOTPSeed->setEnabled(false);
    ui_->lblOTPUrl->setEnabled(false);
    ui_->lblOTPEvery->setEnabled(false);
    ui_->cbShowOTP->setEnabled(false);
  } else {
    if (ui_->rbHound->isChecked()) {
      if (ui_->OTPUrl->text().isEmpty())
      {
        ui_->OTPUrl->setText(FoxVerifier::default_url());
      }
      ui_->OTPUrl->setEnabled(true);
      ui_->lblOTPUrl->setEnabled(true);
      ui_->cbShowOTP->setEnabled(true);
    } else {
      ui_->OTPUrl->setEnabled(false);
      ui_->lblOTPUrl->setEnabled(false);
    }
    if (ui_->rbFox->isChecked()) {
      ui_->sbOTPinterval->setEnabled(true);
      ui_->OTPSeed->setEnabled(true);
      ui_->lblOTPSeed->setEnabled(true);
      ui_->lblOTPEvery->setEnabled(true);
      ui_->cbShowOTP->setEnabled(false);
    } else {
      ui_->OTPSeed->setEnabled(false);
      ui_->lblOTPSeed->setEnabled(false);
      ui_->lblOTPEvery->setEnabled(false);
      ui_->sbOTPinterval->setEnabled(false);
    }
  }
}
void Configuration::impl::on_OTPUrl_textEdited (QString const& url){
    auto text = url;
    if (text.size() == 0)
    {
      ui_->OTPUrl->setText(FoxVerifier::default_url());
    }
}
void Configuration::impl::on_OTPSeed_textEdited (QString const& url){
    ui_->OTPSeed->setText(url.toUpper());
}

void Configuration::impl::on_Field_Day_Exchange_editingFinished ()
{
  QString text = ui_->Field_Day_Exchange->text().toUpper();
  auto class_pos = text.indexOf (QRegularExpression {R"([A-H])"});
  if (class_pos >= 0 && text.size () >= class_pos + 2 && text.at (class_pos + 1) != QChar {' '})
    {
      text.insert (class_pos + 1, QChar {' '});
    }
  ui_->Field_Day_Exchange->setText (text);
}

void Configuration::impl::on_RTTY_Exchange_editingFinished ()
{
  ui_->RTTY_Exchange->setText (ui_->RTTY_Exchange->text ().toUpper ());
}

void Configuration::impl::on_Contest_Name_editingFinished ()
{
  ui_->Contest_Name->setText (ui_->Contest_Name->text ().toUpper ());
}

void Configuration::impl::on_cbSortAlphabetically_clicked (bool)
{
  sortAlphabetically_ = ui_->cbSortAlphabetically->isChecked();
  ui_->cbHideCARD->setEnabled(sortAlphabetically_);
}

void Configuration::impl::on_cbHideCARD_clicked (bool)
{
  hideCARD_ = ui_->cbHideCARD->isChecked();
}

void Configuration::impl::on_Blacklist1_editingFinished ()
{
  ui_->Blacklist1->setText (ui_->Blacklist1->text ().toUpper ());
}

void Configuration::impl::on_Blacklist2_editingFinished ()
{
  ui_->Blacklist2->setText (ui_->Blacklist2->text ().toUpper ());
}

void Configuration::impl::on_Blacklist3_editingFinished ()
{
  ui_->Blacklist3->setText (ui_->Blacklist3->text ().toUpper ());
}

void Configuration::impl::on_Blacklist4_editingFinished ()
{
  ui_->Blacklist4->setText (ui_->Blacklist4->text ().toUpper ());
}

void Configuration::impl::on_Blacklist5_editingFinished ()
{
  ui_->Blacklist5->setText (ui_->Blacklist5->text ().toUpper ());
}

void Configuration::impl::on_Blacklist6_editingFinished ()
{
  ui_->Blacklist6->setText (ui_->Blacklist6->text ().toUpper ());
}

void Configuration::impl::on_Blacklist7_editingFinished ()
{
  ui_->Blacklist7->setText (ui_->Blacklist7->text ().toUpper ());
}

void Configuration::impl::on_Blacklist8_editingFinished ()
{
  ui_->Blacklist8->setText (ui_->Blacklist8->text ().toUpper ());
}

void Configuration::impl::on_Blacklist9_editingFinished ()
{
  ui_->Blacklist9->setText (ui_->Blacklist9->text ().toUpper ());
}

void Configuration::impl::on_Blacklist10_editingFinished ()
{
  ui_->Blacklist10->setText (ui_->Blacklist10->text ().toUpper ());
}

void Configuration::impl::on_Blacklist11_editingFinished ()
{
  ui_->Blacklist11->setText (ui_->Blacklist11->text ().toUpper ());
}

void Configuration::impl::on_Blacklist12_editingFinished ()
{
  ui_->Blacklist12->setText (ui_->Blacklist12->text ().toUpper ());
}

void Configuration::impl::on_Whitelist1_editingFinished ()
{
  ui_->Whitelist1->setText (ui_->Whitelist1->text ().toUpper ());
}

void Configuration::impl::on_Whitelist2_editingFinished ()
{
  ui_->Whitelist2->setText (ui_->Whitelist2->text ().toUpper ());
}

void Configuration::impl::on_Whitelist3_editingFinished ()
{
  ui_->Whitelist3->setText (ui_->Whitelist3->text ().toUpper ());
}

void Configuration::impl::on_Whitelist4_editingFinished ()
{
  ui_->Whitelist4->setText (ui_->Whitelist4->text ().toUpper ());
}

void Configuration::impl::on_Whitelist5_editingFinished ()
{
  ui_->Whitelist5->setText (ui_->Whitelist5->text ().toUpper ());
}

void Configuration::impl::on_Whitelist6_editingFinished ()
{
  ui_->Whitelist6->setText (ui_->Whitelist6->text ().toUpper ());
}

void Configuration::impl::on_Whitelist7_editingFinished ()
{
  ui_->Whitelist7->setText (ui_->Whitelist7->text ().toUpper ());
}

void Configuration::impl::on_Whitelist8_editingFinished ()
{
  ui_->Whitelist8->setText (ui_->Whitelist8->text ().toUpper ());
}

void Configuration::impl::on_Whitelist9_editingFinished ()
{
  ui_->Whitelist9->setText (ui_->Whitelist9->text ().toUpper ());
}

void Configuration::impl::on_Whitelist10_editingFinished ()
{
  ui_->Whitelist10->setText (ui_->Whitelist10->text ().toUpper ());
}

void Configuration::impl::on_Whitelist11_editingFinished ()
{
  ui_->Whitelist11->setText (ui_->Whitelist11->text ().toUpper ());
}

void Configuration::impl::on_Whitelist12_editingFinished ()
{
  ui_->Whitelist12->setText (ui_->Whitelist12->text ().toUpper ());
}

void Configuration::impl::on_Pass1_editingFinished ()
{
  ui_->Pass1->setText (ui_->Pass1->text ().toUpper ());
}

void Configuration::impl::on_Pass2_editingFinished ()
{
  ui_->Pass2->setText (ui_->Pass2->text ().toUpper ());
}

void Configuration::impl::on_Pass3_editingFinished ()
{
  ui_->Pass3->setText (ui_->Pass3->text ().toUpper ());
}

void Configuration::impl::on_Pass4_editingFinished ()
{
  ui_->Pass4->setText (ui_->Pass4->text ().toUpper ());
}

void Configuration::impl::on_Pass5_editingFinished ()
{
  ui_->Pass5->setText (ui_->Pass5->text ().toUpper ());
}

void Configuration::impl::on_Pass6_editingFinished ()
{
  ui_->Pass6->setText (ui_->Pass6->text ().toUpper ());
}

void Configuration::impl::on_Pass7_editingFinished ()
{
  ui_->Pass7->setText (ui_->Pass7->text ().toUpper ());
}

void Configuration::impl::on_Pass8_editingFinished ()
{
  ui_->Pass8->setText (ui_->Pass8->text ().toUpper ());
}

void Configuration::impl::on_Pass9_editingFinished ()
{
  ui_->Pass9->setText (ui_->Pass9->text ().toUpper ());
}

void Configuration::impl::on_Pass10_editingFinished ()
{
  ui_->Pass10->setText (ui_->Pass10->text ().toUpper ());
}

void Configuration::impl::on_Pass11_editingFinished ()
{
  ui_->Pass11->setText (ui_->Pass11->text ().toUpper ());
}

void Configuration::impl::on_Pass12_editingFinished ()
{
  ui_->Pass12->setText (ui_->Pass12->text ().toUpper ());
}

void Configuration::impl::on_Territory1_editingFinished ()
{
  ui_->Territory1->setText (ui_->Territory1->text ());
}

void Configuration::impl::on_Territory2_editingFinished ()
{
  ui_->Territory2->setText (ui_->Territory2->text ());
}

void Configuration::impl::on_Territory3_editingFinished ()
{
  ui_->Territory3->setText (ui_->Territory3->text ());
}

void Configuration::impl::on_Territory4_editingFinished ()
{
  ui_->Territory4->setText (ui_->Territory4->text ());
}

void Configuration::impl::on_highlight_orange_callsigns_editingFinished ()
{
  ui_->highlight_orange_callsigns->setText (ui_->highlight_orange_callsigns->text ().toUpper ());
}

void Configuration::impl::on_highlight_blue_callsigns_editingFinished ()
{
  ui_->highlight_blue_callsigns->setText (ui_->highlight_blue_callsigns->text ().toUpper ());
}

void Configuration::impl::on_voices_combo_box_currentIndexChanged (int /* index */)
{
  voice_ = ui_->voices_combo_box->currentIndex();
  read_voice_directory ();
}

void Configuration::impl::read_voices ()
{
  auto const base_sounds_directory = app_sounds_directory ();
  if (ui_->voices_combo_box->count () > 0)
    {
      ui_->voices_combo_box->setItemData (0, base_sounds_directory.absolutePath ());
    }

  auto const voiceList = app_voice_manifest_path ();
  QFile file2 {voiceList};
  QTextStream stream2(&file2);
  if(!voiceList.isEmpty () && file2.open (QIODevice::ReadOnly | QIODevice::Text)) {
    auto const voice_root = QFileInfo {file2}.absoluteDir ();
    while (!stream2.atEnd()) {
      QString line = stream2.readLine();
      QString voicePath;
      QString voiceName;
      if (!parse_app_voice_entry (line, voicePath, voiceName))
        {
          continue;
        }
      ui_->voices_combo_box->addItem (voiceName, sounds_subdirectory (voice_root, voicePath).absolutePath ());
    }
    stream2.flush();
    file2.close();
  } else {
    voice_=0;
  }
  if (voice_ < 0 || voice_ >= ui_->voices_combo_box->count ())
    {
      voice_=0;
    }
  ui_->voices_combo_box->setCurrentIndex (voice_);
  read_voice_directory ();
}

void Configuration::impl::read_voice_directory ()
{
  voice_directory_.setPath (ui_->voices_combo_box->currentData ().toString ());
}

void Configuration::impl::on_pb_test_alerts_clicked (bool)
{
  read_voice_directory ();
#ifdef WIN32
  QAudioOutput info(QAudioDeviceInfo::defaultOutputDevice());
  QAudioFormat format;
  format.setCodec("audio/pcm");
  format.setSampleRate (48000);
  format.setChannelCount (1);
  format.setSampleSize (16);
  format.setSampleType(QAudioFormat::SignedInt);
  QAudioOutput* audio;
  audio = new QAudioOutput(format, this);
  QFile *effect = new QFile(this);
  effect->setFileName (voice_directory_.absoluteFilePath ("Testing123.wav"));
  effect->open(QIODevice::ReadOnly);
  audio->start(effect);
#else
  QSound::play (voice_directory_.absoluteFilePath ("Testing123.wav"));  // for Linux and macOS
#endif
}

bool Configuration::impl::have_rig ()
{
  if (!open_rig ())
    {
      MessageBox::critical_message (this, tr ("Rig control error")
                                    , tr ("Failed to open connection to rig"));
    }
  return rig_active_;
}

bool Configuration::impl::can_control_rig (char const * command) const
{
  if (rig_active_) return true;

  LOG_TRACE ("suppressing " << command << " because rig is not active");
  return false;
}

void Configuration::impl::mark_rig_offline ()
{
  cached_rig_state_.online (false);
  cached_rig_state_.ptt (false);
  cached_rig_state_.tune (false);
  cached_rig_state_.audio (false);
  cached_rig_state_.tx_audio (false);
}

QString Configuration::impl::summarize_transceiver_failure (QString const& reason)
{
  auto lines = reason.split (QRegularExpression {"[\\r\\n]+"}, SkipEmptyParts);
  for (auto& line: lines)
    {
      line = line.simplified ();
    }
  lines.removeAll (QString {});

  auto summary = lines.isEmpty () ? reason.simplified () : lines.front ();
  if (lines.size () > 1 && lines.back () != summary)
    {
      summary += " | " + lines.back ();
    }

  constexpr int max_summary_length {500};
  if (summary.size () > max_summary_length)
    {
      summary = summary.left (max_summary_length - 3) + "...";
    }
  return summary;
}

bool Configuration::impl::open_rig (bool force)
{
  auto result = false;

  auto const rig_data = gather_rig_data ();
  if (tx_inhibit_blocks_rig_restart (rig_data, force))
    {
      LOG_INFO ("refusing to restart the rig while TX inhibit is active");
      return false;
    }
  if (rig_restart_required (rig_data, force))
    {
      try
        {
          if (is_tci_ && rig_active_ && tci_audio_) restart_tci_device_ = true;
          close_rig ();

          auto const txvolume = cached_rig_state_.txvolume ();
          auto const receive_policy = cached_rig_state_.receive_policy ();
          auto const receive_context = cached_rig_state_.receive_context ();

          // create a new Transceiver object
          auto rig = transceiver_factory_.create (rig_data, transceiver_thread_);
          cached_rig_state_ = Transceiver::TransceiverState {};
          cached_rig_state_.txvolume (txvolume);
          cached_rig_state_.receive_policy (receive_policy);
          cached_rig_state_.receive_context (receive_context);

          // hook up Configuration transceiver control signals to Transceiver slots
          //
          // these connections cross the thread boundary
          rig_connections_ << connect (this, &Configuration::impl::set_transceiver,
                                       rig.get (), &Transceiver::set);
          rig_connections_ << connect (this, &Configuration::impl::enqueue_jtty_pcm,
                                       rig.get (), &Transceiver::enqueue_jtty_pcm);
          rig_connections_ << connect (this, &Configuration::impl::clear_jtty_pcm,
                                       rig.get (), &Transceiver::clear_jtty_pcm);
          rig_connections_ << connect (this, &Configuration::impl::receive_discontinuity,
                                       rig.get (), &Transceiver::receive_discontinuity);
          rig_connections_ << connect (this, &Configuration::impl::receive_stop_reason,
                                       rig.get (), &Transceiver::receive_stop_reason);
          rig_connections_ << connect (this, &Configuration::impl::receive_drain,
                                       rig.get (), &Transceiver::requestContinuousReceiveDrain);

          // hook up Transceiver signals to Configuration signals
          //
          // these connections cross the thread boundary
          rig_connections_ << connect (rig.get (), &Transceiver::resolution, this, [=] (int resolution) {
              rig_resolution_ = resolution;
            });
          rig_connections_ << connect (rig.get (), &Transceiver::tciframeswritten, this, &Configuration::impl::handle_transceiver_tciframeswritten);
          rig_connections_ << connect (rig.get (), &Transceiver::receiveAudio, self_, &Configuration::transceiverReceiveAudio);
          rig_connections_ << connect (rig.get (), &Transceiver::continuousAudioAvailable,
                                       self_, &Configuration::continuousAudioAvailable);
          rig_connections_ << connect (rig.get (), &Transceiver::continuousReceptionStopped,
                                       self_, &Configuration::continuousReceptionStopped);
          rig_connections_ << connect (rig.get (), &Transceiver::continuousReceiveDrained,
                                       self_, &Configuration::continuousReceiveDrained);
          rig_connections_ << connect (rig.get (), &Transceiver::tci_mod_active, this, &Configuration::impl::handle_transceiver_tci_mod_active);
          rig_connections_ << connect (rig.get (), &Transceiver::txSourceCommitted, self_, &Configuration::txSourceCommitted);
          rig_connections_ << connect (rig.get (), &Transceiver::rawTxPlayoutSnapshot, self_, &Configuration::rawTxPlayoutSnapshot);
          rig_connections_ << connect (rig.get (), &Transceiver::jtty_drained, self_, &Configuration::transceiver_jtty_drained);
          rig_connections_ << connect (rig.get (), &Transceiver::jtty_progress, self_, &Configuration::transceiver_jtty_progress);
          rig_connections_ << connect (rig.get (), &Transceiver::jtty_enqueue_accepted, self_, &Configuration::transceiver_jtty_enqueue_accepted);
          rig_connections_ << connect (rig.get (), &Transceiver::jtty_enqueue_failed, self_, &Configuration::transceiver_jtty_enqueue_failed);
          rig_connections_ << connect (rig.get (), &Transceiver::update, this, &Configuration::impl::handle_transceiver_update);
          rig_connections_ << connect (rig.get (), &Transceiver::failure, this, &Configuration::impl::handle_transceiver_failure);
          if (auto inhibit = qobject_cast<TxInhibitTransceiver *> (rig.get ()))
            {
              auto const generation = tx_inhibit_generation_;
              rig_connections_ << connect (self_, &Configuration::tx_inhibit_command,
                inhibit, &TxInhibitTransceiver::tx_inhibit_command, Qt::QueuedConnection);
              rig_connections_ << connect (self_, &Configuration::tx_inhibit_invalid,
                inhibit, &TxInhibitTransceiver::tx_inhibit_invalid, Qt::QueuedConnection);
              rig_connections_ << connect (
                inhibit, &TxInhibitTransceiver::statusChanged, this,
                [this, generation] (bool supported, bool inhibited,
                        QString const& holder,
                        quint32 hold_rx, quint32 release_rx,
                        quint32 expiries, quint32 invalid) {
                  if (generation != tx_inhibit_generation_) return;
                  tx_inhibit_active_ = inhibited;
                  if (inhibited)
                    {
                      ui_->test_PTT_push_button->setChecked (cached_rig_state_.ptt ());
                    }
                  tx_inhibit_status_forwarded_ = true;
                  Q_EMIT self_->tx_inhibit_status_changed (
                    supported, inhibited, holder,
                    hold_rx, release_rx, expiries, invalid);
                }, Qt::QueuedConnection);
            }

          // setup thread safe startup and close down semantics
          rig_connections_ << connect (this, &Configuration::impl::start_transceiver, rig.get (), &Transceiver::start);
          rig_connections_ << connect (this, &Configuration::impl::stop_transceiver, rig.get (), &Transceiver::stop);

          auto p = rig.release ();	// take ownership

          // schedule destruction on thread quit
          connect (transceiver_thread_, &QThread::finished, p, &QObject::deleteLater);

          // schedule eventual destruction for non-closing situations
          //
          // must   be   queued    connection   to   avoid   premature
          // self-immolation  since finished  signal  is  going to  be
          // emitted from  the object that  will get destroyed  in its
          // own  stop  slot  i.e.  a   same  thread  signal  to  slot
          // connection which by  default will be reduced  to a method
          // function call.
          connect (p, &Transceiver::finished, p, &Transceiver::deleteLater, Qt::QueuedConnection);

          ui_->test_CAT_push_button->setStyleSheet ({});
          rig_active_ = true;
          LOG_TRACE ("emitting startup_transceiver");
          Q_EMIT start_transceiver (++transceiver_command_number_); // start rig on its thread
          if(is_tci_) rig_params_ = gather_rig_data ();
          result = true;
        }
      catch (std::exception const& e)
        {
          handle_transceiver_failure (e.what ());
        }

      saved_rig_params_ = rig_data;
      rig_changed_ = true;
    }
  else
    {
      result = true;
    }
  return result;
}

bool Configuration::impl::rig_restart_required (
  TransceiverFactory::ParameterPack const& rig_data, bool force) const
{
  return force || !rig_active_ || rig_data != saved_rig_params_;
}

bool Configuration::impl::tx_inhibit_blocks_rig_restart (
  TransceiverFactory::ParameterPack const& rig_data, bool force) const
{
  return tx_inhibit_active_ && rig_restart_required (rig_data, force);
}

void Configuration::impl::warn_tx_inhibit_restart_blocked ()
{
  MessageBox::warning_message (
    this, tr ("Cannot change radio settings while TX inhibit is active"),
    tr ("Wait for the current inhibit hold to clear before applying "
        "settings that require restarting the radio."));
}

void Configuration::impl::set_cached_mode ()
{
  MODE mode {Transceiver::UNK};
  // override cache mode with what we want to enforce which includes
  // UNK (unknown) where we want to leave the rig mode untouched
  switch (data_mode_)
    {
    case data_mode_USB: mode = Transceiver::USB; break;
    case data_mode_data: mode = Transceiver::DIG_U; break;
    default: break;
    }

  cached_rig_state_.mode (mode);
}

RigFrequencyChangePolicy::Activity Configuration::impl::frequency_change_activity () const
{
  return {false, false, false, false, false, false, false,
          cached_rig_state_.ptt (), cached_rig_state_.tune ()};
}

bool Configuration::impl::frequency_change_allowed (RigFrequencyChangePolicy::ChangeKind kind) const
{
  return RigFrequencyChangePolicy::evaluate (
    kind, frequency_change_activity (), tx_frequency_corrections_allowed_).allowed;
}

bool Configuration::impl::transceiver_frequency (
  Frequency f, RigFrequencyChangePolicy::ChangeKind kind)
{
  return RigFrequencyChangePolicy::applyIfAllowed (
    kind, frequency_change_activity (), tx_frequency_corrections_allowed_, [this, f] {
      cached_rig_state_.online (true); // we want the rig online
      set_cached_mode ();

      // apply any offset & calibration
      // we store the offset here for use in feedback from the rig, we
      // cannot absolutely determine if the offset should apply but by
      // simply picking an offset when the Rx frequency is set and
      // sticking to it we get sane behaviour
      current_offset_ = stations_.offset (f);
      cached_rig_state_.frequency (apply_calibration (f + current_offset_));

      // qDebug () << "Configuration::impl::transceiver_frequency: n:" << transceiver_command_number_ + 1 << "f:" << f;
      LOG_TRACE ("emitting set_transceiver: requested state:" << cached_rig_state_);
      Q_EMIT set_transceiver (cached_rig_state_, ++transceiver_command_number_);
    });
}

bool Configuration::impl::transceiver_tx_frequency (
  Frequency f, RigFrequencyChangePolicy::ChangeKind kind)
{
  if (!RigFrequencyChangePolicy::tx_path_frequency_supported (f != 0, split_mode ()))
    {
      return false;
    }
  return RigFrequencyChangePolicy::applyIfAllowed (
    kind, frequency_change_activity (), tx_frequency_corrections_allowed_, [this, f] {
      Q_ASSERT (!f || split_mode ());
      if (split_mode ())
        {
          cached_rig_state_.online (true); // we want the rig online
          set_cached_mode ();
          cached_rig_state_.split (f);
          cached_rig_state_.tx_frequency (f);

          // lookup offset for tx and apply calibration
          if (f)
            {
              // apply and offset and calibration
              // we store the offset here for use in feedback from the rig, we
              // cannot absolutely determine if the offset should apply but by
              // simply picking an offset when the Rx frequency is set and
              // sticking to it we get sane behaviour
              current_tx_offset_ = stations_.offset (f);
              cached_rig_state_.tx_frequency (apply_calibration (f + current_tx_offset_));
            }

          // qDebug () << "Configuration::impl::transceiver_tx_frequency: n:" << transceiver_command_number_ + 1 << "f:" << f;
          LOG_TRACE ("emitting set_transceiver: requested state:" << cached_rig_state_);
          Q_EMIT set_transceiver (cached_rig_state_, ++transceiver_command_number_);
        }
    });
}

void Configuration::impl::transceiver_mode (MODE m)
{
  cached_rig_state_.online (true); // we want the rig online
  cached_rig_state_.mode (m);
  // qDebug () << "Configuration::impl::transceiver_mode: n:" << transceiver_command_number_ + 1 << "m:" << m;
  LOG_TRACE ("emitting set_transceiver: requested state:" << cached_rig_state_);
  Q_EMIT set_transceiver (cached_rig_state_, ++transceiver_command_number_);
}

void Configuration::impl::transceiver_ptt (bool on)
{
  cached_rig_state_.online (true); // we want the rig online
  set_cached_mode ();
  cached_rig_state_.ptt (on);
  // qDebug () << "Configuration::impl::transceiver_ptt: n:" << transceiver_command_number_ + 1 << "on:" << on;
  LOG_TRACE ("emitting set_transceiver: requested state:" << cached_rig_state_);
  Q_EMIT set_transceiver (cached_rig_state_, ++transceiver_command_number_);
}

void Configuration::impl::transceiver_audio (bool on)
{
  cached_rig_state_.online (true); // we want the rig online
  set_cached_mode ();
  if (cached_rig_state_.audio() != on)
  {
    cached_rig_state_.audio (on);
//    printf("%s(%0.1f) Configuration #:%d audio: %d\n",QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),transceiver_command_number_+1,on);
    Q_EMIT set_transceiver (cached_rig_state_, ++transceiver_command_number_);
  }
}

void Configuration::impl::transceiver_tune (bool on)
{
  cached_rig_state_.online (true); // we want the rig online
  set_cached_mode ();
  //cached_rig_state_.ptt (on);
  cached_rig_state_.tune (on);
  // qDebug () << "Configuration::impl::transceiver_ptt: n:" << transceiver_command_number_ + 1 << "on:" << on;
  LOG_TRACE ("emitting set_transceiver: requested state:" << cached_rig_state_);
  Q_EMIT set_transceiver (cached_rig_state_, ++transceiver_command_number_);
}


void Configuration::impl::transceiver_period (double period)
{
  cached_rig_state_.online (true); // we want the rig online
  set_cached_mode ();
//    printf("%s(%0.1f) Configuration #:%d period: %0.1f cached: %0.1f\n",QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),transceiver_command_number_+1,period,cached_rig_state_.period());
  cached_rig_state_.period (period);
  Q_EMIT set_transceiver (cached_rig_state_, ++transceiver_command_number_);
}

void Configuration::impl::transceiver_blocksize (qint32 blocksize)
{
  cached_rig_state_.online (true); // we want the rig online
  set_cached_mode ();
  if (cached_rig_state_.blocksize() != blocksize)
  {
//    printf("%s(%0.1f) Configuration #:%d blocksize: %d cached:%d\n",QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),transceiver_command_number_+1,blocksize,cached_rig_state_.blocksize());
    cached_rig_state_.blocksize (blocksize);
    Q_EMIT set_transceiver (cached_rig_state_, ++transceiver_command_number_);
  }
}

void Configuration::impl::transceiver_spread (double spread)
{
  cached_rig_state_.online (true); // we want the rig online
  set_cached_mode ();
  if (cached_rig_state_.spread() != spread)
  {
//    printf("%s(%0.1f) Configuration #:%d spread: %0.1f cached: %0.1f\n",QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),transceiver_command_number_+1,spread,cached_rig_state_.spread());
    cached_rig_state_.spread (spread);
    Q_EMIT set_transceiver (cached_rig_state_, ++transceiver_command_number_);
  }
}

void Configuration::impl::transceiver_nsym (int nsym)
{
  cached_rig_state_.online (true); // we want the rig online
  set_cached_mode ();
  if (cached_rig_state_.nsym() != nsym)
  {
//    printf("%s(%0.1f) Configuration #:%d nsym: %d cached:%d\n",QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),transceiver_command_number_+1,nsym,cached_rig_state_.nsym());
    cached_rig_state_.nsym (nsym);
    Q_EMIT set_transceiver (cached_rig_state_, ++transceiver_command_number_);
  }
}

void Configuration::impl::transceiver_trfrequency (double trfrequency)
{
  cached_rig_state_.online (true); // we want the rig online
  set_cached_mode ();
  if (cached_rig_state_.trfrequency() != trfrequency)
  {
//    printf("%s(%0.1f) Configuration #:%d trfrequency: %0.1f cached: %0.1f\n",QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),transceiver_command_number_+1,trfrequency,cached_rig_state_.trfrequency());
    cached_rig_state_.trfrequency (trfrequency);
    Q_EMIT set_transceiver (cached_rig_state_, ++transceiver_command_number_);
  }
}

void Configuration::impl::transceiver_txvolume (double txvolume, bool force)
{
  cached_rig_state_.online (true); // we want the rig online
  set_cached_mode ();
  if (force || cached_rig_state_.txvolume() != txvolume)
  {
//    printf("%s(%0.1f) Configuration #:%d txvolume: %0.1f cached: %0.1f\n",QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),transceiver_command_number_+1,txvolume,cached_rig_state_.txvolume());
    cached_rig_state_.txvolume (txvolume);
    Q_EMIT set_transceiver (cached_rig_state_, ++transceiver_command_number_);
  }
}

void Configuration::impl::transceiver_volume (double volume)
{
  cached_rig_state_.online (true); // we want the rig online
  set_cached_mode ();
  if (cached_rig_state_.volume() != volume)
  {
    //printf("In Configuration::transceiver_volume, volume: %f cached: %f\n",volume,cached_rig_state_.volume());
    cached_rig_state_.volume (volume);
    Q_EMIT set_transceiver (cached_rig_state_, ++transceiver_command_number_);
  }
}

void Configuration::impl::transceiver_modulator_start (TxEvidence::TxRequest const& request)
{
  cached_rig_state_.online (true); // we want the rig online
  set_cached_mode ();
  if (!cached_rig_state_.tx_audio())
  {
    cached_rig_state_.tx_audio (true);
    cached_rig_state_.tx_request (request);
    //    printf("%s(%0.1f) Configuration #:%d modulator_start: symbolslength=%d framespersymbol=%0.1f frequency=%0.1f tonespacing=%0.1f synchronize= %d dbsnr=%0.1f trperiod=%0.1f\n",QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),transceiver_command_number_+1,symbolslength,framespersymbol,frequency,tonespacing,synchronize,dbsnr,trperiod);
    Q_EMIT set_transceiver (cached_rig_state_, ++transceiver_command_number_);
  }
//  else printf("%s(%0.1f) Configuration modulator_start: WAS ALLREADY RUNNING\n",QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str());
}

void Configuration::impl::transceiver_enqueue_jtty_pcm (QByteArray const& samples,
                                                         TxAudioQueueEpoch epoch,
                                                         qint64 enqueueId)
{
  if (!can_control_rig ("transceiver_enqueue_jtty_pcm"))
    {
      // Without an active transceiver nothing consumes the enqueue signal.
      // Report the failure so the submission is rejected instead of hanging.
      Q_EMIT self_->transceiver_jtty_enqueue_failed (
        epoch, enqueueId, TxAudioQueueEnqueueFailure::BackendUnavailable);
      return;
    }
  Q_EMIT enqueue_jtty_pcm (samples, epoch, enqueueId);
}

void Configuration::impl::transceiver_clear_jtty_pcm (TxAudioQueueEpoch epoch)
{
  Q_EMIT clear_jtty_pcm (epoch);
}

void Configuration::impl::transceiver_modulator_stop (bool on)
{
  cached_rig_state_.online (true); // we want the rig online
  set_cached_mode ();
  if (cached_rig_state_.tx_audio())
  {
    cached_rig_state_.tx_audio (false);
    cached_rig_state_.quick (on);
//    printf("%s(%0.1f) Configuration #:%d modulator_stop: quick=%d\n",QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str(),transceiver_command_number_+1,on);
    Q_EMIT set_transceiver (cached_rig_state_, ++transceiver_command_number_);
  }
//  else printf("%s(%0.1f) Configuration modulator_stop: WAS NOT RUNNING\n",QDateTime::currentDateTimeUtc().toString("hh:mm:ss.zzz").toStdString().c_str());
}

void Configuration::impl::sync_transceiver (bool /*force_signal*/)
{
  // pass this on as cache must be ignored
  // Q_EMIT sync (force_signal);
}

void Configuration::impl::handle_transceiver_tciframeswritten (qint64 count)
{
  Q_EMIT self_->transceiver_TCIframesWritten (count);
}

void Configuration::impl::handle_transceiver_tci_mod_active (bool on)
{
  Q_EMIT self_->transceiver_TCImodActive (on);
}

void Configuration::impl::handle_leavingSettings ()
{
  Q_EMIT self_->leavingSettings (true);
}

void Configuration::impl::handle_transceiver_update (TransceiverState const& state,
                                                     unsigned sequence_number)
{
  LOG_TRACE ("#: " << sequence_number << ' ' << state);

  // only follow rig on some information, ignore other stuff
  cached_rig_state_.online (state.online ());
  cached_rig_state_.frequency (state.frequency ());
  if(!is_tci_) cached_rig_state_.mode (state.mode ());  //was not present in jtdx
  cached_rig_state_.split (state.split ());

  if (state.online ())
    {
      ui_->test_PTT_push_button->setChecked (
        tx_inhibit_active_ ? cached_rig_state_.ptt () : state.ptt ());

      if (isVisible ())
        {
          ui_->test_CAT_push_button->setStyleSheet ("QPushButton {background-color: green;}");

          auto const& rig = ui_->rig_combo_box->currentText ();
          auto ptt_method = static_cast<TransceiverFactory::PTTMethod> (ui_->PTT_method_button_group->checkedId ());
          auto CAT_PTT_enabled = transceiver_factory_.has_CAT_PTT (rig);
          ui_->test_PTT_push_button->setEnabled ((TransceiverFactory::PTT_method_CAT == ptt_method && CAT_PTT_enabled)
                                                 || TransceiverFactory::PTT_method_DTR == ptt_method
                                                 || TransceiverFactory::PTT_method_RTS == ptt_method);
        }
    }
  else
    {
      if (is_tci_) {
      	if (sequence_number == transceiver_command_number_)  close_rig (); 
      }
      else close_rig();
    }

  // pass on to clients if current command is processed
  if (sequence_number == transceiver_command_number_)
    {
      TransceiverState reported_state {state};
      // take off calibration & offset
      reported_state.frequency (remove_calibration (reported_state.frequency ()) - current_offset_);

      if (reported_state.tx_frequency ())
        {
          // take off calibration & offset
          reported_state.tx_frequency (remove_calibration (reported_state.tx_frequency ()) - current_tx_offset_);
        }

      Q_EMIT self_->transceiver_update (reported_state);
    }
}

void Configuration::impl::handle_transceiver_failure (QString const& reason)
{
  LOG_ERROR ("handle_transceiver_failure: " << summarize_transceiver_failure (reason));
  close_rig (true);
  ui_->test_PTT_push_button->setChecked (false);

  if (isVisible ())
    {
      MessageBox::critical_message (this, tr ("Rig failure"), reason);
    }
  else
    {
      // pass on if our dialog isn't active
      Q_EMIT self_->transceiver_failure (reason);
    }
}

void Configuration::impl::close_rig (bool failed)
{
  ui_->test_PTT_push_button->setEnabled (false);

  // revert to no rig configured
  if (rig_active_)
    {
      Q_EMIT self_->transceiver_closing (failed);
      ui_->test_CAT_push_button->setStyleSheet ("QPushButton {background-color: red;}");
      LOG_TRACE ("emitting stop_transceiver");
      Q_EMIT stop_transceiver ();
      if (is_tci_) QThread::msleep (100);
      for (auto const& connection: rig_connections_)
        {
          disconnect (connection);
        }
      rig_connections_.clear ();
      rig_active_ = false;
    }
  mark_rig_offline ();
  ++tx_inhibit_generation_;
  tx_inhibit_active_ = false;
  if (tx_inhibit_status_forwarded_)
    {
      Q_EMIT self_->tx_inhibit_status_changed (false, false, {}, 0, 0, 0, 0);
      tx_inhibit_status_forwarded_ = false;
    }
}

// find the audio device that matches the specified name, also
// populate into the selection combo box with any devices we find in
// the search
QAudioDeviceInfo Configuration::impl::find_audio_device (QAudio::Mode mode, QComboBox * combo_box
                                                         , QString const& device_name)
{
  using std::copy;
  using std::back_inserter;

  if (device_name.size ())
    {
      Q_EMIT self_->enumerating_audio_devices ();
      auto const& devices = QAudioDeviceInfo::availableDevices (mode);
      Q_FOREACH (auto const& p, devices)
        {
          // qDebug () << "Configuration::impl::find_audio_device: input:" << (QAudio::AudioInput == mode) << "name:" << p.deviceName () << "preferred format:" << p.preferredFormat () << "endians:" << p.supportedByteOrders () << "codecs:" << p.supportedCodecs () << "channels:" << p.supportedChannelCounts () << "rates:" << p.supportedSampleRates () << "sizes:" << p.supportedSampleSizes () << "types:" << p.supportedSampleTypes ();
          if (p.deviceName () == device_name)
            {
              // convert supported channel counts into something we can store in the item model
              QList<QVariant> channel_counts;
              auto scc = p.supportedChannelCounts ();
              copy (scc.cbegin (), scc.cend (), back_inserter (channel_counts));
              combo_box->insertItem (0, device_name, QVariant::fromValue (audio_info_type {p, channel_counts}));
              combo_box->setCurrentIndex (0);
              return p;
            }
        }
      // insert a place holder for the not found device
      if(!tci_audio_) combo_box->insertItem (0, device_name + " (" + tr ("Not found", "audio device missing") + ")", QVariant::fromValue (audio_info_type {}));
      else {
          combo_box->insertItem (0, "TCI audio", QVariant::fromValue (audio_info_type {}));
      }
      combo_box->setCurrentIndex (0);
    }
  return {};
}

// load the available audio devices into the selection combo box
void Configuration::impl::load_audio_devices(QAudio::Mode mode, QComboBox * combo_box, QAudioDeviceInfo * device)
{
  using std::copy;
  using std::back_inserter;

  QString selected_device_name = combo_box->currentText(); // Get the currently selected item text
  combo_box->clear();

  Q_EMIT self_->enumerating_audio_devices();

  if (sortAlphabetically_) {
    auto const& devices = QAudioDeviceInfo::availableDevices(mode);
    printf ("rig_active_ is: %d and tci_audio_ is %d\n", rig_active_, tci_audio_);
    qDebug () << "qDebug says rig_active_ is: " << rig_active_ << '\n';
    qDebug () << "qDebug says tci_audio_ is: " << tci_audio_ << '\n';
    int current_index = -1;
    if (is_tci_ && tci_audio_) {
      QList<QVariant> channel_counts;
      QList<int> scc({1});
      copy (scc.cbegin (), scc.cend (), back_inserter (channel_counts));
      combo_box->addItem ("TCI audio", channel_counts);
      current_index = 0;
      return;
    }
    // Use a vector to store device names and associated audio_info_type
    std::vector<std::pair<QString, audio_info_type>> device_items;

    Q_FOREACH(auto const& p, devices) {
      // Check if the device supports the "audio/pcm" codec
      if (!p.supportedCodecs().contains("audio/pcm")) {
          continue; // Skip devices that do not support "audio/pcm"
      }
#ifndef WIN32
      if (hideCARD_ && p.deviceName().contains("CARD=")) {
          continue; // skip ALSA devices on Linux -- we never use them
      }
#endif
      // Convert supported channel counts into something we can store in the item model
      QList<QVariant> channel_counts;
      auto scc = p.supportedChannelCounts();
      copy(scc.cbegin(), scc.cend(), back_inserter(channel_counts));

      audio_info_type info = qMakePair(p, channel_counts);
      device_items.emplace_back(p.deviceName(), info);
    }
    // Sort the device items by device name
      std::sort(device_items.begin(), device_items.end(), [](const std::pair<QString, audio_info_type>& a, const std::pair<QString, audio_info_type>& b) {
          return a.first.toLower() < b.first.toLower();
      });
    // Add the sorted items back to the combo box
    for (int i = 0; i < static_cast<int>(device_items.size()); ++i)
    {
      const auto& item = device_items[i];
      combo_box->addItem(item.first, QVariant::fromValue(item.second));
      // Match the device name with the currently selected combo box item
      if (device->deviceName() == item.first) {
        current_index = i;
        combo_box->setCurrentIndex(current_index);
      }
    }
  } else {
    Q_EMIT self_->enumerating_audio_devices ();
    int current_index = -1;
    auto const& devices = QAudioDeviceInfo::availableDevices (mode);
    Q_FOREACH (auto const& p, devices) {
      // qDebug () << "Configuration::impl::load_audio_devices: input:" << (QAudio::AudioInput == mode) << "name:" << p.deviceName () << "preferred format:" << p.preferredFormat () << "endians:" << p.supportedByteOrders () << "codecs:" << p.supportedCodecs () << "channels:" << p.supportedChannelCounts () << "rates:" << p.supportedSampleRates () << "sizes:" << p.supportedSampleSizes () << "types:" << p.supportedSampleTypes ();

      // convert supported channel counts into something we can store in the item model
      QList<QVariant> channel_counts;
      auto scc = p.supportedChannelCounts ();
      copy (scc.cbegin (), scc.cend (), back_inserter (channel_counts));

      combo_box->addItem (p.deviceName (), QVariant::fromValue (audio_info_type {p, channel_counts}));
      if (p == *device) {
          current_index = combo_box->count () - 1;
      }
    }
    combo_box->setCurrentIndex (current_index);
  }
}


// load the available network interfaces into the selection combo box
void Configuration::impl::load_network_interfaces (CheckableItemComboBox * combo_box, QStringList current)
{
  combo_box->clear ();
  for (auto const& net_if : QNetworkInterface::allInterfaces ())
    {
      auto flags = QNetworkInterface::IsUp | QNetworkInterface::CanMulticast;
      if ((net_if.flags () & flags) == flags)
        {
          bool check_it = current.contains (net_if.name ());
          if (net_if.flags () & QNetworkInterface::IsLoopBack)
            {
              loopback_interface_name_ = net_if.name ();
              if (!current.size ())
                {
                  check_it = true;
                }
            }
          auto item = combo_box->addCheckItem (net_if.humanReadableName ()
                                               , net_if.name ()
                                               , check_it ? Qt::Checked : Qt::Unchecked);
          auto tip = QString {"name(index): %1(%2) - %3"}.arg (net_if.name ()).arg (net_if.index ())
                       .arg (net_if.flags () & QNetworkInterface::IsUp ? "Up" : "Down");
          auto hw_addr = net_if.hardwareAddress ();
          if (hw_addr.size ())
            {
              tip += QString {"\nhw: %1"}.arg (net_if.hardwareAddress ());
            }
          auto aes = net_if.addressEntries ();
          if (aes.size ())
            {
              tip += "\naddresses:";
              for (auto const& ae : aes)
                {
                  tip += QString {"\n  ip: %1/%2"}.arg (ae.ip ().toString ()).arg (ae.prefixLength ());
                }
            }
          item->setToolTip (tip);
        }
    }
}

// get the select network interfaces from the selection combo box
void Configuration::impl::validate_network_interfaces (QString const& /*text*/)
{
  auto model = static_cast<QStandardItemModel *> (ui_->udp_interfaces_combo_box->model ());
  bool has_checked {false};
  int loopback_row {-1};
  for (int row = 0; row < model->rowCount (); ++row)
    {
      if (model->item (row)->data ().toString () == loopback_interface_name_)
        {
          loopback_row = row;
        }
      else if (Qt::Checked == model->item (row)->checkState ())
        {
          has_checked = true;
        }
    }
  if (loopback_row >= 0)
    {
      if (!has_checked)
        {
          model->item (loopback_row)->setCheckState (Qt::Checked);
        }
      model->item (loopback_row)->setEnabled (has_checked);
    }
}

// get the select network interfaces from the selection combo box
QStringList Configuration::impl::get_selected_network_interfaces (CheckableItemComboBox * combo_box)
{
  QStringList interfaces;
  auto model = static_cast<QStandardItemModel *> (combo_box->model ());
  for (int row = 0; row < model->rowCount (); ++row)
    {
      if (Qt::Checked == model->item (row)->checkState ())
        {
          interfaces << model->item (row)->data ().toString ();
        }
    }
  return interfaces;
}

// enable only the channels that are supported by the selected audio device
void Configuration::impl::update_audio_channels (QComboBox const * source_combo_box, int index, QComboBox * combo_box, bool allow_both)
{
  // disable all items
  for (int i (0); i < combo_box->count (); ++i)
    {
      combo_box->setItemData (i, combo_box_item_disabled, Qt::UserRole - 1);
    }

  Q_FOREACH (QVariant const& v
             , (source_combo_box->itemData (index).value<audio_info_type> ().second))
    {
      // enable valid options
      int n {v.toInt ()};
      if (2 == n)
        {
          combo_box->setItemData (AudioDevice::Left, combo_box_item_enabled, Qt::UserRole - 1);
          combo_box->setItemData (AudioDevice::Right, combo_box_item_enabled, Qt::UserRole - 1);
          if (allow_both)
            {
              combo_box->setItemData (AudioDevice::Both, combo_box_item_enabled, Qt::UserRole - 1);
            }
        }
      else if (1 == n)
        {
          combo_box->setItemData (AudioDevice::Mono, combo_box_item_enabled, Qt::UserRole - 1);
        }
    }
}

void Configuration::impl::find_tab (QWidget * target)
{
  for (auto * parent = target->parentWidget (); parent; parent = parent->parentWidget ())
    {
      auto index = ui_->configuration_tabs->indexOf (parent);
      if (index != -1)
        {
          ui_->configuration_tabs->setCurrentIndex (index);
          break;
        }
    }
  target->setFocus ();
}

// load all the supported rig names into the selection combo box
void Configuration::impl::enumerate_rigs ()
{
  ui_->rig_combo_box->clear ();

  auto rigs = transceiver_factory_.supported_transceivers ();

  for (auto r = rigs.cbegin (); r != rigs.cend (); ++r)
    {
      if ("None" == r.key ())
        {
          // put None first
          ui_->rig_combo_box->insertItem (0, r.key (), r.value ().model_number_);
        }
      else
        {
          int i;
          for(i=1;i<ui_->rig_combo_box->count() && (r.key().toLower() > ui_->rig_combo_box->itemText(i).toLower());++i);
          if (i < ui_->rig_combo_box->count())  ui_->rig_combo_box->insertItem (i, r.key (), r.value ().model_number_);
          else ui_->rig_combo_box->addItem (r.key (), r.value ().model_number_);
        }
    }

  ui_->rig_combo_box->setCurrentText (rig_params_.rig_name);
}

void Configuration::impl::fill_port_combo_box(QComboBox* cb)
{
    auto current_text = cb->currentText();
    cb->clear();

    // Retrieve available ports and filter out ones with "NULL"
    QList<QSerialPortInfo> ports;
    foreach (const QSerialPortInfo &p, QSerialPortInfo::availablePorts())
    {
        if (!p.portName().contains("NULL")) // virtual serial port pairs
        {
            ports.append(p);
        }
    }

    std::sort(ports.begin(), ports.end(), [](const QSerialPortInfo& a, const QSerialPortInfo& b) {
        return serial_port_name_less(a.portName(), b.portName());
    });

    // Add sorted ports to the combo box
    for (const auto& p : ports)
    {
        // Remove possibly confusing Windows device path (OK because it gets added back by Hamlib)
        cb->addItem(p.systemLocation().remove(QRegularExpression{R"(^\\\\\.\\)"}));

        auto tip = QString{"%1 %2 %3"}.arg(p.manufacturer()).arg(p.serialNumber()).arg(p.description()).trimmed();
        if (tip.size())
        {
            cb->setItemData(cb->count() - 1, tip, Qt::ToolTipRole);
        }
    }

    cb->setEditText(current_text);
}

auto Configuration::impl::apply_calibration (Frequency f) const -> Frequency
{
  if (frequency_calibration_disabled_) return f;
  return std::llround (calibration_.intercept
                       + (1. + calibration_.slope_ppm / 1.e6) * f);
}

auto Configuration::impl::remove_calibration (Frequency f) const -> Frequency
{
  if (frequency_calibration_disabled_) return f;
  return std::llround ((f - calibration_.intercept)
                       / (1. + calibration_.slope_ppm / 1.e6));
}

ENUM_QDATASTREAM_OPS_IMPL (Configuration, DataMode);
ENUM_QDATASTREAM_OPS_IMPL (Configuration, Type2MsgGen);

ENUM_CONVERSION_OPS_IMPL (Configuration, DataMode);
ENUM_CONVERSION_OPS_IMPL (Configuration, Type2MsgGen);
