// -*- Mode: C++ -*-
#ifndef SOUNDIN_H__
#define SOUNDIN_H__

#include <limits>
#include <QString>
#include <QDateTime>
#include <QScopedPointer>
#include <QPointer>
#include <QAudioInput>

#include "Audio/AudioInputSource.hpp"

class QAudioDeviceInfo;
class QAudioInput;

// Gets audio data from sound sample source and passes it to a sink device
class SoundInput
  final : public AudioInputSource
{
  Q_OBJECT;

public:
  SoundInput (QObject * parent = nullptr)
    : AudioInputSource {parent}
    , cummulative_lost_usec_ {std::numeric_limits<qint64>::min ()}
  {
  }

  ~SoundInput () override;

  // sink must exist from the start call until the next start call or
  // stop call
  Q_SLOT void start(QAudioDeviceInfo const&, int framesPerBuffer, AudioDevice * sink, unsigned downSampleFactor, AudioDevice::Channel = AudioDevice::Mono) override;
  Q_SLOT void suspend () override;
  Q_SLOT void resume () override;
  Q_SLOT void stop () override;
  Q_SLOT void reset (bool report_dropped_frames) override;

private:
  friend class TestSoundInput;

  // used internally
  Q_SLOT void handleStateChanged (QAudio::State);

  bool checkStream ();
  void updateStreamInterruption (QAudio::State, QAudio::Error);
  void publishStreamDescriptor ();

  QScopedPointer<QAudioInput> m_stream;
  QPointer<AudioDevice> m_sink;
  qint64 cummulative_lost_usec_;
  QAudio::Error m_lastStreamError {QAudio::NoError};
  bool m_interruptionReported {false};
  bool m_destroying {false};
};

#endif
